<?php
/* Roue de la Chance — API JSON unique, partagée par tous les projets */
define('RDC_DEPTH', 1);
require dirname(__DIR__) . '/app/bootstrap.php';
require RDC_APP . '/admin.php';
require RDC_APP . '/livreur.php';

$action = (string)($_GET['a'] ?? '');
$method = (string)($_SERVER['REQUEST_METHOD'] ?? 'GET');

try {
    db();

    $downloads = ['adm.export.codes' => 'adm_export_codes', 'adm.export.plays' => 'adm_export_plays', 'adm.backup' => 'adm_backup'];
    if ($method === 'GET' && isset($downloads[$action])) {
        require_admin();
        $downloads[$action]();
        exit;
    }
    if ($method !== 'POST') fail('method', 'Méthode non autorisée.', 405);
    // Protection CSRF : en-tête personnalisé impossible à envoyer depuis un autre site.
    if (($_SERVER['HTTP_X_RDC'] ?? '') !== '1') fail('csrf', 'Requête refusée.', 403);

    $in = input();
    $slug = in_str($in, 'p', 64);

    $open = [
        'game.check' => function () use ($slug, $in) { return game_check($slug, $in['code'] ?? ''); },
        'game.play' => function () use ($slug, $in) { return game_play($slug, $in['code'] ?? ''); },
        'game.claim' => function () use ($slug, $in) { return game_claim($slug, $in['code'] ?? '', $in); },
        'liv.login' => function () use ($in) { return liv_login($in); },
        'liv.logout' => function () { return liv_logout(); },
        'liv.me' => function () { return liv_me(); },
        'liv.lookup' => function () use ($in) { return liv_lookup($in); },
        'liv.deliver' => function () use ($in) { return liv_deliver($in); },
        'liv.pending' => function () use ($in) { return liv_pending($in); },
        'adm.state' => function () { return adm_state(); },
        'adm.setup' => function () use ($in) { return adm_setup($in); },
        'adm.login' => function () use ($in) { return adm_login($in); },
    ];
    $admin = [
        'adm.logout' => function () { return adm_logout(); },
        'adm.boot' => function () { return adm_boot(); },
        'adm.dashboard' => function () { return adm_dashboard(); },
        'adm.password' => function () use ($in) { return adm_password($in); },
        'adm.project.get' => function () use ($in) { return adm_project_get($in); },
        'adm.project.save' => function () use ($in) { return adm_project_save($in); },
        'adm.project.create' => function () use ($in) { return adm_project_create($in); },
        'adm.project.delete' => function () use ($in) { return adm_project_delete($in); },
        'adm.project.import' => function () use ($in) { return adm_project_import($in); },
        'adm.projects.reorder' => function () use ($in) { return adm_projects_reorder($in); },
        'adm.product.save' => function () use ($in) { return adm_product_save($in); },
        'adm.product.delete' => function () use ($in) { return adm_product_delete($in); },
        'adm.product.reorder' => function () use ($in) { return adm_product_reorder($in); },
        'adm.wheel.save' => function () use ($in) { return adm_wheel_save($in); },
        'adm.upload' => function () { return adm_upload(); },
        'adm.codes.summary' => function () { return adm_codes_summary(); },
        'adm.codes.generate' => function () use ($in) { return adm_codes_generate($in); },
        'adm.codes.list' => function () use ($in) { return adm_codes_list($in); },
        'adm.codes.lookup' => function () use ($in) { return code_lookup($in['code'] ?? ''); },
        'adm.codes.void' => function () use ($in) { return adm_codes_set($in, 'new', 'void'); },
        'adm.codes.restore' => function () use ($in) { return adm_codes_set($in, 'void', 'new'); },
        'adm.batch.void' => function () use ($in) { return adm_batch_void($in); },
        'adm.batch.delete' => function () use ($in) { return adm_batch_delete($in); },
        'adm.batch.rename' => function () use ($in) { return adm_batch_rename($in); },
        'adm.batch.codes' => function () use ($in) { return adm_batch_codes($in); },
        'adm.plays.list' => function () use ($in) { return adm_plays_list($in); },
        'adm.plays.status' => function () use ($in) { return adm_plays_status($in); },
        'adm.livreurs.list' => function () { return adm_livreurs_list(); },
        'adm.livreurs.save' => function () use ($in) { return adm_livreurs_save($in); },
        'adm.livreurs.delete' => function () use ($in) { return adm_livreurs_delete($in); },
        'adm.settings.save' => function () use ($in) { return adm_settings_save($in); },
        'adm.diagnostic' => function () { return adm_diagnostic(); },
    ];

    if (isset($open[$action])) {
        $res = $open[$action]();
    } elseif (isset($admin[$action])) {
        require_admin();
        $res = $admin[$action]();
    } else {
        fail('unknown', 'Action inconnue.', 404);
    }
    json_out(['ok' => true] + $res);
} catch (ApiError $e) {
    json_out(['ok' => false, 'error' => $e->error, 'message' => $e->getMessage()] + $e->extra, $e->status);
} catch (Throwable $e) {
    error_log('[roue-de-la-chance] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    $out = ['ok' => false, 'error' => 'server', 'message' => 'Une erreur est survenue sur le serveur. Réessayez dans un instant.'];
    if (cfg('debug')) $out['debug'] = $e->getMessage() . ' @ ' . basename($e->getFile()) . ':' . $e->getLine();
    json_out($out, 500);
}
