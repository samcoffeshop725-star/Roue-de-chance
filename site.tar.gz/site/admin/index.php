<?php
/* Roue de la Chance — espace d'administration */
define('RDC_DEPTH', 1);
require dirname(__DIR__) . '/app/bootstrap.php';
require RDC_APP . '/render.php';
try { db(); } catch (Throwable $e) { render_fatal($e); }

shell_page('admin', 'Administration — Roue de la chance',
    ['assets/css/base.css', 'assets/css/wheel.css', 'assets/css/admin.css'],
    ['assets/js/core.js', 'assets/js/qr.js', 'assets/js/wheel.js', 'assets/js/scanner.js', 'assets/js/admin.js'],
    ['state' => admin_public_state()]
);
