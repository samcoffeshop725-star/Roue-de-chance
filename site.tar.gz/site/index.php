<?php
/* Roue de la Chance — pages publiques : jeu d'un projet, ou portail de choix du projet */
define('RDC_DEPTH', 0);
require __DIR__ . '/app/bootstrap.php';
require RDC_APP . '/render.php';

try {
    db();
} catch (Throwable $e) {
    render_fatal($e);
}

$rawCode = (string)($_GET['c'] ?? $_GET['code'] ?? '');
$code = substr((string)preg_replace('/[^A-Za-z0-9\-]/', '', $rawCode), 0, 24);
$slug = (string)($_GET['p'] ?? '');
$project = null;

if ($slug !== '') {
    $project = project_by_slug(substr((string)preg_replace('/[^a-z0-9\-]/', '', strtolower($slug)), 0, 64));
    if (!$project) {
        http_response_code(404);
        render_portal($code, true);
        exit;
    }
} else {
    $project = project_by_domain(request_hostname());
    if (!$project) {
        $home = (string)setting('home', 'portal');
        if ($home !== 'portal') $project = project_by_slug($home);
        if (!$project) {
            $active = projects_list(true);
            if (count($active) === 1) $project = $active[0];
        }
    }
}

if ($project) {
    if ((int)$project['active'] === 1) render_game($project, $code);
    else render_closed($project);
} else {
    // Un ticket déjà joué ramène directement au jeu où il a été utilisé, jamais à la page d'accueil.
    $played = $code !== '' ? played_game_url($code) : null;
    if ($played !== null) {
        header('Cache-Control: no-store');
        header('Location: ' . $played, true, 302);
        exit;
    }
    render_portal($code);
}
