/*!
 * Roue de la Chance — portail : choix du jeu quand un ticket est scanné sur l'adresse commune.
 */
(function () {
  'use strict';
  var RDC = window.RDC;
  var h = RDC.h;

  function initials(name) {
    return String(name || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(function (w) { return w.charAt(0); }).join('').toUpperCase();
  }

  /** Fond de page : image choisie dans l'administration (assombrie pour garder le texte lisible), puis étoiles. */
  function background(b) {
    var bg = h('div', { class: 'g-bg', 'aria-hidden': 'true' });
    if (b && b.image) {
      bg.appendChild(h('div', { class: 'g-bg__img', style: { backgroundImage: 'url("' + RDC.asset(b.image).replace(/"/g, '%22') + '")' } }));
      bg.appendChild(h('div', { class: 'g-bg__veil', style: { opacity: String((b.overlay == null ? 55 : b.overlay) / 100) } }));
    }
    bg.appendChild(h('div', { class: 'g-bg__stars' }));
    return bg;
  }

  function mountPortal(root, boot) {
    RDC.clear(root);
    var bg = background(boot.bg);
    var wrap;
    if (boot.mode === 'closed') {
      var p = boot.project;
      RDC.applyTheme({ c1: p.c1, c2: p.c2, c3: p.c3, bg1: p.bg1, bg2: p.bg2, text: '#FFFFFF', font_title: 'Bungee', font_body: 'Barlow' }, null, boot.fonts);
      wrap = h('main', { class: 'pt-wrap pt-closed' },
        p.logo ? h('img', { class: 'pt-logo', src: RDC.asset(p.logo), alt: '' }) : null,
        h('h1', { class: 'pt-title', text: p.name }),
        h('p', { class: 'pt-text', text: 'Ce jeu est fermé pour le moment. Revenez bientôt !' }));
    } else {
      var code = RDC.code.normalize(boot.code || '');
      var list = boot.projects || [];
      wrap = h('main', { class: 'pt-wrap' },
        boot.portal.logo ? h('img', { class: 'pt-logo', src: RDC.asset(boot.portal.logo), alt: '' }) : null,
        h('h1', { class: 'pt-title', text: boot.portal.title || 'Roue de la chance' }),
        boot.portal.text ? h('p', { class: 'pt-text', text: boot.portal.text }) : null,
        boot.not_found ? h('p', { class: 'pt-note is-warn', html: RDC.icon('warning') + '<span>Ce jeu n’existe pas ou n’est plus disponible. Choisissez un jeu ci-dessous.</span>' }) : null,
        code ? h('p', { class: 'pt-note', html: RDC.icon('ticket') + '<span>Votre ticket <strong>' + RDC.esc(RDC.code.format(code)) + '</strong> est prêt. Choisissez le jeu sur lequel l’utiliser.</span>' }) : null,
        list.length ? h('ul', { class: 'pt-list' }, list.map(function (p) {
          var a = h('a', { class: 'pt-card', href: RDC.url.project(p.slug, code ? RDC.code.format(code) : '') },
            p.logo ? h('img', { class: 'pt-card__logo', src: RDC.asset(p.logo), alt: '' }) : h('span', { class: 'pt-card__mono', 'aria-hidden': 'true', text: initials(p.name) }),
            h('span', { class: 'pt-card__txt' }, h('span', { class: 'pt-card__name', text: p.name }), p.tagline ? h('span', { class: 'pt-card__tag', text: p.tagline, style: { display: 'block' } }) : null),
            h('span', { class: 'pt-card__go', html: RDC.icon('chevron') }));
          a.style.setProperty('--pc1', p.c1);
          a.style.setProperty('--p1', p.bg1);
          a.style.setProperty('--p2', p.bg2);
          a.style.setProperty('--pink', RDC.color.ink(p.c1));
          // Le jeu remplace la page d'accueil dans l'historique : le bouton Retour ne ramène jamais ici.
          a.addEventListener('click', function (e) {
            if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            location.replace(a.href);
          });
          return h('li', {}, a);
        })) : h('p', { class: 'pt-note is-warn', html: RDC.icon('info') + '<span>Aucun jeu n’est ouvert pour le moment.</span>' }),
        list.length ? h('p', { class: 'pt-foot', text: 'Un ticket donne droit à un seul tour de roue, sur le jeu de votre choix.' }) : null);
      RDC.applyTheme({ c1: '#FF2E9A', c2: '#18E7FF', c3: '#FFD60A', bg1: '#0E0630', bg2: '#3B0A6B', text: '#FFF5FB', font_title: 'Bungee', font_body: 'Barlow' }, null, boot.fonts);
    }
    root.appendChild(h('div', { class: 'g-root' }, bg, wrap));
    return { destroy: function () {} };
  }

  RDC.apps.Portal = { mount: mountPortal };
})();
