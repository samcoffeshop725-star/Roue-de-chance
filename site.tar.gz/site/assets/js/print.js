/*!
 * Roue de la Chance — planches de tickets à imprimer (A4).
 */
(function () {
  'use strict';
  var RDC = window.RDC;
  var h = RDC.h;

  var LAYOUTS = {
    '8': { cols: 2, rows: 4, dir: 'v', qr: 32, label: '8 grands tickets' },
    '10': { cols: 2, rows: 5, dir: 'h', qr: 36, label: '10 tickets (carte de visite)' },
    '12': { cols: 3, rows: 4, dir: 'v', qr: 28, label: '12 tickets moyens' },
    '24': { cols: 3, rows: 8, dir: 'h', qr: 24, label: '24 petites étiquettes', small: true }
  };

  function Print(root, boot) {
    this.root = root;
    this.boot = boot;
    var self = this;
    RDC.clear(root);
    root.appendChild(h('div', { class: 'pr-empty', html: '<span class="rdc-spinner" style="margin:0 auto"></span>' }));
    RDC.api('adm.batch.codes', { id: boot.batch, only_new: true }).then(function (r) {
      self.data = r;
      var t = r.settings.ticket || {};
      self.opt = { link: t.link || 'portal', style: t.style || 'neon', layout: LAYOUTS[t.layout] ? t.layout : '12', logo: t.logo || 'portal',
        title: t.title || '', subtitle: t.subtitle || '', footer: t.footer || '' };
      self.render();
    }, function (e) {
      RDC.clear(root);
      root.appendChild(h('div', { class: 'pr-empty' }, h('p', { text: e.message }), h('p', {}, h('a', { href: RDC.url.admin(), text: 'Retour à l’administration' }))));
    });
  }

  Print.prototype.project = function (slug) {
    var l = this.data.projects;
    for (var i = 0; i < l.length; i++) if (l[i].slug === slug) return l[i];
    return null;
  };

  Print.prototype.render = function () {
    var self = this, d = this.data, o = this.opt;
    RDC.clear(this.root);
    var sel = function (label, key, options) {
      var s = h('select', {});
      options.forEach(function (x) { s.appendChild(h('option', { value: x[0], text: x[1] })); });
      s.value = o[key];
      s.addEventListener('change', function () { o[key] = s.value; self.paint(); });
      return h('label', { class: 'pr-ctrl' }, h('span', { text: label }), s);
    };
    var txt = function (label, key) {
      var i = h('input', { type: 'text', maxlength: '120' });
      i.value = o[key];
      i.addEventListener('input', RDC.debounce(function () { o[key] = i.value; self.paint(); }, 300));
      return h('label', { class: 'pr-ctrl' }, h('span', { text: label }), i);
    };
    var logoOpts = [['none', 'Sans logo']];
    if (d.settings.portal && d.settings.portal.logo) logoOpts.push(['portal', 'Logo du portail']);
    d.projects.forEach(function (p) { if (p.logo) logoOpts.push([p.slug, 'Logo de « ' + p.name + ' »']); });
    if (!logoOpts.some(function (x) { return x[0] === o.logo; })) o.logo = logoOpts.length > 1 ? logoOpts[1][0] : 'none';
    this.countEl = h('p', {});
    var printBtn = h('button', { type: 'button', class: 'pr-btn pr-btn--go', html: RDC.icon('print') + '<span>Imprimer</span>', onclick: function () { window.print(); } });
    var saveBtn = h('button', { type: 'button', class: 'pr-btn', html: RDC.icon('check') + '<span>Mémoriser ces réglages</span>' });
    saveBtn.addEventListener('click', function () {
      var tk = { link: o.link, style: o.style, layout: o.layout, logo: o.logo, title: o.title, subtitle: o.subtitle, footer: o.footer };
      RDC.busy(saveBtn, RDC.api('adm.settings.save', { settings: { ticket: tk } })).then(function () { RDC.toast('Réglages mémorisés pour les prochaines impressions.', 'success'); }, function (e) { RDC.toast(e.message, 'error'); });
    });
    var bar = h('div', { class: 'pr-bar' },
      h('div', { class: 'pr-bar__top' },
        h('a', { class: 'pr-btn', href: RDC.cfg.demo ? '#/admin/tickets' : RDC.url.admin() + '#/tickets', html: RDC.icon('back') + '<span>Administration</span>' }),
        h('div', { class: 'pr-bar__t' }, h('h1', { text: 'Tickets à imprimer : ' + d.batch.label }), this.countEl),
        saveBtn, printBtn),
      h('div', { class: 'pr-ctrls' },
        sel('Le QR code ouvre', 'link', [['portal', 'Le portail (tous projets)']].concat(d.projects.map(function (p) { return [p.slug, 'Le projet « ' + p.name + ' »']; }))),
        sel('Style', 'style', [['neon', 'Néon (fond sombre)'], ['light', 'Clair (économise l’encre)']]),
        sel('Format', 'layout', Object.keys(LAYOUTS).map(function (k) { return [k, LAYOUTS[k].label]; })),
        sel('Logo', 'logo', logoOpts),
        txt('Titre', 'title'), txt('Accroche', 'subtitle'), txt('Mention du bas', 'footer')));
    this.pagesEl = h('div', { class: 'pr-pages' });
    this.root.appendChild(bar);
    this.root.appendChild(h('p', { class: 'pr-tip', html: RDC.icon('info') + '<span>Dans la fenêtre d’impression, choisissez le format <strong>A4</strong>, des marges <strong>nulles</strong> et cochez <strong>« Graphiques d’arrière-plan »</strong> pour le style néon. Seuls les tickets encore disponibles sont imprimés. Découpez le long des pointillés.</span>' }));
    this.root.appendChild(this.pagesEl);
    this.paint();
  };

  Print.prototype.paint = function () {
    var self = this, d = this.data, o = this.opt;
    var L = LAYOUTS[o.layout];
    var per = L.cols * L.rows;
    var codes = d.codes;
    var pages = Math.ceil(codes.length / per);
    this.countEl.textContent = codes.length ? RDC.fmt.plural(codes.length, 'ticket disponible', 'tickets disponibles') + ' sur ' + RDC.fmt.plural(pages, 'page', 'pages') + ' A4' : 'Aucun ticket disponible dans cette série.';
    RDC.clear(this.pagesEl);
    if (!codes.length) { this.pagesEl.appendChild(h('div', { class: 'pr-empty', text: 'Tous les tickets de cette série ont déjà été joués ou désactivés.' })); return; }
    var theme = o.link !== 'portal' && this.project(o.link) ? this.project(o.link) : (d.projects[0] || {});
    var logo = o.logo === 'portal' ? (d.settings.portal && d.settings.portal.logo) : o.logo !== 'none' ? (this.project(o.logo) || {}).logo : '';
    var token = (this.paintToken = {});
    var p = 0;
    (function chunk() {
      if (token !== self.paintToken) return;
      var end = Math.min(pages, p + 6);
      for (; p < end; p++) {
        var grid = h('div', { class: 'pr-grid', style: { gridTemplateColumns: 'repeat(' + L.cols + ', 1fr)', gridTemplateRows: 'repeat(' + L.rows + ', 1fr)' } });
        codes.slice(p * per, p * per + per).forEach(function (c) { grid.appendChild(self.ticket(c.code, L, theme, logo)); });
        self.pagesEl.appendChild(h('section', { class: 'pr-page', 'aria-label': 'Page ' + (p + 1) }, grid));
      }
      if (p < pages) setTimeout(chunk, 16);
    })();
  };

  Print.prototype.ticket = function (code, L, theme, logo) {
    var o = this.opt;
    var url = RDC.url.ticket(code, this.data.public_base, o.link, this.data.projects);
    var qr = RDCQR.toSVG(url, { ecl: 'M', margin: 2, dark: '#000000', light: '#FFFFFF', title: 'QR code du ticket ' + RDC.code.format(code) });
    var qrBox = h('div', { class: 'pr-t__qr', style: { width: L.qr + 'mm', height: L.qr + 'mm' } });
    qrBox.innerHTML = qr;
    var t = h('div', { class: 'pr-t pr-t--' + L.dir + ' is-' + o.style + (L.small ? ' is-small' : '') },
      L.dir === 'v' && logo ? h('img', { class: 'pr-t__logo', src: RDC.asset(logo), alt: '' }) : null,
      L.dir === 'v' && o.title ? h('p', { class: 'pr-t__title', text: o.title }) : null,
      qrBox,
      h('div', { class: 'pr-t__txt' },
        L.dir === 'h' && logo ? h('img', { class: 'pr-t__logo', src: RDC.asset(logo), alt: '' }) : null,
        L.dir === 'h' && o.title ? h('p', { class: 'pr-t__title', text: o.title }) : null,
        h('p', { class: 'pr-t__code', text: RDC.code.format(code) }),
        o.subtitle ? h('p', { class: 'pr-t__sub', text: o.subtitle }) : null,
        o.footer ? h('p', { class: 'pr-t__foot', text: o.footer }) : null));
    t.style.setProperty('--pbg1', theme.bg1 || '#0E0630');
    t.style.setProperty('--pbg2', theme.bg2 || '#3B0A6B');
    t.style.setProperty('--pc1', theme.c1 || '#FF2E9A');
    t.style.setProperty('--pc3', theme.c3 || '#FFD60A');
    return t;
  };

  RDC.apps.Print = { mount: function (root, boot) { var p = new Print(root, boot); return { app: p, destroy: function () { p.paintToken = null; } }; } };
})();
