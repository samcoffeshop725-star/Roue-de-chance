/*!
 * Roue de la Chance — confettis (canvas, sans dépendance).
 */
(function () {
  'use strict';
  var RDC = window.RDC;

  function confetti(opts) {
    opts = opts || {};
    if (RDC.reducedMotion()) return;
    var colors = opts.colors || ['#FF2E9A', '#18E7FF', '#FFD60A', '#FFFFFF'];
    var count = opts.count || 160;
    var duration = opts.duration || 3200;
    var canvas = document.createElement('canvas');
    canvas.className = 'rdc-confetti';
    canvas.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:1200';
    document.body.appendChild(canvas);
    var ctx = canvas.getContext('2d');
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var W, H;
    function size() { W = window.innerWidth; H = window.innerHeight; canvas.width = W * dpr; canvas.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); }
    size();
    window.addEventListener('resize', size);
    var parts = [];
    var origins = opts.origins || [{ x: 0.5, y: 0.35 }];
    for (var i = 0; i < count; i++) {
      var o = origins[i % origins.length];
      var ang = (opts.spread ? (Math.random() - 0.5) * opts.spread : Math.random() * Math.PI * 2) + (opts.angle || 0);
      var sp = (opts.speed || 9) * (0.45 + Math.random() * 0.75);
      parts.push({
        x: o.x * W, y: o.y * H,
        vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp - (opts.lift || 5),
        w: 6 + Math.random() * 7, h: 8 + Math.random() * 10,
        rot: Math.random() * Math.PI, vr: (Math.random() - 0.5) * 0.35,
        tilt: Math.random() * Math.PI, vt: 0.08 + Math.random() * 0.12,
        color: colors[(Math.random() * colors.length) | 0], shape: Math.random() < 0.22 ? 'c' : 'r'
      });
    }
    var start = performance.now();
    (function frame(now) {
      var t = now - start;
      ctx.clearRect(0, 0, W, H);
      var fade = t > duration - 700 ? Math.max(0, (duration - t) / 700) : 1;
      parts.forEach(function (p) {
        p.vy += 0.22; p.vx *= 0.992; p.vy *= 0.992;
        p.x += p.vx; p.y += p.vy; p.rot += p.vr; p.tilt += p.vt;
        ctx.save();
        ctx.globalAlpha = fade;
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.color;
        if (p.shape === 'c') { ctx.beginPath(); ctx.arc(0, 0, p.w / 2, 0, Math.PI * 2); ctx.fill(); }
        else ctx.fillRect(-p.w / 2, -p.h / 2 * Math.abs(Math.cos(p.tilt)), p.w, p.h * Math.abs(Math.cos(p.tilt)) + 1);
        ctx.restore();
      });
      if (t < duration) requestAnimationFrame(frame);
      else { window.removeEventListener('resize', size); canvas.remove(); }
    })(start);
  }

  RDC.fx = {
    confetti: confetti,
    celebrate: function (colors, big) {
      confetti({ colors: colors, count: big ? 220 : 140, origins: [{ x: 0.5, y: 0.4 }], speed: big ? 13 : 10 });
      if (big) {
        setTimeout(function () { confetti({ colors: colors, count: 120, origins: [{ x: 0, y: 0.7 }], angle: -Math.PI / 3, spread: 0.9, speed: 16, lift: 2 }); }, 350);
        setTimeout(function () { confetti({ colors: colors, count: 120, origins: [{ x: 1, y: 0.7 }], angle: -2 * Math.PI / 3, spread: 0.9, speed: 16, lift: 2 }); }, 600);
      }
    }
  };
})();
