/*!
 * Roue de la Chance — la roue (SVG) : rendu des cases, ampoules, pointeur, animation de lancer.
 * Le résultat est toujours tiré par le serveur ; la roue ne fait que s'arrêter sur la case reçue.
 */
(function () {
  'use strict';
  var RDC = window.RDC;
  var NS = 'http://www.w3.org/2000/svg';
  var XL = 'http://www.w3.org/1999/xlink';
  var CX = 500, R_SEG = 440;
  var FONT = "'Barlow Condensed', 'Roboto Condensed', 'Arial Narrow', sans-serif-condensed, 'Helvetica Neue', Arial, sans-serif";

  function s(tag, attrs, parent) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) {
      if (attrs[k] === null || attrs[k] === undefined) continue;
      if (k === 'href') { e.setAttribute('href', attrs[k]); e.setAttributeNS(XL, 'xlink:href', attrs[k]); }
      else e.setAttribute(k, attrs[k]);
    }
    if (parent) parent.appendChild(e);
    return e;
  }
  function polar(r, deg) {
    var a = (deg - 90) * Math.PI / 180;
    return [CX + r * Math.cos(a), CX + r * Math.sin(a)];
  }
  function wedge(r, a0, a1) {
    var p0 = polar(r, a0), p1 = polar(r, a1);
    return 'M' + CX + ' ' + CX + 'L' + p0[0].toFixed(2) + ' ' + p0[1].toFixed(2) +
      'A' + r + ' ' + r + ' 0 ' + (a1 - a0 > 180 ? 1 : 0) + ' 1 ' + p1[0].toFixed(2) + ' ' + p1[1].toFixed(2) + 'Z';
  }

  var ctx2d = null;
  function tw(text, size, weight) {
    if (!ctx2d) ctx2d = document.createElement('canvas').getContext('2d');
    ctx2d.font = (weight || 700) + ' ' + size + 'px ' + FONT;
    return ctx2d.measureText(text).width;
  }
  function upper(t) { try { return String(t).toLocaleUpperCase('fr-FR'); } catch (e) { return String(t).toUpperCase(); } }

  /** Découpe un texte en lignes (au plus maxLines) pour une taille donnée. */
  function split(text, size, maxW, maxLines, weight) {
    var words = text.split(/[ \t\n\r]+/).filter(Boolean); // l'espace insécable lie « 70 % », « 250 g »
    var lines = [], cur = '';
    for (var i = 0; i < words.length; i++) {
      var tryLine = cur ? cur + ' ' + words[i] : words[i];
      if (tw(tryLine, size, weight) <= maxW(lines.length) || !cur) cur = tryLine;
      else { lines.push(cur); cur = words[i]; }
    }
    if (cur) lines.push(cur);
    if (lines.length > maxLines) return null;
    for (var j = 0; j < lines.length; j++) if (tw(lines[j], size, weight) > maxW(j)) return null;
    return lines;
  }
  function ellipsis(text, size, maxW, weight) {
    if (tw(text, size, weight) <= maxW) return text;
    var t = text;
    while (t.length > 1 && tw(t + '…', size, weight) > maxW) t = t.slice(0, -1);
    return t.replace(/\s+$/, '') + '…';
  }

  /* Couleurs automatiques des cases : alternance des néons du thème, jamais deux voisines identiques. */
  function autoColors(segs, theme) {
    var C = RDC.color;
    var pal = [theme.c1, theme.c2, C.shade(theme.c1, -0.32), C.shade(theme.c2, -0.34), C.mix(theme.c1, theme.c2, 0.5)];
    var loseCol = C.shade(C.mix(theme.bg2, theme.bg1, 0.35), -0.15);
    var out = [], k = 0;
    segs.forEach(function (sg, i) {
      if (sg.color) { out.push(sg.color); return; }
      if (sg.kind === 'lose') { out.push(loseCol); return; }
      if (sg.kind === 'jackpot') { out.push(theme.c3); return; }
      var tries = 0, col;
      do {
        col = pal[k % pal.length]; k++; tries++;
      } while (tries < pal.length && (col === out[i - 1] || (i === segs.length - 1 && col === out[0])));
      out.push(col);
    });
    return out;
  }

  function Wheel(container, opts) {
    this.root = container;
    this.opts = opts || {};
    this.angle = 0;
    this.state = 'idle';
    this.uid = 'w' + Math.random().toString(36).slice(2, 8);
    this.segments = [];
    this._raf = null;
    this._idleRaf = null;
    this.build();
    this.setSegments(this.opts.segments || []);
    var self = this;
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(function () { if (!self.destroyed) self.render(); });
      if (document.fonts.load) document.fonts.load('700 40px "Barlow Condensed"').then(function () { if (!self.destroyed) self.render(); }, function () {});
    }
  }

  Wheel.prototype.build = function () {
    var self = this;
    var root = this.root;
    root.classList.add('wheel');
    root.innerHTML = '';
    this.frame = s('svg', { class: 'wheel-frame', viewBox: '0 0 1000 1000', 'aria-hidden': 'true' }, root);
    this.rotorEl = document.createElement('div');
    this.rotorEl.className = 'wheel-rotor';
    root.appendChild(this.rotorEl);
    this.rotorSvg = s('svg', { viewBox: '0 0 1000 1000', role: 'img', 'aria-label': 'Roue de la chance' }, this.rotorEl);
    this.pointer = s('svg', { class: 'wheel-pointer', viewBox: '0 0 1000 1000', 'aria-hidden': 'true' }, root);
    this.hub = document.createElement('button');
    this.hub.type = 'button';
    this.hub.className = 'wheel-hub';
    this.hub.addEventListener('click', function () { if (self.opts.onHub) self.opts.onHub(self.state); });
    root.appendChild(this.hub);
    this.drawFrame();
    this.drawPointer();
    this.setState('locked');
  };

  Wheel.prototype.theme = function () {
    var t = this.opts.theme || {};
    return { c1: t.c1 || '#FF2E9A', c2: t.c2 || '#18E7FF', c3: t.c3 || '#FFD60A', bg1: t.bg1 || '#0E0630', bg2: t.bg2 || '#3B0A6B', text: t.text || '#FFFFFF', lights: t.lights !== false };
  };

  Wheel.prototype.drawFrame = function () {
    var t = this.theme(), C = RDC.color, f = this.frame, id = this.uid;
    f.innerHTML = '';
    var defs = s('defs', {}, f);
    var g = s('radialGradient', { id: id + 'bz', cx: '50%', cy: '42%', r: '60%' }, defs);
    s('stop', { offset: '0%', 'stop-color': C.shade(t.bg2, 0.12) }, g);
    s('stop', { offset: '78%', 'stop-color': C.shade(t.bg1, -0.1) }, g);
    s('stop', { offset: '100%', 'stop-color': C.shade(t.bg1, -0.55) }, g);
    var ring = s('linearGradient', { id: id + 'rg', x1: '0', y1: '0', x2: '1', y2: '1' }, defs);
    s('stop', { offset: '0%', 'stop-color': C.shade(t.c3, 0.45) }, ring);
    s('stop', { offset: '50%', 'stop-color': t.c3 }, ring);
    s('stop', { offset: '100%', 'stop-color': C.shade(t.c3, -0.45) }, ring);
    s('circle', { cx: CX, cy: CX, r: 494, fill: 'url(#' + id + 'bz)' }, f);
    s('circle', { cx: CX, cy: CX, r: 492, fill: 'none', stroke: t.c1, 'stroke-width': 5, class: 'wheel-neon' }, f);
    s('circle', { cx: CX, cy: CX, r: 451, fill: 'none', stroke: 'url(#' + id + 'rg)', 'stroke-width': 7 }, f);
    var n = 28;
    var bulbs = s('g', { class: 'wheel-bulbs' }, f);
    for (var i = 0; i < n; i++) {
      var p = polar(472, i * 360 / n);
      var b = s('g', { class: 'bulb b' + (i % 2), style: '--i:' + i }, bulbs);
      s('circle', { cx: p[0].toFixed(1), cy: p[1].toFixed(1), r: 17, class: 'bulb-halo', fill: t.c3 }, b);
      s('circle', { cx: p[0].toFixed(1), cy: p[1].toFixed(1), r: 8.5, class: 'bulb-core', fill: C.shade(t.c3, 0.7) }, b);
    }
    this.root.classList.toggle('no-lights', !t.lights);
    this.root.style.setProperty('--w-c1', t.c1);
    this.root.style.setProperty('--w-c3', t.c3);
  };

  Wheel.prototype.drawPointer = function () {
    var t = this.theme(), C = RDC.color, p = this.pointer, id = this.uid;
    p.innerHTML = '';
    var defs = s('defs', {}, p);
    var g = s('linearGradient', { id: id + 'pt', x1: '0', y1: '0', x2: '0', y2: '1' }, defs);
    s('stop', { offset: '0%', 'stop-color': C.shade(t.c1, 0.25) }, g);
    s('stop', { offset: '100%', 'stop-color': C.shade(t.c1, -0.3) }, g);
    var grp = s('g', { class: 'wheel-pointer-g' }, p);
    s('path', { d: 'M452 18H548Q562 18 555 31L510 110Q500 126 490 110L445 31Q438 18 452 18Z', fill: 'url(#' + id + 'pt)', stroke: '#FFFFFF', 'stroke-width': 6, 'stroke-linejoin': 'round' }, grp);
    s('circle', { cx: 500, cy: 44, r: 10, fill: '#FFFFFF' }, grp);
    this.pointerG = grp;
  };

  Wheel.prototype.setTheme = function (theme) {
    this.opts.theme = theme;
    this.drawFrame();
    this.drawPointer();
    this.render();
  };

  Wheel.prototype.setSegments = function (segs) {
    this.segments = (segs || []).slice();
    this.render();
  };

  Wheel.prototype.indexOf = function (segId) {
    for (var i = 0; i < this.segments.length; i++) if (this.segments[i].id === segId) return i;
    return -1;
  };

  Wheel.prototype.labelFor = function (sg) {
    var tx = this.opts.texts || {};
    var p = sg.product || {};
    if (sg.kind === 'lose') return { label: sg.label || tx.lose_label || 'Perdu', sub: sg.sub || tx.lose_sub || '' };
    var soldOut = sg.available === false;
    if (sg.kind === 'jackpot') return { label: sg.label || tx.jackpot_label || 'Grand prix', sub: soldOut ? (tx.sold_out || 'Épuisé') : (sg.sub || p.name || ''), soldOut: soldOut };
    return { label: sg.label || p.name || 'Lot', sub: soldOut ? (tx.sold_out || 'Épuisé') : (sg.sub || p.weight || ''), soldOut: soldOut };
  };

  Wheel.prototype.render = function () {
    var svg = this.rotorSvg, id = this.uid, t = this.theme(), C = RDC.color;
    svg.innerHTML = '';
    var segs = this.segments;
    var n = Math.max(segs.length, 1);
    var th = 360 / n;
    var defs = s('defs', {}, svg);
    var shade = s('radialGradient', { id: id + 'sh', cx: '50%', cy: '50%', r: '50%' }, defs);
    s('stop', { offset: '0%', 'stop-color': '#000', 'stop-opacity': 0.28 }, shade);
    s('stop', { offset: '30%', 'stop-color': '#000', 'stop-opacity': 0 }, shade);
    s('stop', { offset: '82%', 'stop-color': '#000', 'stop-opacity': 0 }, shade);
    s('stop', { offset: '100%', 'stop-color': '#000', 'stop-opacity': 0.34 }, shade);
    var gold = s('linearGradient', { id: id + 'gd', x1: '0', y1: '0', x2: '0', y2: '1' }, defs);
    s('stop', { offset: '0%', 'stop-color': C.shade(t.c3, 0.35) }, gold);
    s('stop', { offset: '100%', 'stop-color': C.shade(t.c3, -0.28) }, gold);

    s('circle', { cx: CX, cy: CX, r: 448, fill: C.shade(t.bg1, -0.4) }, svg);
    if (!segs.length) {
      s('circle', { cx: CX, cy: CX, r: R_SEG, fill: C.mix(t.bg1, t.bg2, 0.6) }, svg);
      return;
    }
    var colors = autoColors(segs, t);
    this.colors = colors;

    // Dimensions selon le nombre de cases
    var radial = n >= 10;
    var maxPhoto = n <= 4 ? 170 : n <= 6 ? 150 : n <= 8 ? 134 : n <= 10 ? 116 : n <= 12 ? 100 : n <= 16 ? 80 : 64;
    var half = Math.sin(th / 2 * Math.PI / 180);
    var d = Math.min(maxPhoto, 2 * (R_SEG - maxPhoto / 2 - 34) * half * 0.84);
    var rP = R_SEG - d / 2 - 34;
    s('clipPath', { id: id + 'cp' }, defs).appendChild(s('circle', { cx: CX, cy: CX - rP, r: d / 2 - 5 }));

    var segLayer = s('g', {}, svg);
    var contentLayer = s('g', {}, svg);
    var self = this;
    segs.forEach(function (sg, i) {
      var a0 = i * th - th / 2, a1 = i * th + th / 2;
      var fill = sg.kind === 'jackpot' && !sg.color ? 'url(#' + id + 'gd)' : colors[i];
      s('path', { d: n === 1 ? 'M500 60a440 440 0 1 0 0.01 0z' : wedge(R_SEG, a0, a1), fill: fill, class: 'seg seg-' + sg.kind, 'data-i': i }, segLayer);

      var ink = C.ink(colors[i], '#1A0A33', '#FFFFFF');
      var lb = self.labelFor(sg);
      var g = s('g', { transform: 'rotate(' + (i * th).toFixed(3) + ' 500 500)', class: 'seg-content' + (lb.soldOut ? ' is-soldout' : '') }, contentLayer);

      // Photo ou pictogramme
      var hasPhoto = sg.kind !== 'lose' && sg.product && sg.product.photo;
      if (hasPhoto) {
        s('circle', { cx: CX, cy: CX - rP, r: d / 2, fill: '#FFFFFF', stroke: sg.kind === 'jackpot' ? C.shade(t.c3, -0.45) : 'rgba(255,255,255,.9)', 'stroke-width': sg.kind === 'jackpot' ? 7 : 5 }, g);
        s('image', { href: RDC.asset(sg.product.photo), x: CX - d / 2 + 5, y: CX - rP - d / 2 + 5, width: d - 10, height: d - 10, preserveAspectRatio: 'xMidYMid slice', 'clip-path': 'url(#' + id + 'cp)' }, g);
      } else {
        var icon = sg.kind === 'lose' ? 'sad' : sg.kind === 'jackpot' ? 'crown' : 'gift';
        var isz = d * 0.5;
        var ig = s('g', { transform: 'translate(' + (CX - isz / 2) + ' ' + (CX - rP - isz / 2) + ') scale(' + (isz / 24) + ')', fill: 'none', stroke: ink, 'stroke-width': 1.7, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', opacity: 0.92 }, g);
        ig.innerHTML = RDC.icon(icon).replace(/^<svg[^>]*>|<\/svg>$/g, '');
      }

      var label = upper(lb.label), sub = lb.sub;
      if (!radial) {
        var iconSz = d * 0.5;
        var rTop = hasPhoto ? rP - d / 2 - 14 : rP - iconSz / 2 - 12, rBottom = 124;
        var widthAt = function (r) { return Math.max(20, 2 * r * Math.tan(th / 2 * Math.PI / 180) * 0.88 - 8); };
        var fit = null;
        for (var S = (n <= 4 ? 60 : n <= 6 ? 56 : n <= 8 ? 50 : 46); S >= 22; S -= 2) {
          var subS = Math.round(S * 0.66);
          var r1 = rTop - S * 0.74;
          var lines = split(label, S, function (li) { return widthAt(r1 - li * S * 1.02); }, 2, 800);
          if (!lines) continue;
          var rLast = r1 - (lines.length - 1) * S * 1.02;
          var subLines = [], rS1 = rLast - subS * 1.18, rEnd = rLast - 4;
          if (sub) {
            subLines = split(sub, subS, function (li) { return widthAt(rS1 - li * subS * 1.06); }, 2, 600);
            if (!subLines) continue;
            rEnd = rS1 - (subLines.length - 1) * subS * 1.06 - subS * 0.25;
          }
          if (rEnd < rBottom) continue;
          fit = { S: S, lines: lines, r1: r1, subS: subS, subLines: subLines, rS1: rS1 };
          break;
        }
        if (!fit) {
          var Sm = 22, r1m = rTop - Sm * 0.74, sm = 16;
          fit = { S: Sm, lines: [ellipsis(label, Sm, widthAt(r1m), 800)], r1: r1m, subS: sm, rS1: r1m - sm * 1.18,
            subLines: sub ? [ellipsis(sub, sm, widthAt(r1m - sm * 1.18), 600)] : [] };
        }
        fit.lines.forEach(function (ln, li) {
          var tx = s('text', { x: CX, y: (CX - (fit.r1 - li * fit.S * 1.02)).toFixed(1), 'text-anchor': 'middle', fill: ink, 'font-size': fit.S, 'font-weight': 800, 'font-family': FONT, 'letter-spacing': 0.5 }, g);
          tx.textContent = ln;
        });
        fit.subLines.forEach(function (ln, li) {
          var st = s('text', { x: CX, y: (CX - (fit.rS1 - li * fit.subS * 1.06)).toFixed(1), 'text-anchor': 'middle', fill: ink, 'fill-opacity': 0.88, 'font-size': fit.subS, 'font-weight': 600, 'font-family': FONT }, g);
          st.textContent = ln;
        });
      } else {
        // Texte le long du rayon (beaucoup de cases)
        var rIn = 128, rOut = rP - d / 2 - 12;
        var len = rOut - rIn;
        var hAt = 2 * rIn * Math.tan(th / 2 * Math.PI / 180) * 0.92;
        var fitR = null;
        for (var S2 = 40; S2 >= 18; S2 -= 2) {
          var subS2 = Math.round(S2 * 0.74);
          var lines2 = split(label, S2, function () { return len; }, 2, 800);
          if (!lines2) continue;
          var hTot = lines2.length * S2 * 0.98 + (sub ? subS2 : 0);
          if (hTot > hAt + S2 * 0.35) continue;
          fitR = { S: S2, lines: lines2, subS: subS2, h: hTot };
          break;
        }
        if (!fitR) fitR = { S: 18, lines: [ellipsis(label, 18, len, 800)], subS: 14, h: 32 };
        var gr = s('g', { transform: 'translate(' + CX + ' ' + (CX - (rIn + len / 2)) + ') rotate(-90)' }, g);
        var y0 = -fitR.h / 2 + fitR.S * 0.78;
        fitR.lines.forEach(function (ln, li) {
          var tx2 = s('text', { x: 0, y: (y0 + li * fitR.S * 0.98).toFixed(1), 'text-anchor': 'middle', fill: ink, 'font-size': fitR.S, 'font-weight': 800, 'font-family': FONT, 'letter-spacing': 0.4 }, gr);
          tx2.textContent = ln;
        });
        var subFit = sub ? ellipsis(sub, fitR.subS, len, 600) : '';
        // Une deuxième ligne trop coupée n'apporte rien : on l'omet plutôt que d'afficher un fragment.
        if (subFit && (subFit === sub || subFit.length - 1 >= sub.length * 0.7)) {
          var st2 = s('text', { x: 0, y: (y0 + (fitR.lines.length - 1) * fitR.S * 0.98 + fitR.subS * 1.05).toFixed(1), 'text-anchor': 'middle', fill: ink, 'fill-opacity': 0.86, 'font-size': fitR.subS, 'font-weight': 600, 'font-family': FONT }, gr);
          st2.textContent = subFit;
        }
      }
    });

    // Ombrage, séparateurs et picots
    s('circle', { cx: CX, cy: CX, r: R_SEG, fill: 'url(#' + id + 'sh)', 'pointer-events': 'none' }, svg);
    var sep = s('g', { stroke: 'rgba(255,255,255,.72)', 'stroke-width': 3.5, 'stroke-linecap': 'round' }, svg);
    if (n > 1) {
      for (var k = 0; k < n; k++) {
        var pa = polar(118, k * th - th / 2), pb = polar(R_SEG - 2, k * th - th / 2);
        s('line', { x1: pa[0].toFixed(1), y1: pa[1].toFixed(1), x2: pb[0].toFixed(1), y2: pb[1].toFixed(1) }, sep);
      }
    }
    s('circle', { cx: CX, cy: CX, r: R_SEG, fill: 'none', stroke: C.shade(t.c3, -0.15), 'stroke-width': 8 }, svg);
    var pins = s('g', {}, svg);
    if (n > 1) {
      for (var m = 0; m < n; m++) {
        var pp = polar(R_SEG - 14, m * th - th / 2);
        s('circle', { cx: pp[0].toFixed(1), cy: pp[1].toFixed(1), r: 8, fill: '#FFFFFF', stroke: C.shade(t.c3, -0.35), 'stroke-width': 3 }, pins);
      }
    }
    s('circle', { cx: CX, cy: CX, r: 116, fill: C.shade(t.bg1, -0.35), stroke: 'url(#' + id + 'gd)', 'stroke-width': 10 }, svg);
  };

  /* États visuels : locked | ready | spinning | win | jackpot | lose */
  Wheel.prototype.setState = function (st, hubHtml) {
    this.state = st;
    var r = this.root;
    ['locked', 'ready', 'spinning', 'win', 'jackpot', 'lose'].forEach(function (k) { r.classList.toggle('is-' + k, k === st); });
    var tx = this.opts.texts || {};
    var hub = this.hub;
    var labels = {
      locked: RDC.icon('lock', 'hub-ico'),
      ready: '<span class="hub-txt">' + RDC.esc(tx.hub_ready || 'Jouer') + '</span>',
      spinning: '<span class="hub-dots"><i></i><i></i><i></i></span>',
      win: RDC.icon('gift', 'hub-ico'),
      jackpot: RDC.icon('crown', 'hub-ico'),
      lose: RDC.icon('sad', 'hub-ico')
    };
    hub.innerHTML = hubHtml || labels[st] || '';
    hub.setAttribute('aria-label', st === 'ready' ? (tx.spin_btn || 'Lancer la roue') : st === 'locked' ? (tx.scan_btn || 'Scanner mon ticket') : 'Roue de la chance');
    hub.disabled = st === 'spinning';
    if (st === 'locked' || st === 'ready') this.idle(true);
  };

  /* Rotation lente au repos, pour attirer l'œil. */
  Wheel.prototype.idle = function (on) {
    var self = this;
    cancelAnimationFrame(this._idleRaf);
    this._idleRaf = null;
    if (!on || RDC.reducedMotion() || this.opts.noIdle) return;
    var last = performance.now();
    (function loop(now) {
      if (self.destroyed || self.state === 'spinning') return;
      var dt = Math.min(64, now - last); last = now;
      self.angle += dt * 0.006;
      self.apply();
      self._idleRaf = requestAnimationFrame(loop);
    })(last);
  };

  Wheel.prototype.apply = function () {
    this.rotorEl.style.transform = 'rotate(' + this.angle.toFixed(3) + 'deg)';
  };

  Wheel.prototype.tickPointer = function () {
    var p = this.pointerG;
    if (!p) return;
    p.classList.remove('tick');
    p.getBoundingClientRect();
    p.classList.add('tick');
  };

  /**
   * Lance la roue et l'arrête sur la case `index`.
   * @returns {Promise} résolue à l'arrêt
   */
  Wheel.prototype.spinTo = function (index, opts) {
    opts = opts || {};
    var self = this;
    var n = this.segments.length || 1;
    var th = 360 / n;
    this.idle(false);
    this.setState('spinning');
    var reduced = RDC.reducedMotion();
    var duration = opts.duration || (reduced ? 2600 : 6400);
    var turns = reduced ? 3 : (opts.turns || 7);
    var jitter = (Math.random() * 0.64 - 0.32) * th;
    var start = this.angle;
    var targetMod = ((-(index * th) + jitter) % 360 + 360) % 360;
    var curMod = ((start % 360) + 360) % 360;
    var delta = targetMod - curMod;
    if (delta < 0) delta += 360;
    var end = start + turns * 360 + delta;
    var back = reduced ? 0 : 9;
    var windup = reduced ? 0 : 320;
    var lastPin = Math.floor((start + th / 2) / th);
    return new Promise(function (resolve) {
      var t0 = performance.now();
      cancelAnimationFrame(self._raf);
      (function frame(now) {
        if (self.destroyed) return resolve();
        var t = now - t0;
        var ang;
        if (t < windup) {
          var u = t / windup;
          ang = start - back * Math.sin(u * Math.PI / 2);
        } else {
          var p = Math.min(1, (t - windup) / duration);
          var e = 1 - Math.pow(1 - p, 4);
          ang = (start - back) + (end - start + back) * e;
        }
        self.angle = ang;
        self.apply();
        var pin = Math.floor((ang + th / 2) / th);
        if (pin !== lastPin) {
          lastPin = pin;
          self.tickPointer();
          if (self.opts.onTick) self.opts.onTick();
        }
        if (t < windup + duration) self._raf = requestAnimationFrame(frame);
        else { self.angle = end; self.apply(); resolve(); }
      })(t0);
    });
  };

  /** Positionne directement une case sous le pointeur (sans animation). */
  Wheel.prototype.showIndex = function (index) {
    var th = 360 / (this.segments.length || 1);
    this.idle(false);
    this.angle = -index * th;
    this.apply();
  };

  Wheel.prototype.highlight = function (index) {
    RDC.$$('.seg', this.rotorSvg).forEach(function (p) { p.classList.toggle('is-hit', +p.getAttribute('data-i') === index); });
  };

  Wheel.prototype.destroy = function () {
    this.destroyed = true;
    cancelAnimationFrame(this._raf);
    cancelAnimationFrame(this._idleRaf);
  };

  Wheel.autoColors = autoColors;
  RDC.Wheel = Wheel;
})();
