/*!
 * Roue de la Chance — page de jeu publique.
 * Parcours : scanner le ticket → vérification → lancer la roue → résultat & bon de gain.
 */
(function () {
  'use strict';
  var RDC = window.RDC;
  var h = RDC.h;
  var NB = ' ';

  function contactLinks(c) {
    var out = [];
    var digits = function (v) { return String(v || '').replace(/[^\d+]/g, ''); };
    var safe = function (u) { return /^https?:\/\//i.test(u) ? u : null; };
    if (c.phone) out.push({ icon: 'phone', label: c.phone, href: 'tel:' + digits(c.phone) });
    if (c.whatsapp) out.push({ icon: 'whatsapp', label: 'WhatsApp', href: 'https://wa.me/' + digits(c.whatsapp).replace(/^\+/, '') });
    if (c.instagram) out.push({ icon: 'instagram', label: 'Instagram', href: safe(c.instagram) || 'https://instagram.com/' + encodeURIComponent(c.instagram.replace(/^@/, '')) });
    if (c.facebook) out.push({ icon: 'facebook', label: 'Facebook', href: safe(c.facebook) || 'https://facebook.com/' + encodeURIComponent(c.facebook) });
    if (c.website) out.push({ icon: 'globe', label: c.website.replace(/^https?:\/\//i, '').replace(/\/$/, ''), href: safe(c.website) || 'https://' + c.website });
    return out;
  }

  function Game(root, boot) {
    this.root = root;
    this.boot = boot;
    this.t = boot.texts || {};
    this.o = boot.options || {};
    this.theme = boot.theme || {};
    this.slug = boot.project.slug;
    this.state = 'locked';
    this.code = null;
    this.result = null;
    RDC.applyTheme(this.theme, document.documentElement, boot.fonts);
    if (this.o.sound === false) RDC.sfx.setEnabled(false);
    this.render();
    if (boot.code) this.check(boot.code, true);
  }

  Game.prototype.render = function () {
    var self = this, b = this.boot, t = this.t, th = this.theme;
    RDC.clear(this.root);

    var bg = h('div', { class: 'g-bg', 'aria-hidden': 'true' });
    if (th.bg_mode === 'image' && th.bg_image) {
      bg.appendChild(h('div', { class: 'g-bg__img', style: { backgroundImage: 'url("' + RDC.asset(th.bg_image).replace(/"/g, '%22') + '")' } }));
      bg.appendChild(h('div', { class: 'g-bg__veil', style: { opacity: String((th.bg_overlay == null ? 55 : th.bg_overlay) / 100) } }));
    }
    if (th.sparkles !== false) bg.appendChild(h('div', { class: 'g-bg__stars' }));

    // En-tête
    this.soundBtn = this.o.sound === false ? null : h('button', { type: 'button', class: 'g-iconbtn', onclick: function () { self.toggleSound(); } });
    var brand = h('a', { class: 'g-brand', href: RDC.url.project(this.slug) },
      b.project.logo ? h('img', { class: 'g-logo', src: RDC.asset(b.project.logo), alt: '' }) : null,
      h('span', { class: 'g-brand__text' },
        h('span', { class: 'g-name', text: b.project.name }),
        b.project.tagline ? h('span', { class: 'g-tagline', text: b.project.tagline }) : null));
    var top = h('header', { class: 'g-top' }, brand, this.soundBtn);
    this.updateSoundBtn();

    // Héros
    this.statusEl = h('div', { class: 'g-status', role: 'status', 'aria-live': 'polite' });
    this.ctaBtn = h('button', { type: 'button', class: 'g-cta', onclick: function () { self.onCta(); } });
    this.altBtn = h('button', { type: 'button', class: 'g-alt', onclick: function () { self.onAlt(); } });
    var wheelBox = h('div', { class: 'g-wheel' });
    var hero = h('section', { class: 'g-hero' },
      h('div', { class: 'g-intro' }, h('h1', { class: 'g-title', text: t.title }), t.subtitle ? h('p', { class: 'g-sub', text: t.subtitle }) : null),
      h('div', { class: 'g-stage' }, th.rays !== false ? h('div', { class: 'g-rays', 'aria-hidden': 'true' }) : null, wheelBox),
      h('div', { class: 'g-panel' }, this.statusEl, this.ctaBtn, this.altBtn));

    this.mineEl = h('section', { class: 'g-mine', hidden: true, 'aria-label': 'Votre lot' });
    var main = h('main', { class: 'g-main' }, hero, this.mineEl, this.renderPrizes(), this.renderSteps());

    // Pied de page
    var links = contactLinks(b.contact || {});
    var foot = h('footer', { class: 'g-foot' },
      links.length ? h('div', { class: 'g-contact' }, links.map(function (l) {
        return h('a', { href: l.href, target: l.icon === 'phone' ? null : '_blank', rel: 'noopener', html: RDC.icon(l.icon) + '<span>' + RDC.esc(l.label) + '</span>' });
      })) : null,
      t.rules ? h('button', { type: 'button', class: 'g-rulesbtn', text: 'Règlement du jeu', onclick: function () { self.openRules(); } }) : null,
      t.footer ? h('p', { class: 'g-foot__text', text: t.footer }) : null,
      h('p', { class: 'g-copy', text: '© ' + new Date().getFullYear() + ' ' + b.project.name }));

    this.el = h('div', { class: 'g-root', 'data-bg': th.bg_mode || 'gradient' }, bg, top, main, foot);
    this.root.appendChild(this.el);

    this.wheel = new RDC.Wheel(wheelBox, {
      segments: b.segments, theme: { c1: th.c1, c2: th.c2, c3: th.c3, bg1: th.bg1, bg2: th.bg2, text: th.text, lights: th.lights },
      texts: t, onTick: function () { RDC.sfx.tick(); },
      onHub: function () { self.onHub(); }
    });
    this.setState('locked');
  };

  Game.prototype.renderPrizes = function () {
    var p = this.boot.prizes || [], t = this.t;
    if (this.o.show_prizes === false || !p.length) return null;
    var showVal = this.o.show_values;
    var chip = function (x) {
      return h('div', { class: 'g-chip' }, x.photo ? h('img', { src: RDC.asset(x.photo), alt: '', loading: 'lazy' }) : h('div', { class: 'g-chip__ph', html: RDC.icon('gift') }));
    };
    var meta = function (x) { return [x.weight, showVal && x.value ? x.value : ''].filter(Boolean).join(' · '); };
    var jack = p.filter(function (x) { return x.jackpot; })[0];
    var others = p.filter(function (x) { return x !== jack; });
    return h('section', { class: 'g-section', 'aria-labelledby': 'g-prizes-t' },
      h('h2', { class: 'g-h2', id: 'g-prizes-t', text: t.prizes_title || 'Les lots en jeu' }),
      jack ? h('div', { class: 'g-jackpot' }, chip(jack), h('div', {},
        h('span', { class: 'g-badge', html: RDC.icon('crown') + RDC.esc(t.jackpot_label || 'Grand prix') }),
        h('p', { class: 'g-jackpot__name', text: jack.name }),
        meta(jack) ? h('p', { class: 'g-jackpot__meta', text: meta(jack) }) : null,
        jack.description ? h('p', { class: 'g-jackpot__meta', text: jack.description }) : null,
        jack.available === false ? h('span', { class: 'g-soldout', text: t.sold_out || 'Épuisé' }) : null)) : null,
      others.length ? h('ul', { class: 'g-prizes' }, others.map(function (x) {
        return h('li', { class: 'g-prize' + (x.available === false ? ' is-out' : '') }, chip(x),
          h('p', { class: 'g-prize__name', text: x.name }),
          meta(x) ? h('p', { class: 'g-prize__meta', text: meta(x) }) : null,
          x.available === false ? h('span', { class: 'g-soldout', text: t.sold_out || 'Épuisé' }) : null);
      })) : null);
  };

  Game.prototype.renderSteps = function () {
    var steps = (this.t.steps || []).filter(function (s) { return s && (s.t || s.d); });
    if (this.o.show_steps === false || !steps.length) return null;
    return h('section', { class: 'g-section', 'aria-labelledby': 'g-how-t' },
      h('h2', { class: 'g-h2', id: 'g-how-t', text: 'Comment jouer' }),
      h('ol', { class: 'g-steps' }, steps.map(function (s, i) {
        return h('li', { class: 'g-step' }, h('span', { class: 'g-step__n', 'aria-hidden': 'true', text: String(i + 1) }),
          h('div', {}, h('p', { class: 'g-step__t', text: s.t }), s.d ? h('p', { class: 'g-step__d', text: s.d }) : null));
      })));
  };

  /* ───── Son ───── */
  Game.prototype.updateSoundBtn = function () {
    if (!this.soundBtn) return;
    var on = RDC.sfx.isEnabled();
    this.soundBtn.innerHTML = RDC.icon(on ? 'soundOn' : 'soundOff');
    this.soundBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
    this.soundBtn.setAttribute('aria-label', on ? 'Couper le son' : 'Activer le son');
    this.soundBtn.title = on ? 'Couper le son' : 'Activer le son';
  };
  Game.prototype.toggleSound = function () {
    RDC.sfx.setEnabled(!RDC.sfx.isEnabled());
    this.updateSoundBtn();
    if (RDC.sfx.isEnabled()) RDC.sfx.beep();
  };

  /* ───── États de la page ───── */
  Game.prototype.status = function (tone, icon, text) {
    this.statusEl.setAttribute('data-tone', tone || 'info');
    this.statusEl.innerHTML = '';
    if (icon === 'spinner') this.statusEl.appendChild(h('span', { class: 'rdc-spinner', 'aria-hidden': 'true' }));
    else if (icon) this.statusEl.appendChild(RDC.iconEl(icon));
    this.statusEl.appendChild(h('span', { text: text }));
  };

  Game.prototype.setButtons = function (cta, alt) {
    this.ctaBtn.hidden = !cta;
    if (cta) { this.ctaBtn.innerHTML = (cta.icon ? RDC.icon(cta.icon) : '') + '<span>' + RDC.esc(cta.label) + '</span>'; this.ctaBtn.disabled = !!cta.disabled; this.ctaAction = cta.action; }
    this.altBtn.hidden = !alt;
    if (alt) { this.altBtn.innerHTML = (alt.icon ? RDC.icon(alt.icon) : '') + '<span>' + RDC.esc(alt.label) + '</span>'; this.altAction = alt.action; }
  };

  Game.prototype.setState = function (st, info) {
    var t = this.t, self = this;
    this.state = st;
    ['locked', 'checking', 'ready', 'spinning', 'done'].forEach(function (k) { self.el.classList.toggle('is-' + k, k === st); });
    var scan = { label: t.scan_btn || 'Scanner mon QR code', icon: 'scan', action: 'scan' };
    var manual = { label: t.manual_btn || 'Saisir mon code', icon: 'keyboard', action: 'manual' };
    if (st === 'locked') {
      if (info && info.error) this.status('error', 'warning', info.error);
      else this.status('info', 'lock', t.locked_hint || 'Scannez votre ticket pour jouer.');
      this.setButtons(scan, manual);
      this.wheel.setState('locked');
    } else if (st === 'checking') {
      this.status('info', 'spinner', 'Vérification du ticket…');
      this.setButtons({ label: 'Vérification…', icon: 'scan', disabled: true }, null);
    } else if (st === 'ready') {
      var hint = t.ready_hint || ('Ticket {code} validé. À vous de jouer' + NB + '!');
      this.status('ok', 'check', hint.indexOf('{code}') >= 0 ? hint.replace('{code}', this.code) : hint);
      this.setButtons({ label: t.spin_btn || 'Lancer la roue', icon: 'wheel', action: 'spin' }, { label: 'Utiliser un autre ticket', icon: 'scan', action: 'scan' });
      this.wheel.setState('ready');
    } else if (st === 'spinning') {
      this.status('info', 'spinner', 'La roue tourne… bonne chance' + NB + '!');
      this.setButtons({ label: 'Bonne chance' + NB + '!', icon: 'wheel', disabled: true }, null);
    } else if (st === 'done') {
      var r = this.result;
      if (r.kind === 'lose') {
        this.status('info', 'sad', t.lose_text || 'Perdu, à la prochaine fois' + NB + '!');
        this.setButtons({ label: 'Jouer un autre ticket', icon: 'scan', action: 'scan' }, { label: 'Revoir le résultat', icon: 'eye', action: 'result' });
      } else {
        var pz = r.prize || {};
        this.status('win', r.kind === 'jackpot' ? 'crown' : 'gift', (r.kind === 'jackpot' ? (t.jackpot_label || 'Grand prix') : 'Gagné') + NB + ': ' + pz.name + (pz.weight ? ' (' + pz.weight + ')' : ''));
        this.setButtons({ label: 'Afficher mon bon de gain', icon: 'ticket', action: 'result' }, { label: 'Jouer un autre ticket', icon: 'scan', action: 'scan' });
      }
    }
  };

  Game.prototype.run = function (action) {
    if (action === 'scan') this.openScanner();
    else if (action === 'manual') this.openManual();
    else if (action === 'spin') this.spin();
    else if (action === 'result') this.openResult(this.result);
  };
  Game.prototype.onCta = function () { RDC.sfx.unlock(); this.run(this.ctaAction); };
  Game.prototype.onAlt = function () { RDC.sfx.unlock(); this.run(this.altAction); };
  Game.prototype.onHub = function () {
    RDC.sfx.unlock();
    if (this.state === 'ready') this.spin();
    else if (this.state === 'locked') this.openScanner();
    else if (this.state === 'done') this.openResult(this.result);
  };

  /* ───── Ticket : scan, saisie, vérification ───── */
  Game.prototype.openScanner = function () {
    var self = this;
    RDC.Scanner.open({
      title: 'Scanner mon ticket',
      hint: 'Visez le QR code imprimé sur votre ticket.',
      accent: this.theme.c2,
      manualLabel: this.t.manual_btn || 'Saisir mon code',
      onResult: function (text) {
        var c = RDC.code.normalize(text);
        if (!c) return 'Ce QR code n’est pas un ticket de jeu. Visez le QR code de votre ticket.';
        RDC.sfx.beep();
        self.check(c);
        return true;
      },
      onManual: function () { self.openManual(); }
    });
  };

  Game.prototype.openManual = function () {
    var self = this;
    var input = h('input', { class: 'g-input g-input--code', id: 'g-code', type: 'text', inputmode: 'text', autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false', maxlength: '11', placeholder: 'XXXXX-XXXXX', 'aria-describedby': 'g-code-hint g-code-err', autofocus: true });
    var err = h('p', { class: 'g-err', id: 'g-code-err', role: 'alert' });
    var submit = h('button', { type: 'submit', class: 'g-btn g-btn--primary g-btn--block', html: RDC.icon('check') + '<span>Valider mon ticket</span>' });
    var form = h('form', { novalidate: true },
      h('label', { class: 'sr-only', for: 'g-code', text: 'Code du ticket' }),
      input,
      h('p', { class: 'g-hint', id: 'g-code-hint', style: { marginTop: '10px' }, text: 'Le code de 10 caractères est imprimé sous le QR code de votre ticket.' }),
      err, submit);
    input.addEventListener('input', function () {
      var pos = input.selectionStart, before = input.value.length;
      input.value = RDC.code.typing(input.value);
      if (pos !== null) { var np = pos + (input.value.length - before); try { input.setSelectionRange(np, np); } catch (e) { /* rien */ } }
      input.classList.remove('is-invalid'); err.textContent = '';
    });
    var m = RDC.modal({ title: 'Saisir mon code', content: form, width: '420px' });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var c = RDC.code.normalize(input.value);
      if (!c) {
        input.classList.add('is-invalid');
        err.textContent = input.value.replace(/[^A-Z0-9]/gi, '').length < 10 ? 'Le code doit compter 10 caractères.' : 'Code incorrect : vérifiez chaque caractère (il n’y a ni O, ni I, ni L, ni 0, ni 1).';
        input.focus();
        return;
      }
      RDC.sfx.unlock();
      m.close();
      self.check(c);
    });
  };

  Game.prototype.check = function (raw, fromUrl) {
    var self = this;
    var c = RDC.code.normalize(raw);
    if (!c) {
      this.setState('locked', { error: 'Ce code n’est pas valide. Scannez à nouveau votre ticket ou saisissez le code.' });
      return;
    }
    this.setState('checking');
    RDC.api('game.check', { p: this.slug, code: c }).then(function (r) {
      self.code = r.code;
      if (r.state === 'played') {
        self.result = r.result;
        var idx = self.wheel.indexOf(r.result.segment_id);
        if (idx >= 0) { self.wheel.showIndex(idx); self.wheel.highlight(idx); }
        self.wheel.setState(r.result.kind === 'lose' ? 'lose' : r.result.kind === 'jackpot' ? 'jackpot' : 'win');
        self.setState('done');
        self.renderMine();
        self.openResult(r.result, true);
        return;
      }
      self.setState('ready');
      RDC.sfx.unlockWheel();
      if (!fromUrl || window.innerWidth < 920) {
        var st = self.el.querySelector('.g-stage');
        if (st && st.scrollIntoView) st.scrollIntoView({ behavior: RDC.reducedMotion() ? 'auto' : 'smooth', block: 'center' });
      }
    }).catch(function (e) {
      RDC.sfx.error();
      self.code = null;
      self.setState('locked', { error: e.message });
    });
  };

  /* ───── Partie ───── */
  Game.prototype.spin = function () {
    var self = this;
    if (this.state !== 'ready' || !this.code) return;
    this.setState('spinning');
    this.wheel.setState('spinning');
    RDC.api('game.play', { p: this.slug, code: this.code }).then(function (r) {
      if (r.segments && self.changed(r.segments)) {
        self.boot.segments = r.segments;
        self.wheel.setSegments(r.segments);
      }
      var res = r.result;
      var idx = self.wheel.indexOf(res.segment_id);
      if (idx < 0) idx = 0;
      if (r.replay) { self.wheel.showIndex(idx); return res; }
      return self.wheel.spinTo(idx).then(function () { return res; });
    }).then(function (res) {
      self.finish(res);
    }).catch(function (e) {
      if (e.code === 'network' || e.code === 'server') {
        // La partie a peut-être été enregistrée : on revérifie le ticket pour retrouver le résultat.
        RDC.api('game.check', { p: self.slug, code: self.code }).then(function (r) {
          if (r.state === 'played') { self.finish(r.result); return; }
          self.setState('ready');
          RDC.toast('Connexion interrompue. Votre ticket reste valable : relancez la roue.', 'error');
        }).catch(function () {
          self.setState('ready');
          RDC.toast(e.message, 'error');
        });
        return;
      }
      RDC.sfx.error();
      self.code = null;
      self.setState('locked', { error: e.message });
    });
  };

  Game.prototype.changed = function (segs) {
    var cur = this.boot.segments || [];
    if (cur.length !== segs.length) return true;
    for (var i = 0; i < segs.length; i++) if (cur[i].id !== segs[i].id) return true;
    return false;
  };

  Game.prototype.finish = function (res) {
    var self = this;
    this.result = res;
    var idx = this.wheel.indexOf(res.segment_id);
    this.wheel.highlight(idx);
    var kind = res.kind;
    this.wheel.setState(kind === 'lose' ? 'lose' : kind === 'jackpot' ? 'jackpot' : 'win');
    this.setState('done');
    this.renderMine();
    if (kind === 'lose') RDC.sfx.lose();
    else if (kind === 'jackpot') RDC.sfx.jackpot();
    else RDC.sfx.win();
    if (kind !== 'lose' && this.o.confetti !== false) {
      RDC.fx.celebrate([this.theme.c1, this.theme.c2, this.theme.c3, '#FFFFFF'], kind === 'jackpot');
    }
    setTimeout(function () { self.openResult(res); }, kind === 'lose' ? 500 : 900);
  };

  Game.prototype.renderMine = function () {
    var r = this.result, self = this;
    RDC.clear(this.mineEl);
    if (!r || r.kind === 'lose') { this.mineEl.hidden = true; return; }
    var pz = r.prize || {};
    this.mineEl.hidden = false;
    this.mineEl.appendChild(pz.photo ? h('img', { src: RDC.asset(pz.photo), alt: '' }) : h('div', {}));
    this.mineEl.appendChild(h('div', { class: 'g-mine__txt' },
      h('p', { class: 'g-mine__label', text: r.status === 'delivered' ? 'Lot remis' : 'Votre lot à récupérer' }),
      h('p', { class: 'g-mine__name', text: pz.name + (pz.weight ? ' · ' + pz.weight : '') })));
    this.mineEl.appendChild(h('button', { type: 'button', text: 'Mon bon', onclick: function () { self.openResult(self.result); } }));
  };

  /* ───── Fenêtre de résultat ───── */
  Game.prototype.openResult = function (r, already) {
    if (!r) return;
    var t = this.t, self = this, o = this.o;
    var content;
    if (r.kind === 'lose') {
      content = h('div', { class: 'g-res is-lose' },
        h('div', { class: 'g-res__sad', html: RDC.icon('sad') }),
        h('p', { class: 'g-res__kicker', text: t.lose_title || 'Pas de chance…' }),
        h('p', { class: 'g-res__lead', text: t.lose_text || 'Vous avez perdu, à la prochaine fois !' }),
        already ? h('p', { class: 'g-res__when', text: 'Ticket ' + r.code + ' joué le ' + RDC.fmt.date(r.played_at) }) : null,
        h('div', { class: 'g-res__actions' },
          h('button', { type: 'button', class: 'g-btn g-btn--primary g-btn--block', html: RDC.icon('scan') + '<span>Jouer un autre ticket</span>', onclick: function () { m.close(); self.openScanner(); } })));
    } else {
      var pz = r.prize || {};
      var isJ = r.kind === 'jackpot';
      var meta = [pz.weight, o.show_values && pz.value ? pz.value : ''].filter(Boolean).join(' · ');
      var qr = '';
      try { qr = RDCQR.toSVG(RDC.url.ticket(r.code, this.boot.qr_base, this.slug, []), { ecl: 'M', margin: 2, className: 'g-voucher__qr', title: 'QR code du ticket ' + r.code }); } catch (e) { qr = ''; }
      var delivered = r.status === 'delivered';
      content = h('div', { class: 'g-res' + (isJ ? ' is-jackpot' : '') },
        h('div', { class: 'g-res__burst', 'aria-hidden': 'true' }),
        h('p', { class: 'g-res__kicker', text: isJ ? (t.jackpot_title || 'Grand prix !') : (t.win_title || 'Bravo !') }),
        h('p', { class: 'g-res__lead', text: isJ ? (t.jackpot_text || 'Vous remportez le grand prix') : (t.win_text || 'Vous avez gagné') }),
        pz.photo ? h('img', { class: 'g-res__photo', src: RDC.asset(pz.photo), alt: pz.name || '' }) : null,
        h('p', { class: 'g-res__prize', text: pz.name || '' }),
        meta ? h('p', { class: 'g-res__meta', text: meta }) : null,
        h('div', { class: 'g-voucher' },
          h('div', { class: 'g-voucher__head' },
            h('span', { class: 'g-voucher__title', text: 'Bon de gain' }),
            h('span', { class: 'g-voucher__status' + (delivered ? ' is-done' : ''), text: delivered ? 'Lot remis' : r.status === 'cancelled' ? 'Annulé' : 'À récupérer' })),
          h('p', { class: 'g-voucher__code', 'aria-label': 'Code du ticket ' + r.code, text: r.code }),
          h('div', { class: 'g-voucher__body' },
            h('dl', {},
              h('dt', { text: 'Jeu' }), h('dd', { text: (r.project && r.project.name) || this.boot.project.name }),
              h('dt', { text: 'Joué le' }), h('dd', { text: RDC.fmt.short(r.played_at) })),
            qr ? RDC.frag(qr) : null),
          h('p', { class: 'g-voucher__hint', text: delivered ? 'Ce lot vous a déjà été remis. Merci d’avoir joué' + NB + '!' : (t.voucher_hint || 'Présentez ce bon à votre livreur.') })),
        (!delivered && r.status !== 'cancelled' && o.ask_details !== false) ? this.claimBlock(r) : null,
        h('div', { class: 'g-res__actions' },
          h('button', { type: 'button', class: 'g-btn g-btn--block', text: 'Fermer', onclick: function () { m.close(); } })));
    }
    var m = RDC.modal({ content: content, width: '460px', label: 'Résultat', wrapClass: 'g-modal', focus: '.rdc-modal__close' });
  };

  Game.prototype.claimBlock = function (r) {
    var self = this, t = this.t, o = this.o;
    var box = h('div', {});
    function done() {
      RDC.clear(box);
      var c = self.boot.contact || {};
      box.appendChild(h('div', { class: 'g-claim__ok', role: 'status' }, RDC.iconEl('check'),
        h('div', {}, h('p', { text: t.claim_thanks || 'C’est noté !' }),
          h('p', { class: 'g-hint', style: { marginTop: '4px' }, text: 'Une erreur dans vos coordonnées ? ' + (c.phone ? 'Appelez-nous au ' + c.phone + '.' : 'Contactez-nous pour la corriger.') }))));
    }
    function form() {
      RDC.clear(box);
      var name = h('input', { class: 'g-input', id: 'c-name', name: 'name', autocomplete: 'name', required: true, maxlength: '80' });
      var phone = h('input', { class: 'g-input', id: 'c-phone', name: 'phone', type: 'tel', autocomplete: 'tel', inputmode: 'tel', maxlength: '30', required: o.require_phone !== false });
      var note = o.ask_address !== false ? h('textarea', { class: 'g-input', id: 'c-note', name: 'note', rows: '2', maxlength: '300', autocomplete: 'street-address' }) : null;
      var err = h('p', { class: 'g-err', role: 'alert' });
      var btn = h('button', { type: 'submit', class: 'g-btn g-btn--primary g-btn--block', text: 'Envoyer mes coordonnées' });
      var f = h('form', { class: 'g-claim', novalidate: true },
        h('p', { class: 'g-claim__title', text: t.claim_title || 'Où vous remettre votre lot ?' }),
        h('div', { class: 'g-field' }, h('label', { for: 'c-name', text: 'Nom et prénom' }), name),
        h('div', { class: 'g-field' }, h('label', { for: 'c-phone', text: 'Téléphone' + (o.require_phone === false ? ' (facultatif)' : '') }), phone),
        note ? h('div', { class: 'g-field' }, h('label', { for: 'c-note', text: 'Adresse ou précisions (facultatif)' }), note) : null,
        err, btn,
        h('p', { class: 'g-hint', style: { marginTop: '10px' }, text: t.claim_privacy || '' }));
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        err.textContent = '';
        RDC.busy(btn, RDC.api('game.claim', { p: self.slug, code: r.code, name: name.value, phone: phone.value, note: note ? note.value : '' }))
          .then(function () { r.claimed = true; if (self.result && self.result.code === r.code) self.result.claimed = true; done(); RDC.sfx.beep(); })
          .catch(function (ex) {
            err.textContent = ex.message;
            var fld = ex.data && ex.data.field;
            if (fld === 'name') name.focus(); else if (fld === 'phone') phone.focus();
          });
      });
      box.appendChild(f);
    }
    if (r.claimed) done(); else form();
    return box;
  };

  Game.prototype.openRules = function () {
    RDC.modal({ title: 'Règlement du jeu', content: h('div', { class: 'g-rules', text: this.t.rules }), width: '560px' });
  };

  RDC.apps.Game = {
    mount: function (root, boot) {
      var g = new Game(root, boot);
      return { app: g, destroy: function () { g.wheel.destroy(); RDC.closeAllModals(); } };
    }
  };
})();
