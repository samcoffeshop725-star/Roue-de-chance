/*!
 * Roue de la Chance — fabrication d'un fichier PDF, sans aucun service extérieur.
 * Tout est vectoriel : les QR codes restent parfaitement nets à l'impression, quelle que soit la taille.
 * Les polices du site (Bungee, Barlow, Barlow Condensed) sont embarquées dans le fichier.
 */
(function (root) {
  'use strict';

  /* ───── Texte : encodage WinAnsi (accents français inclus) ───── */
  var WIN = { 8364: 128, 8218: 130, 402: 131, 8222: 132, 8230: 133, 8224: 134, 8225: 135, 710: 136, 8240: 137, 352: 138,
    8249: 139, 338: 140, 381: 142, 8216: 145, 8217: 146, 8220: 147, 8221: 148, 8226: 149, 8211: 150, 8212: 151,
    732: 152, 8482: 153, 353: 154, 8250: 155, 339: 156, 382: 158, 376: 159 };
  var WINB = {};
  for (var u in WIN) WINB[WIN[u]] = +u;

  function winBytes(s) {
    var out = [];
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c === 160) c = 32;
      if (c < 128 || (c >= 160 && c <= 255)) out.push(c);
      else if (WIN[c] !== undefined) out.push(WIN[c]);
      else out.push(63); // '?'
    }
    return out;
  }

  /* ───── Lecture d'une police TTF : tailles des lettres, correspondance caractère → dessin ───── */
  function parseTTF(buf) {
    var dv = new DataView(buf);
    function u16(o) { return dv.getUint16(o); }
    function i16(o) { return dv.getInt16(o); }
    function u32(o) { return dv.getUint32(o); }
    var num = u16(4), tables = {};
    for (var i = 0; i < num; i++) {
      var o = 12 + i * 16;
      var tag = String.fromCharCode(dv.getUint8(o), dv.getUint8(o + 1), dv.getUint8(o + 2), dv.getUint8(o + 3));
      tables[tag] = { off: u32(o + 8), len: u32(o + 12) };
    }
    var head = tables.head.off, hhea = tables.hhea.off;
    var upem = u16(head + 18);
    var bbox = [i16(head + 36), i16(head + 38), i16(head + 40), i16(head + 42)];
    var ascent = i16(hhea + 4), descent = i16(hhea + 6);
    var numH = u16(hhea + 34);
    var capHeight = 0;
    if (tables['OS/2'] && u16(tables['OS/2'].off) >= 2) capHeight = i16(tables['OS/2'].off + 88);
    if (!capHeight) capHeight = Math.round(ascent * 0.72);
    // cmap : on prend la table Windows Unicode (format 4)
    var cm = tables.cmap.off, nSub = u16(cm + 2), best = 0;
    for (i = 0; i < nSub; i++) {
      var pid = u16(cm + 4 + i * 8), eid = u16(cm + 6 + i * 8), so = u32(cm + 8 + i * 8);
      if ((pid === 3 && (eid === 1 || eid === 10)) || (pid === 0)) { best = cm + so; if (pid === 3 && eid === 1) break; }
    }
    var glyphOf = function () { return 0; };
    if (best && u16(best) === 4) {
      var segX2 = u16(best + 6), ends = best + 14, starts = ends + segX2 + 2, deltas = starts + segX2, ranges = deltas + segX2;
      glyphOf = function (uc) {
        for (var s = 0; s < segX2; s += 2) {
          if (uc <= u16(ends + s)) {
            var st = u16(starts + s);
            if (uc < st) return 0;
            var ro = u16(ranges + s);
            if (!ro) return (uc + i16(deltas + s)) & 0xFFFF;
            var gi = u16(ranges + s + ro + (uc - st) * 2);
            return gi ? (gi + i16(deltas + s)) & 0xFFFF : 0;
          }
        }
        return 0;
      };
    }
    var hmtx = tables.hmtx.off;
    function advance(g) { return u16(hmtx + 4 * Math.min(g, numH - 1)); }
    var k = 1000 / upem;
    var widths = [];
    for (var b = 32; b <= 255; b++) {
      var uc = b < 128 ? b : (WINB[b] !== undefined ? WINB[b] : b);
      var g = glyphOf(uc);
      widths.push(Math.round(advance(g) * k));
    }
    return {
      bytes: new Uint8Array(buf), widths: widths,
      ascent: Math.round(ascent * k), descent: Math.round(descent * k),
      capHeight: Math.round(capHeight * k),
      bbox: bbox.map(function (v) { return Math.round(v * k); })
    };
  }

  /** Largeur d'un texte (en unités du document) pour une taille et un interlettrage donnés. */
  function measure(font, text, size, tc) {
    var bs = winBytes(text), w = 0;
    for (var i = 0; i < bs.length; i++) w += (font.widths[Math.max(0, bs[i] - 32)] || 500);
    return w * size / 1000 + (tc || 0) * Math.max(0, bs.length - 1);
  }

  /** Découpe un texte en lignes qui tiennent dans une largeur donnée. */
  function wrap(font, text, size, maxW) {
    var lines = [];
    String(text).split('\n').forEach(function (part) {
      var words = part.split(/\s+/).filter(Boolean);
      if (!words.length) return;
      var line = words[0];
      for (var i = 1; i < words.length; i++) {
        if (measure(font, line + ' ' + words[i], size) <= maxW) line += ' ' + words[i];
        else { lines.push(line); line = words[i]; }
      }
      lines.push(line);
    });
    return lines;
  }

  /* ───── Couleurs ───── */
  function rgb(hex) {
    var m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '').trim());
    var n = parseInt(m ? m[1] : '000000', 16);
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }
  function col(hex, op) { var c = rgb(hex); return c.map(function (v) { return +v.toFixed(4); }).join(' ') + ' ' + op; }
  function mix(a, b, t) {
    var x = rgb(a), y = rgb(b);
    var h = x.map(function (v, i) { return Math.round((v + (y[i] - v) * t) * 255); });
    return '#' + h.map(function (v) { return ('0' + v.toString(16)).slice(-2); }).join('');
  }

  /* ───── Écriture du fichier PDF ───── */
  function Doc() { this.objs = [null]; }
  Doc.prototype.add = function (o) { this.objs.push(o); return this.objs.length - 1; };
  Doc.prototype.set = function (id, o) { this.objs[id] = o; };

  function toBytes(s) {
    var out = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) out[i] = s.charCodeAt(i) & 255;
    return out;
  }

  /** Compression des flux quand le navigateur sait la faire (sinon le fichier reste valable, juste plus gros). */
  function deflate(bytes) {
    if (typeof CompressionStream === 'undefined') return Promise.resolve(null);
    try {
      var cs = new CompressionStream('deflate');
      var w = cs.writable.getWriter();
      w.write(bytes); w.close();
      return new Response(cs.readable).arrayBuffer().then(function (b) { return new Uint8Array(b); }, function () { return null; });
    } catch (e) { return Promise.resolve(null); }
  }

  Doc.prototype.build = function () {
    var objs = this.objs;
    var jobs = objs.map(function (o) {
      if (!o || o.stream === undefined) return Promise.resolve(o);
      var raw = typeof o.stream === 'string' ? toBytes(o.stream) : o.stream;
      if (o.raw) return Promise.resolve({ dict: o.dict, bytes: raw, filter: '' });
      return deflate(raw).then(function (z) {
        return (z && z.length < raw.length) ? { dict: o.dict, bytes: z, filter: ' /Filter /FlateDecode' } : { dict: o.dict, bytes: raw, filter: '' };
      });
    });
    return Promise.all(jobs).then(function (ready) {
      var parts = [], pos = 0, offsets = [];
      function push(s) { var b = typeof s === 'string' ? toBytes(s) : s; parts.push(b); pos += b.length; }
      push('%PDF-1.4\n%âãÏÓ\n');
      for (var i = 1; i < ready.length; i++) {
        offsets[i] = pos;
        var o = ready[i];
        if (o && o.bytes !== undefined) {
          push(i + ' 0 obj\n<< ' + (o.dict || '') + ' /Length ' + o.bytes.length + o.filter + ' >>\nstream\n');
          push(o.bytes);
          push('\nendstream\nendobj\n');
        } else {
          push(i + ' 0 obj\n' + o + '\nendobj\n');
        }
      }
      var xref = pos;
      push('xref\n0 ' + ready.length + '\n0000000000 65535 f \n');
      for (i = 1; i < ready.length; i++) push(('0000000000' + offsets[i]).slice(-10) + ' 00000 n \n');
      push('trailer\n<< /Size ' + ready.length + ' /Root 1 0 R >>\nstartxref\n' + xref + '\n%%EOF\n');
      var total = 0;
      parts.forEach(function (p) { total += p.length; });
      var out = new Uint8Array(total), at = 0;
      parts.forEach(function (p) { out.set(p, at); at += p.length; });
      return out;
    });
  };

  /* ───── Dessins ───── */
  var MM = 72 / 25.4;
  function n2(v) { return (Math.round(v * 100) / 100).toString(); }

  /** Tracé d'un rectangle à coins arrondis (x, y = coin bas-gauche). */
  function rrect(x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    var k = r * 0.5523;
    function pt() { return Array.prototype.slice.call(arguments).map(n2).join(' '); }
    return pt(x + r, y) + ' m ' +
      pt(x + w - r, y) + ' l ' + pt(x + w - r + k, y, x + w, y + r - k, x + w, y + r) + ' c ' +
      pt(x + w, y + h - r) + ' l ' + pt(x + w, y + h - r + k, x + w - r + k, y + h, x + w - r, y + h) + ' c ' +
      pt(x + r, y + h) + ' l ' + pt(x + r - k, y + h, x, y + h - r + k, x, y + h - r) + ' c ' +
      pt(x, y + r) + ' l ' + pt(x, y + r - k, x + r - k, y, x + r, y) + ' c h ';
  }

  function esc(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i++) {
      var c = bytes[i];
      if (c === 40 || c === 41 || c === 92) s += '\\' + String.fromCharCode(c);
      else if (c < 32 || c > 126) s += '\\' + ('00' + c.toString(8)).slice(-3);
      else s += String.fromCharCode(c);
    }
    return s;
  }

  /**
   * Planches de tickets → PDF.
   * o = { codes[], layout:{cols,rows,dir,qr,small}, style:'neon'|'light', theme:{bg1,bg2,c1,c3},
   *       title, subtitle, footer, urlOf(code), fmtCode(code), fonts:{title,code,text}(ArrayBuffer),
   *       logo: {pixels:ImageData}|null }
   */
  function ticketsPDF(o) {
    var F = { title: parseTTF(o.fonts.title), code: parseTTF(o.fonts.code), text: parseTTF(o.fonts.text) };
    var doc = new Doc();
    var catalog = doc.add(null), pagesObj = doc.add(null);
    var fontIds = {};
    Object.keys(F).forEach(function (k) {
      var f = F[k];
      var file = doc.add({ dict: '/Length1 ' + f.bytes.length, stream: f.bytes });
      var desc = doc.add('<< /Type /FontDescriptor /FontName /RDC' + k + ' /Flags 32 /FontBBox [' + f.bbox.join(' ') + ']' +
        ' /ItalicAngle 0 /Ascent ' + f.ascent + ' /Descent ' + f.descent + ' /CapHeight ' + f.capHeight + ' /StemV 82 /FontFile2 ' + file + ' 0 R >>');
      fontIds[k] = doc.add('<< /Type /Font /Subtype /TrueType /BaseFont /RDC' + k + ' /FirstChar 32 /LastChar 255 /Widths [' +
        f.widths.join(' ') + '] /FontDescriptor ' + desc + ' 0 R /Encoding /WinAnsiEncoding >>');
    });

    var neon = o.style !== 'light';
    var th = o.theme || {};
    var BG1 = th.bg1 || '#0E0630', BG2 = th.bg2 || '#3B0A6B', C1 = th.c1 || '#FF2E9A', C3 = th.c3 || '#FFD60A';
    var INK = neon ? '#FFF5FB' : '#1D1638';
    var MUT = neon ? mix('#FFF5FB', BG1, 0.22) : '#4A4366';

    var L = o.layout;
    var PW = 210, PH = 297, M = 8;
    var cw = (PW - 2 * M) / L.cols, chh = (PH - 2 * M) / L.rows;

    // Fond néon : halo de couleur en haut du ticket (dégradé circulaire)
    var shadeId = 0, resExtra = '';
    if (neon) {
      var fn = doc.add('<< /FunctionType 2 /Domain [0 1] /C0 [' + rgb(BG2).map(n2).join(' ') + '] /C1 [' + rgb(BG1).map(n2).join(' ') + '] /N 1 >>');
      shadeId = doc.add('<< /ShadingType 3 /ColorSpace /DeviceRGB /Coords [' + n2(cw / 2) + ' ' + n2(chh) + ' 0 ' + n2(cw / 2) + ' ' + n2(chh) + ' ' + n2(Math.max(cw, chh) * 0.95) + ']' +
        ' /Function ' + fn + ' 0 R /Extend [true true] >>');
      resExtra += ' /Shading << /Sh1 ' + shadeId + ' 0 R >>';
    }

    // Logo : image embarquée une seule fois (avec sa transparence)
    var logoId = 0, logoW = 0, logoH = 0;
    if (o.logo) {
      var px = o.logo, nPix = px.width * px.height;
      var rgbBuf = new Uint8Array(nPix * 3), aBuf = new Uint8Array(nPix);
      for (var i = 0; i < nPix; i++) {
        rgbBuf[i * 3] = px.data[i * 4]; rgbBuf[i * 3 + 1] = px.data[i * 4 + 1]; rgbBuf[i * 3 + 2] = px.data[i * 4 + 2];
        aBuf[i] = px.data[i * 4 + 3];
      }
      var smask = doc.add({ dict: '/Type /XObject /Subtype /Image /Width ' + px.width + ' /Height ' + px.height + ' /ColorSpace /DeviceGray /BitsPerComponent 8', stream: aBuf });
      logoId = doc.add({ dict: '/Type /XObject /Subtype /Image /Width ' + px.width + ' /Height ' + px.height + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /SMask ' + smask + ' 0 R', stream: rgbBuf });
      logoH = L.small ? 0 : 7;
      logoW = logoH * px.width / px.height;
      if (logoW > 28) { logoW = 28; logoH = logoW * px.height / px.width; }
      resExtra += ' /XObject << /Lg ' + logoId + ' 0 R >>';
    }

    var resources = '<< /Font << /Ft ' + fontIds.title + ' 0 R /Fc ' + fontIds.code + ' 0 R /Fx ' + fontIds.text + ' 0 R >>' + resExtra + ' >>';

    /* Un ticket : liste d'éléments empilés, centrés verticalement dans la case. */
    function ticketOps(code, x0, y0) {
      var pad = L.small ? 2.6 : 4;
      var innerW = cw - 2 * pad - (neon ? 3 : 4) - (L.dir === 'h' ? L.qr + 3 : 0);
      var ops = [];
      // Découpe (pointillés gris) + fond + liseré
      ops.push('q 0.709 0.678 0.788 RG 0.2 w [1.2 1.2] 0 d ' + n2(x0) + ' ' + n2(y0) + ' ' + n2(cw) + ' ' + n2(chh) + ' re S Q');
      if (neon) {
        ops.push('q ' + n2(x0) + ' ' + n2(y0) + ' ' + n2(cw) + ' ' + n2(chh) + ' re W n 1 0 0 1 ' + n2(x0) + ' ' + n2(y0) + ' cm /Sh1 sh Q');
        ops.push('q ' + col(C3, 'RG') + ' 1.15 w 1 J [0 2.5] 0 d ' + rrect(x0 + 1.5, y0 + 1.5, cw - 3, chh - 3, 3.2) + 'S Q');
      } else {
        ops.push('q 1 1 1 rg ' + n2(x0) + ' ' + n2(y0) + ' ' + n2(cw) + ' ' + n2(chh) + ' re f Q');
        ops.push('q ' + col(C1, 'RG') + ' 0.5 w ' + rrect(x0 + 2, y0 + 2, cw - 4, chh - 4, 3) + 'S Q');
      }

      var qrMM = L.qr;
      var gap = L.small ? 1.2 : 1.6;
      var codeSize = L.small ? 3.6 : 4.4, codeTc = codeSize * 0.12;
      var titleSize = L.small ? 3.1 : 4.2, subSize = 3, footSize = L.small ? 2.1 : 2.4;
      var textW = L.dir === 'v' ? cw - 2 * pad - 4 : innerW;
      var title = o.title ? wrap(F.title, o.title, titleSize, textW) : [];
      var sub = (!L.small && o.subtitle) ? wrap(F.text, o.subtitle, subSize, textW) : [];
      var foot = o.footer ? wrap(F.text, o.footer, footSize, textW) : [];
      var codeTxt = o.fmtCode(code);

      // Hauteurs empilées
      var items = [];
      if (logoId && !L.small && L.dir === 'v') items.push(['logo', logoH]);
      if (L.dir === 'v') {
        title.forEach(function (t) { items.push(['title', titleSize * 1.05, t]); });
        items.push(['qr', qrMM]);
        items.push(['code', codeSize * 1.1, codeTxt]);
        sub.forEach(function (t) { items.push(['sub', subSize * 1.25, t]); });
        foot.forEach(function (t) { items.push(['foot', footSize * 1.2, t]); });
      }

      function qrOps(qx, qyTop, size) {
        var out = [];
        var qr = RDCQR.encode(o.urlOf(code), { ecl: 'M' });
        var mTot = qr.size + 4; // marge de 2 modules de chaque côté
        var padQ = neon ? 0.8 : 0;
        // Carte blanche arrondie derrière le QR
        out.push('q 1 1 1 rg ' + rrect(qx - padQ, y0 + chh - (qyTop + size) - padQ, size + 2 * padQ, size + 2 * padQ, 2.2) + 'f Q');
        var mod = size / mTot;
        var rects = [];
        for (var yy = 0; yy < qr.size; yy++) {
          var xx = 0;
          while (xx < qr.size) {
            if (qr.modules[yy][xx]) {
              var st = xx;
              while (xx < qr.size && qr.modules[yy][xx]) xx++;
              var rx = qx + (st + 2) * mod;
              var ry = y0 + chh - (qyTop + (yy + 2 + 1) * mod);
              rects.push(n2(rx) + ' ' + n2(ry) + ' ' + n2((xx - st) * mod + 0.012) + ' ' + n2(mod + 0.012) + ' re');
            } else xx++;
          }
        }
        out.push('q 0 0 0 rg ' + rects.join(' ') + ' f Q');
        return out.join('\n');
      }

      if (L.dir === 'v') {
        var totalH = 0;
        items.forEach(function (it) { totalH += it[1]; });
        totalH += gap * (items.length - 1);
        var yTop = (chh - totalH) / 2; // depuis le haut de la case
        var cx = x0 + cw / 2;
        items.forEach(function (it) {
          var kind = it[0];
          if (kind === 'logo') {
            ops.push('q ' + n2(logoW) + ' 0 0 ' + n2(logoH) + ' ' + n2(cx - logoW / 2) + ' ' + n2(y0 + chh - yTop - logoH) + ' cm /Lg Do Q');
          } else if (kind === 'qr') {
            ops.push(qrOps(cx - qrMM / 2, yTop, qrMM));
          } else {
            var font = kind === 'title' ? 'Ft' : kind === 'code' ? 'Fc' : 'Fx';
            var fkey = kind === 'title' ? 'title' : kind === 'code' ? 'code' : 'text';
            var size = kind === 'title' ? titleSize : kind === 'code' ? codeSize : kind === 'sub' ? subSize : footSize;
            var tc = kind === 'code' ? codeTc : 0;
            var color = kind === 'title' ? (neon ? '#FFFFFF' : INK) : kind === 'code' ? (neon ? C3 : INK) : kind === 'foot' ? MUT : INK;
            if (kind === 'title' && neon) {
              ops.push('q 2 Tr ' + col(C1, 'RG') + ' ' + n2(size * 0.05) + ' w BT /Ft ' + n2(size) + ' Tf 0 Tc ' + col('#FFFFFF', 'rg') + ' ' +
                n2(x0 + cw / 2 - measure(F.title, it[2], size) / 2) + ' ' + n2(y0 + chh - yTop - size * 0.84) + ' Td (' + esc(winBytes(it[2])) + ') Tj ET Q');
            } else {
              var w = measure(F[fkey], it[2], size, tc);
              ops.push('BT /' + font + ' ' + n2(size) + ' Tf ' + n2(tc) + ' Tc ' + col(color, 'rg') + ' ' +
                n2(cx - w / 2) + ' ' + n2(y0 + chh - yTop - size * 0.84) + ' Td (' + esc(winBytes(it[2])) + ') Tj ET');
            }
          }
          var ih = it[1];
          yTop += ih + gap;
        });
      } else {
        // Horizontal : QR à gauche, textes à droite
        var qx = x0 + pad + (neon ? 1.6 : 0.8);
        var qy = (chh - qrMM) / 2;
        ops.push(qrOps(qx, qy, qrMM));
        var tx0 = qx + qrMM + (L.small ? 2.4 : 3) + (neon ? 0.8 : 0);
        var maxTw = x0 + cw - pad - (neon ? 1.6 : 0.8) - tx0;
        var lines = [];
        if (logoId && !L.small) lines.push(['logo', logoH]);
        title = o.title ? wrap(F.title, o.title, titleSize, maxTw) : [];
        sub = (!L.small && o.subtitle) ? wrap(F.text, o.subtitle, subSize, maxTw) : [];
        foot = o.footer ? wrap(F.text, o.footer, footSize, maxTw) : [];
        title.forEach(function (t) { lines.push(['title', titleSize * 1.05, t]); });
        lines.push(['code', codeSize * 1.15, codeTxt]);
        sub.forEach(function (t) { lines.push(['sub', subSize * 1.25, t]); });
        foot.forEach(function (t) { lines.push(['foot', footSize * 1.2, t]); });
        var tot = 0;
        lines.forEach(function (l) { tot += l[1]; });
        tot += 1 * (lines.length - 1);
        var ty = (chh - tot) / 2;
        lines.forEach(function (l) {
          if (l[0] === 'logo') {
            ops.push('q ' + n2(logoW) + ' 0 0 ' + n2(logoH) + ' ' + n2(tx0) + ' ' + n2(y0 + chh - ty - logoH) + ' cm /Lg Do Q');
          } else {
            var font = l[0] === 'title' ? 'Ft' : l[0] === 'code' ? 'Fc' : 'Fx';
            var fk = l[0] === 'title' ? 'title' : l[0] === 'code' ? 'code' : 'text';
            var size = l[0] === 'title' ? titleSize : l[0] === 'code' ? codeSize : l[0] === 'sub' ? subSize : footSize;
            var tc = l[0] === 'code' ? codeTc : 0;
            var color = l[0] === 'title' ? (neon ? '#FFFFFF' : INK) : l[0] === 'code' ? (neon ? C3 : INK) : l[0] === 'foot' ? MUT : INK;
            if (l[0] === 'title' && neon) {
              ops.push('q 2 Tr ' + col(C1, 'RG') + ' ' + n2(size * 0.05) + ' w BT /Ft ' + n2(size) + ' Tf 0 Tc 1 1 1 rg ' +
                n2(tx0) + ' ' + n2(y0 + chh - ty - size * 0.84) + ' Td (' + esc(winBytes(l[2])) + ') Tj ET Q');
            } else {
              ops.push('BT /' + font + ' ' + n2(size) + ' Tf ' + n2(tc) + ' Tc ' + col(color, 'rg') + ' ' +
                n2(tx0) + ' ' + n2(y0 + chh - ty - size * 0.84) + ' Td (' + esc(winBytes(l[2])) + ') Tj ET');
            }
          }
          ty += l[1] + 1;
        });
      }
      return ops.join('\n');
    }

    var per = L.cols * L.rows;
    var pageIds = [];
    for (var p = 0; p * per < o.codes.length; p++) {
      var ops = ['q ' + n2(MM) + ' 0 0 ' + n2(MM) + ' 0 0 cm'];
      var slice = o.codes.slice(p * per, (p + 1) * per);
      for (var s = 0; s < slice.length; s++) {
        var colI = s % L.cols, rowI = Math.floor(s / L.cols);
        ops.push(ticketOps(slice[s], M + colI * cw, PH - M - (rowI + 1) * chh));
      }
      ops.push('Q');
      var content = doc.add({ stream: ops.join('\n') });
      pageIds.push(doc.add('<< /Type /Page /Parent ' + pagesObj + ' 0 R /MediaBox [0 0 ' + n2(PW * MM) + ' ' + n2(PH * MM) + ']' +
        ' /Resources ' + resources + ' /Contents ' + content + ' 0 R >>'));
      if (o.onPage) o.onPage(p + 1);
    }
    doc.set(catalog, '<< /Type /Catalog /Pages ' + pagesObj + ' 0 R >>');
    doc.set(pagesObj, '<< /Type /Pages /Kids [' + pageIds.map(function (id) { return id + ' 0 R'; }).join(' ') + '] /Count ' + pageIds.length + ' >>');
    return doc.build();
  }

  root.RDCPDF = { tickets: ticketsPDF, _measure: measure, _parse: parseTTF, _win: winBytes };
})(typeof window !== 'undefined' ? window : globalThis);
