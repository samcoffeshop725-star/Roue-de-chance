/*!
 * Roue de la Chance — espace d'administration.
 * Tout ce qui concerne les tickets est centralisé (une seule réserve pour tous les projets) ;
 * chaque projet garde sa propre identité, ses produits et sa roue.
 */
(function () {
  'use strict';
  var RDC = window.RDC;
  var h = RDC.h;
  var NB = ' ';

  /* ════════════════ Composants de formulaire ════════════════ */
  var uid = 0;
  function nid(p) { uid++; return (p || 'f') + uid; }

  function field(label, input, hint, opts) {
    opts = opts || {};
    var id = input.id || (input.id = nid('in'));
    return h('div', { class: 'a-field' + (opts.class ? ' ' + opts.class : '') },
      label ? h('label', { for: id, text: label }) : null, input, hint ? h('p', { class: 'a-hint', text: hint }) : null);
  }
  function input(value, attrs) {
    var el = h('input', Object.assign({ class: 'a-input', type: 'text' }, attrs || {}));
    el.value = value == null ? '' : value;
    return el;
  }
  function textarea(value, attrs) {
    var el = h('textarea', Object.assign({ class: 'a-textarea', rows: '3' }, attrs || {}));
    el.value = value == null ? '' : value;
    return el;
  }
  function select(options, value, attrs) {
    var el = h('select', Object.assign({ class: 'a-select' }, attrs || {}));
    options.forEach(function (o) {
      var opt = h('option', { value: String(o[0]), text: o[1] });
      if (o[2]) opt.disabled = true;
      el.appendChild(opt);
    });
    el.value = String(value);
    return el;
  }
  function switchEl(label, checked, onChange, small) {
    var cb = h('input', { type: 'checkbox' });
    cb.checked = !!checked;
    cb.addEventListener('change', function () { onChange(cb.checked); });
    return h('label', { class: 'a-switch' }, cb, h('span', { class: 'a-switch__ui', 'aria-hidden': 'true' }),
      h('span', { class: 'a-switch__txt' }, h('span', { text: label }), small ? h('small', { text: small }) : null));
  }
  function colorEl(value, onChange) {
    var picker = h('input', { type: 'color', 'aria-label': 'Choisir la couleur' });
    var txt = input(value, { maxlength: '7', 'aria-label': 'Code couleur' });
    picker.value = value;
    picker.addEventListener('input', function () { txt.value = picker.value.toUpperCase(); onChange(txt.value); });
    txt.addEventListener('change', function () {
      var v = txt.value.trim();
      if (/^#?[0-9a-f]{6}$/i.test(v)) { v = (v[0] === '#' ? v : '#' + v).toUpperCase(); txt.value = v; picker.value = v; onChange(v); }
      else txt.value = picker.value.toUpperCase();
    });
    var box = h('div', { class: 'a-color' }, picker, txt);
    box.set = function (v) { picker.value = v; txt.value = v; };
    return box;
  }
  /** Champ image : aperçu, envoi par clic ou glisser-déposer, suppression. */
  function imageEl(o) {
    var value = o.value || '';
    var file = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp,image/gif', hidden: true });
    var pv = h('div', { class: 'a-image__pv' });
    var choose = h('button', { type: 'button', class: 'btn btn--sm', html: RDC.icon('upload') + '<span>' + (o.cta || 'Choisir une image') + '</span>' });
    var remove = h('button', { type: 'button', class: 'btn btn--sm btn--ghost btn--danger-ghost', html: RDC.icon('trash') + '<span>Retirer</span>' });
    var box = h('div', { class: 'a-image' + (o.dark ? ' a-image--dark' : '') + (o.cover ? ' a-image--cover' : '') }, pv,
      h('div', { class: 'a-image__acts' }, h('div', { class: 'a-row' }, choose, o.removable === false ? null : remove), o.hint ? h('p', { class: 'a-hint', text: o.hint }) : null), file);
    function paint() {
      RDC.clear(pv);
      if (value) pv.appendChild(h('img', { src: RDC.asset(value), alt: '' }));
      else pv.innerHTML = RDC.icon('image');
      remove.hidden = !value;
    }
    function send(f) {
      if (!f) return;
      if (!/^image\/(jpeg|png|webp|gif)$/.test(f.type)) { RDC.toast('Format non pris en charge : utilisez une image JPG, PNG, WebP ou GIF.', 'error'); return; }
      RDC.busy(choose, RDC.upload(f, o.kind || 'product')).then(function (r) {
        value = r.path; paint(); o.onChange(value);
      }, function (e) { RDC.toast(e.message, 'error'); });
    }
    choose.addEventListener('click', function () { file.click(); });
    file.addEventListener('change', function () { send(file.files[0]); file.value = ''; });
    remove.addEventListener('click', function () { value = ''; paint(); o.onChange(''); });
    ['dragenter', 'dragover'].forEach(function (ev) { box.addEventListener(ev, function (e) { e.preventDefault(); box.classList.add('is-drag'); }); });
    ['dragleave', 'drop'].forEach(function (ev) { box.addEventListener(ev, function (e) { e.preventDefault(); box.classList.remove('is-drag'); }); });
    box.addEventListener('drop', function (e) { if (e.dataTransfer && e.dataTransfer.files[0]) send(e.dataTransfer.files[0]); });
    paint();
    return box;
  }
  function badge(text, kind, icon) {
    return h('span', { class: 'a-badge' + (kind ? ' a-badge--' + kind : ''), html: (icon ? RDC.icon(icon) : '') + RDC.esc(text) });
  }
  function projDot(p) {
    var el = h('span', { class: 'a-dotp' }, h('i', {}), h('span', { text: p ? p.name : '—' }));
    if (p) el.style.setProperty('--pc', p.c1);
    return el;
  }
  function card(title, body, o) {
    o = o || {};
    return h('section', { class: 'a-card' + (o.class ? ' ' + o.class : ''), id: o.id || null },
      title || o.actions ? h('div', { class: 'a-card__head' }, title ? h('h2', { text: title }) : null, o.actions || null, o.desc ? h('p', { text: o.desc }) : null) : null,
      body);
  }
  function emptyBox(title, text, action) {
    return h('div', { class: 'a-empty' }, h('strong', { text: title }), text ? h('span', { text: text }) : null, action ? h('div', { style: { marginTop: '12px' } }, action) : null);
  }
  function btn(label, icon, onClick, cls, attrs) {
    return h('button', Object.assign({ type: 'button', class: 'btn' + (cls ? ' ' + cls : ''), html: (icon ? RDC.icon(icon) : '') + (label ? '<span>' + RDC.esc(label) + '</span>' : ''), onclick: onClick }, attrs || {}));
  }
  function iconBtn(icon, label, onClick, cls) {
    return h('button', { type: 'button', class: 'btn btn--sm btn--icon' + (cls ? ' ' + cls : ''), title: label, 'aria-label': label, html: RDC.icon(icon), onclick: onClick });
  }
  function linkBtn(label, icon, href, cls, newTab) {
    return h('a', { class: 'btn' + (cls ? ' ' + cls : ''), href: href, target: newTab ? '_blank' : null, rel: newTab ? 'noopener' : null, html: (icon ? RDC.icon(icon) : '') + '<span>' + RDC.esc(label) + '</span>' });
  }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function pct(n) { return RDC.fmt.pct(n); }

  var KIND = { product: 'Produit', jackpot: 'Grand prix', lose: 'Perdu' };
  var STATUS = { pending: ['À remettre', 'warn', 'gift'], delivered: ['Remis', 'ok', 'check'], cancelled: ['Annulé', 'err', 'close'], none: ['—', '', null] };
  var CODE_STATUS = { new: ['Disponible', 'info'], used: ['Joué', 'pri'], void: ['Désactivé', 'err'] };

  /** Verdict d'un ticket (mêmes règles que l'espace livreur). */
  function describeCode(r) {
    var res = r.result;
    if (r.status === 'void') return { tone: 'red', icon: 'close', title: 'Ticket désactivé : il ne peut plus être joué' };
    if (r.status === 'new') return { tone: 'blue', icon: 'ticket', title: 'Ticket valide, pas encore joué' };
    if (!res) return { tone: 'gray', icon: 'info', title: 'Ticket utilisé' };
    if (res.kind === 'lose') return { tone: 'gray', icon: 'sad', title: 'Joué : perdant' };
    if (res.status === 'pending') return { tone: 'green', icon: 'gift', title: (res.kind === 'jackpot' ? 'Grand prix gagné' : 'Lot gagné') + ' : à remettre' };
    if (res.status === 'delivered') return { tone: 'amber', icon: 'check', title: 'Lot déjà remis' };
    if (res.status === 'cancelled') return { tone: 'red', icon: 'close', title: 'Gain annulé' };
    return { tone: 'gray', icon: 'info', title: 'Statut inconnu' };
  }

  /* ════════════════ Application ════════════════ */
  function Admin(root, boot) {
    this.root = root;
    this.boot = boot;
    this.prefix = RDC.cfg.demo ? '#/admin' : '#';
    this.dirty = false;
    var self = this;
    RDC.onAuthLost = function () { self.showLogin('Votre session a expiré. Reconnectez-vous.'); };
    this.onHash = function () { self.route(); };
    this.onUnload = function (e) { if (self.dirty) { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', this.onUnload);
    var st = boot.state || {};
    this.phoneLogin = !!st.phone;   // connexion avec le numéro de téléphone + le mot de passe
    this.resetMode = !!st.reset;    // l'écran d'installation sert à réinitialiser un accès existant
    if (st.authed) this.load();
    else if (st.setup) this.showSetup();
    else this.showLogin();
  }

  Admin.prototype.href = function (path) { return this.prefix + path; };
  Admin.prototype.navigate = function (path) { location.hash = this.href(path); };

  /* ───── Installation & connexion ───── */
  Admin.prototype.authScreen = function (title, sub, fields, submitLabel, onSubmit) {
    RDC.clear(this.root);
    window.removeEventListener('hashchange', this.onHash);
    var err = h('p', { class: 'a-err', role: 'alert' });
    var go = h('button', { type: 'submit', class: 'btn btn--primary', text: submitLabel });
    var form = h('form', { class: 'a-auth__box', novalidate: true },
      h('h1', { class: 'a-auth__t', text: title }), h('p', { class: 'a-auth__s', text: sub }), fields, err, go);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      err.textContent = '';
      var p = onSubmit(err);
      if (p) RDC.busy(go, p).catch(function (ex) { err.textContent = ex.message; });
    });
    this.root.appendChild(h('div', { class: 'a-auth' }, form));
    var first = RDC.$('input', form);
    if (first) first.focus();
  };

  Admin.prototype.showSetup = function () {
    var self = this, reset = this.resetMode;
    var key = input('', { autocomplete: 'off', spellcheck: 'false' });
    var phone = input('', { type: 'tel', inputmode: 'tel', autocomplete: 'username', placeholder: '+212 6 12 34 56 78', maxlength: '24' });
    var pw = input('', { type: 'password', autocomplete: 'new-password', minlength: '8' });
    var pw2 = input('', { type: 'password', autocomplete: 'new-password' });
    this.authScreen(reset ? 'Nouveau mot de passe' : 'Bienvenue',
      reset ? 'Réinitialisation de l’accès administrateur. Elle n’est possible qu’une fois : remettez ensuite reset_admin à false dans config.php.'
        : 'Créez votre accès à l’administration. Cette étape n’a lieu qu’une fois.',
      h('div', { class: 'a-stack' },
        field('Clé d’installation', key, 'Elle figure dans le fichier config.php (ligne install_key) et dans le guide d’installation.'),
        field('Numéro de téléphone (identifiant)', phone, reset ? 'Laissez vide pour garder le numéro actuel.' : 'Avec l’indicatif du pays. Il vous servira à vous connecter.'),
        field('Mot de passe administrateur', pw, '8 caractères minimum.'),
        field('Confirmez le mot de passe', pw2)),
      reset ? 'Enregistrer le nouveau mot de passe' : 'Créer l’accès administrateur',
      function (err) {
        if (pw.value.length < 8) { err.textContent = 'Le mot de passe doit compter au moins 8 caractères.'; return null; }
        if (pw.value !== pw2.value) { err.textContent = 'Les deux mots de passe ne sont pas identiques.'; return null; }
        return RDC.api('adm.setup', { install_key: key.value, phone: phone.value, password: pw.value }).then(function () {
          if (phone.value.trim()) self.phoneLogin = true;
          self.load();
        });
      });
  };

  Admin.prototype.showLogin = function (msg) {
    var self = this;
    RDC.closeAllModals();
    this.setDirty(false);
    var phone = this.phoneLogin ? input('', { type: 'tel', inputmode: 'tel', autocomplete: 'username', placeholder: '+212 6 12 34 56 78', maxlength: '24' }) : null;
    var pw = input('', { type: 'password', autocomplete: 'current-password' });
    this.authScreen('Administration', msg || 'Roue de la chance : gestion de vos projets, tickets et lots.',
      h('div', { class: 'a-stack' }, phone ? field('Numéro de téléphone', phone) : null, field('Mot de passe', pw)), 'Se connecter',
      function (err) {
        if (phone && !phone.value.trim()) { err.textContent = 'Indiquez votre numéro de téléphone.'; return null; }
        return RDC.api('adm.login', { phone: phone ? phone.value : '', password: pw.value }).then(function () { self.load(); });
      });
  };

  Admin.prototype.load = function () {
    var self = this;
    RDC.clear(this.root);
    this.root.appendChild(h('div', { class: 'a-loading', html: '<span class="rdc-spinner"></span>' }));
    return RDC.api('adm.boot').then(function (b) {
      self.data = b;
      RDC.cfg.publicBase = b.public_base;
      self.renderShell();
      window.removeEventListener('hashchange', self.onHash);
      window.addEventListener('hashchange', self.onHash);
      self.route();
      self.refreshPendingBadge();
    }, function (e) {
      if (e.code === 'auth') self.showLogin();
      else { RDC.clear(self.root); self.root.appendChild(h('div', { class: 'a-loading', text: e.message })); }
    });
  };

  Admin.prototype.project = function (id) {
    var list = (this.data && this.data.projects) || [];
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  };

  /* ───── Structure (menu + zone principale) ───── */
  Admin.prototype.renderShell = function () {
    var self = this;
    RDC.clear(this.root);
    this.nav = h('nav', { class: 'a-nav', 'aria-label': 'Menu principal' });
    this.main = h('main', { class: 'a-main', id: 'a-main' });
    this.side = h('aside', { class: 'a-side' },
      h('a', { class: 'a-logo', href: this.href('/') }, h('img', { class: 'a-logo__mark', src: RDC.asset('assets/img/favicon.svg'), alt: '' }),
        h('span', { class: 'a-logo__t' }, 'Roue de la chance', h('span', { class: 'a-logo__s', text: 'Administration' }))),
      this.nav,
      h('div', { class: 'a-side__foot a-nav' },
        h('a', { href: RDC.url.livreur(), target: RDC.cfg.demo ? null : '_blank', rel: 'noopener', html: RDC.icon('truck') + '<span>Espace livreur</span>' }),
        RDC.cfg.demo ? null : h('a', { href: '#', html: RDC.icon('logout') + '<span>Se déconnecter</span>', onclick: function (e) { e.preventDefault(); self.logout(); } })));
    this.scrim = h('div', { class: 'a-scrim', hidden: true, onclick: function () { self.menu(false); } });
    this.shell = h('div', { class: 'a-shell' },
      this.side, this.scrim,
      h('div', { class: 'a-body' },
        h('div', { class: 'a-mtop' }, iconBtn('menu', 'Ouvrir le menu', function () { self.menu(true); }), h('span', { class: 'a-mtop__t', text: 'Administration' })),
        this.main));
    this.root.appendChild(this.shell);
    this.paintNav();
  };

  Admin.prototype.menu = function (open) {
    this.shell.classList.toggle('is-menu', open);
    this.scrim.hidden = !open;
  };

  Admin.prototype.paintNav = function () {
    var self = this;
    RDC.clear(this.nav);
    var cur = this.current || '/';
    var item = function (path, icon, label, extra) {
      var active = cur === path || (path !== '/' && cur.indexOf(path + '/') === 0);
      var a = h('a', { href: self.href(path), class: active ? 'is-active' : '', html: RDC.icon(icon) + '<span>' + RDC.esc(label) + '</span>', 'aria-current': active ? 'page' : null });
      if (extra) a.appendChild(extra);
      return a;
    };
    this.pendingBadge = h('span', { class: 'a-nav__badge', hidden: !this.pending, text: String(this.pending || 0) });
    this.nav.appendChild(item('/', 'dashboard', 'Tableau de bord'));
    this.nav.appendChild(item('/tickets', 'ticket', 'Tickets & QR codes'));
    this.nav.appendChild(item('/gains', 'gift', 'Gains & remises', this.pendingBadge));
    this.nav.appendChild(item('/livreurs', 'truck', 'Livreurs'));
    this.nav.appendChild(h('p', { class: 'a-nav__h' }, h('span', { text: 'Vos projets' }), h('button', { type: 'button', title: 'Nouveau projet', 'aria-label': 'Nouveau projet', html: RDC.icon('plus'), onclick: function () { self.newProject(); } })));
    (this.data.projects || []).forEach(function (p) {
      var dot = p.logo ? h('img', { class: 'a-nav__proj', src: RDC.asset(p.logo), alt: '' }) : h('i', { class: 'a-nav__proj' });
      dot.style.setProperty('--pc', p.c1);
      var a = h('a', { href: self.href('/projet/' + p.id), class: cur.indexOf('/projet/' + p.id + '/') === 0 || cur === '/projet/' + p.id ? 'is-active' : '' }, dot, h('span', { text: p.name }));
      if (!p.active) a.appendChild(h('span', { class: 'a-nav__off', text: 'fermé' }));
      self.nav.appendChild(a);
    });
    this.nav.appendChild(item('/projets', 'grid', 'Gérer les projets'));
    this.nav.appendChild(h('p', { class: 'a-nav__h', text: 'Réglages' }));
    this.nav.appendChild(item('/parametres', 'settings', 'Paramètres'));
    this.nav.appendChild(item('/aide', 'info', 'Aide & mode d’emploi'));
  };

  Admin.prototype.refreshPendingBadge = function () {
    var self = this;
    RDC.api('adm.plays.list', { status: 'pending' }).then(function (r) {
      self.pending = r.total;
      if (self.pendingBadge) { self.pendingBadge.textContent = String(r.total); self.pendingBadge.hidden = !r.total; }
    }, function () {});
  };

  Admin.prototype.logout = function () {
    var self = this;
    RDC.api('adm.logout').then(function () { self.showLogin('Vous êtes déconnecté.'); }, function () { self.showLogin(); });
  };

  /* ───── Navigation ───── */
  Admin.prototype.route = function () {
    var self = this;
    var hash = location.hash || '';
    var path = hash.indexOf(this.prefix) === 0 ? hash.slice(this.prefix.length) : '/';
    if (!path || path[0] !== '/') path = '/' + path;
    path = path.replace(/\/+$/, '') || '/';
    if (this.dirty && path !== this.current) {
      if (this.ignoreHash) { this.ignoreHash = false; return; }
      var target = path;
      RDC.confirm({ title: 'Quitter sans enregistrer ?', message: 'Vos dernières modifications ne sont pas enregistrées.', confirm: 'Quitter sans enregistrer', danger: true, cancel: 'Rester' })
        .then(function (ok) {
          if (ok) { self.setDirty(false); self.current = null; self.go(target); }
          else { self.ignoreHash = true; location.hash = self.href(self.current); }
        });
      return;
    }
    this.go(path);
  };

  Admin.prototype.go = function (path) {
    var self = this;
    this.current = path;
    this.menu(false);
    this.setDirty(false);
    if (this.previewWheel) { this.previewWheel.destroy(); this.previewWheel = null; }
    this.paintNav();
    RDC.clear(this.main);
    window.scrollTo(0, 0);
    var parts = path.split('/').filter(Boolean);
    var p = parts[0] || '';
    try {
      if (p === '' || p === 'tableau') this.pageDashboard();
      else if (p === 'tickets') this.pageCodes();
      else if (p === 'gains') this.pageGains(parts[1]);
      else if (p === 'livreurs') this.pageLivreurs();
      else if (p === 'projets') this.pageProjects();
      else if (p === 'projet') this.pageProject(parseInt(parts[1], 10), parts[2] || 'identite');
      else if (p === 'parametres') this.pageSettings();
      else if (p === 'aide') this.pageHelp();
      else this.pageDashboard();
    } catch (e) {
      self.main.appendChild(h('p', { class: 'a-err', text: 'Erreur d’affichage : ' + e.message }));
      if (window.console) console.error(e);
    }
  };

  Admin.prototype.head = function (title, desc, actions) {
    return h('div', { class: 'a-page-head' }, h('div', { class: 'a-page-head__txt' }, h('h1', { text: title }), desc ? h('p', { text: desc }) : null), actions || null);
  };
  Admin.prototype.loading = function () { var l = h('div', { class: 'a-loading', html: '<span class="rdc-spinner"></span>' }); this.main.appendChild(l); return l; };
  Admin.prototype.fail = function (box, e) { RDC.clear(box); box.appendChild(h('p', { class: 'a-err', text: e.message })); };

  /* ───── Barre d'enregistrement ───── */
  Admin.prototype.setDirty = function (on, save, reset) {
    var self = this;
    this.dirty = !!on;
    if (on) { this.saveFn = save || this.saveFn; this.resetFn = reset || this.resetFn; }
    if (!on) { if (this.savebar) { this.savebar.remove(); this.savebar = null; } return; }
    if (this.savebar) return;
    var saveBtn = h('button', { type: 'button', class: 'btn btn--primary', html: RDC.icon('check') + '<span>Enregistrer</span>' });
    saveBtn.addEventListener('click', function () {
      RDC.busy(saveBtn, Promise.resolve(self.saveFn && self.saveFn())).then(function () {}, function (e) { RDC.toast(e.message, 'error'); });
    });
    this.savebar = h('div', { class: 'a-savebar', role: 'region', 'aria-label': 'Modifications non enregistrées' },
      h('span', { text: 'Modifications non enregistrées' }),
      h('button', { type: 'button', class: 'btn btn--ghost', text: 'Annuler', onclick: function () { if (self.resetFn) self.resetFn(); } }),
      saveBtn);
    document.body.appendChild(this.savebar);
  };

  /* ════════════════ Tableau de bord ════════════════ */
  Admin.prototype.pageDashboard = function () {
    var self = this;
    this.main.appendChild(this.head('Tableau de bord', 'Vue d’ensemble de vos ' + this.data.projects.length + ' projets et de la réserve commune de tickets.',
      h('div', { class: 'a-row' }, btn('Générer des tickets', 'plus', function () { self.navigate('/tickets'); setTimeout(function () { self.generateModal(); }, 50); }, 'btn--primary'))));
    var box = this.loading();
    RDC.api('adm.dashboard').then(function (d) {
      box.remove();
      var c = d.codes, p = d.plays;
      self.pending = p.pending;
      if (self.pendingBadge) { self.pendingBadge.textContent = String(p.pending); self.pendingBadge.hidden = !p.pending; }
      if (d.storage === false) {
        self.main.appendChild(h('div', { class: 'a-alert a-alert--err', style: { marginBottom: '12px' } }, RDC.iconEl('warning'),
          h('div', {}, h('strong', { text: 'Stockage temporaire : vos données seront effacées' }),
            h('p', { text: 'Aucun disque permanent n’est branché : au prochain redémarrage du serveur, les tickets, les parties et les photos disparaîtront (et les tickets joués redeviendraient jouables). Sur Render, ajoutez un disque de 1 Go monté sur /var/data (onglet « Disks »), sur une offre payante.' }))));
      }
      if (d.default_password) {
        self.main.appendChild(h('div', { class: 'a-alert a-alert--warn', style: { marginBottom: '12px' } }, RDC.iconEl('warning'),
          h('div', {}, h('strong', { text: 'Vous utilisez encore le mot de passe de départ' }),
            h('p', { text: 'Choisissez votre propre mot de passe dans Paramètres, carte « Accès administrateur ». Vous pourrez le changer de nouveau quand vous voulez.' }),
            h('div', { style: { marginTop: '8px' } }, btn('Changer le mot de passe', 'settings', function () { self.navigate('/parametres'); }, 'btn--sm')))));
      }
      (d.alerts || []).forEach(function (al) {
        self.main.appendChild(h('div', { class: 'a-alert a-alert--err', style: { marginBottom: '12px' } }, RDC.iconEl('shield'),
          h('div', {}, h('strong', { text: RDC.fmt.date(al.at.replace(' ', 'T') + 'Z') }), h('p', { text: al.msg }))));
      });
      self.main.appendChild(h('div', { class: 'a-kpis' },
        h('a', { class: 'a-kpi', href: self.href('/tickets') }, h('span', { class: 'a-kpi__l', text: 'Tickets disponibles' }), h('span', { class: 'a-kpi__v', text: RDC.fmt.num(c.fresh) }),
          h('span', { class: 'a-kpi__s', text: RDC.fmt.num(c.total) + ' émis, ' + RDC.fmt.num(c.used) + ' joués' })),
        h('div', { class: 'a-kpi' }, h('span', { class: 'a-kpi__l', text: 'Parties aujourd’hui' }), h('span', { class: 'a-kpi__v', text: RDC.fmt.num(p.today) }),
          h('span', { class: 'a-kpi__s', text: RDC.fmt.num(p.total) + ' depuis le début' })),
        h('a', { class: 'a-kpi' + (p.pending ? ' a-kpi--alert' : ''), href: self.href('/gains/a-remettre') }, h('span', { class: 'a-kpi__l', text: 'Lots à remettre' }), h('span', { class: 'a-kpi__v', text: RDC.fmt.num(p.pending) }),
          h('span', { class: 'a-kpi__s', text: RDC.fmt.num(p.delivered) + ' déjà remis' })),
        h('div', { class: 'a-kpi' }, h('span', { class: 'a-kpi__l', text: 'Gains' }), h('span', { class: 'a-kpi__v', text: RDC.fmt.num(p.wins) }),
          h('span', { class: 'a-kpi__s', text: RDC.fmt.plural(p.jackpots, 'grand prix', 'grands prix') + (p.total ? ', ' + Math.round(p.wins / p.total * 100) + NB + '% des parties' : '') }))));

      // Graphique
      var max = Math.max.apply(null, d.series.map(function (s) { return s.plays; }).concat([1]));
      var bars = h('div', { class: 'a-bars', role: 'img', 'aria-label': 'Parties par jour sur 14 jours' });
      var xs = h('div', { class: 'a-bars-x', 'aria-hidden': 'true' });
      d.series.forEach(function (s, i) {
        var hgt = Math.round(s.plays / max * 100);
        bars.appendChild(h('div', { class: 'a-bar' + (i === d.series.length - 1 ? ' is-today' : ''), title: s.day + ' : ' + s.plays + ' parties' },
          h('span', { class: 'a-bar__n', style: { bottom: 'calc(' + hgt + '% + 4px)' }, text: s.plays ? String(s.plays) : '' }),
          h('div', { class: 'a-bar__fill', style: { height: hgt + '%' } })));
        var dd = new Date(s.day + 'T12:00:00');
        xs.appendChild(h('span', { text: i === d.series.length - 1 ? 'auj.' : String(dd.getDate()) }));
      });
      var recent = d.recent.length ? h('div', { class: 'a-recent' }, d.recent.map(function (r) {
        var proj = r.project ? self.project(r.project.id) || r.project : null;
        return h('div', { class: 'a-recent__row' },
          r.prize && r.prize.photo ? h('img', { class: 'a-thumb', src: RDC.asset(r.prize.photo), alt: '' }) : h('span', { class: 'a-thumb', style: { display: 'grid', placeItems: 'center' }, html: RDC.icon(r.kind === 'lose' ? 'sad' : 'gift') }),
          h('div', { style: { minWidth: '0' } },
            h('div', { style: { fontWeight: '700' }, text: r.kind === 'lose' ? 'Perdu' : (r.kind === 'jackpot' ? 'Grand prix : ' : '') + (r.prize ? r.prize.name : '') }),
            h('div', { class: 'a-small a-muted' }, projDot(proj), NB + NB + r.code)),
          h('span', { class: 'a-small a-muted a-nowrap', text: RDC.fmt.relative(r.played_at) }));
      })) : emptyBox('Aucune partie pour l’instant', 'Les parties apparaîtront ici dès que vos clients joueront.');

      var projRows = h('div', { class: 'a-recent' }, d.projects.map(function (pr) {
        return h('a', { class: 'a-recent__row', href: self.href('/projet/' + pr.id), style: { textDecoration: 'none', color: 'inherit' } },
          projDot(pr),
          h('span', { class: 'a-small a-muted', text: RDC.fmt.plural(pr.stats.today, 'partie', 'parties') + ' aujourd’hui, ' + RDC.fmt.num(pr.stats.plays) + ' au total' }),
          !pr.active ? badge('Fermé', '') : pr.stats.pending ? badge(pr.stats.pending + ' à remettre', 'warn') : badge('Ouvert', 'ok'));
      }));
      var low = d.low_stock.length ? card('Stocks bas', h('div', { class: 'a-recent' }, d.low_stock.map(function (l) {
        return h('a', { class: 'a-recent__row', href: self.href('/projet/' + l.project_id + '/produits'), style: { textDecoration: 'none', color: 'inherit' } },
          l.photo ? h('img', { class: 'a-thumb', src: RDC.asset(l.photo), alt: '' }) : h('span', {}),
          h('div', {}, h('div', { style: { fontWeight: '700' }, text: l.name + ' ' + l.weight }), h('div', { class: 'a-small a-muted', text: l.project })),
          badge(l.stock ? l.stock + ' restant' + (l.stock > 1 ? 's' : '') : 'Épuisé', l.stock ? 'warn' : 'err'));
      })), { desc: 'Une case dont le lot est épuisé ne peut plus être gagnée.' }) : null;

      self.main.appendChild(h('div', { class: 'a-two' },
        h('div', { class: 'a-stack' },
          card('Parties des 14 derniers jours', h('div', {}, bars, xs)),
          card('Activité récente', recent, { actions: linkBtn('Tout voir', null, self.href('/gains'), 'btn--sm') })),
        h('div', { class: 'a-stack' },
          card('Vos projets', projRows, { actions: linkBtn('Gérer', null, self.href('/projets'), 'btn--sm') }),
          low,
          card('Accès rapides', h('div', { class: 'a-row' },
            linkBtn('Espace livreur', 'truck', RDC.url.livreur(), '', !RDC.cfg.demo),
            linkBtn('Lots à remettre', 'gift', self.href('/gains/a-remettre')),
            linkBtn('Imprimer des tickets', 'print', self.href('/tickets')))))));
    }, function (e) { self.fail(box, e); });
  };

  /* ════════════════ Tickets & QR codes ════════════════ */
  Admin.prototype.pageCodes = function () {
    var self = this;
    this.main.appendChild(this.head('Tickets & QR codes',
      'Une seule réserve de tickets pour tous vos projets : dès qu’un ticket est joué sur un projet, il devient invalide sur tous les autres.',
      h('div', { class: 'a-row' }, btn('Générer des tickets', 'plus', function () { self.generateModal(); }, 'btn--primary'))));
    this.codesSummary = h('div', {});
    this.main.appendChild(this.codesSummary);
    var lookupBox = h('div', { 'aria-live': 'polite' });
    var lk = input('', { class: 'a-input a-input--code', placeholder: 'XXXXX-XXXXX', maxlength: '11', 'aria-label': 'Code du ticket' });
    lk.addEventListener('input', function () { lk.value = RDC.code.typing(lk.value); });
    var lkBtn = h('button', { type: 'submit', class: 'btn btn--primary', text: 'Vérifier' });
    var lkForm = h('form', { class: 'a-row', novalidate: true }, h('div', { style: { flex: '1', minWidth: '200px' } }, lk), lkBtn);
    lkForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var c = RDC.code.normalize(lk.value);
      if (!c) { RDC.clear(lookupBox); lookupBox.appendChild(h('div', { class: 'a-alert a-alert--err', html: RDC.icon('warning') + '<span>Code mal saisi : vérifiez les 10 caractères (sans O, I, L, 0 ni 1).</span>' })); return; }
      RDC.busy(lkBtn, RDC.api('adm.codes.lookup', { code: c })).then(function (r) { self.showCodeVerdict(lookupBox, r); }, function (ex) {
        RDC.clear(lookupBox); lookupBox.appendChild(h('div', { class: 'a-alert a-alert--err', html: RDC.icon('warning') + '<span>' + RDC.esc(ex.message) + '</span>' }));
      });
    });
    var lookupCard = card('Vérifier un ticket', h('div', { class: 'a-stack' }, lkForm, lookupBox), { desc: 'Retrouvez l’état d’un ticket, où il a été joué et ce qu’il a gagné. Vous pouvez aussi désactiver un ticket perdu ou volé.' });

    this.codesList = h('div', {});
    this.main.appendChild(h('div', { class: 'a-stack' }, this.batchesCard = h('div', {}), lookupCard, this.codesList));
    this.loadCodes();
  };

  Admin.prototype.loadCodes = function () {
    var self = this;
    RDC.api('adm.codes.summary').then(function (s) {
      self.codeData = s;
      var t = s.totals;
      RDC.clear(self.codesSummary);
      var per = (self.data.projects || []).map(function (p) { return h('span', { class: 'a-small' }, projDot(p), NB + '·' + NB + RDC.fmt.num(s.by_project[String(p.id)] || 0)); });
      self.codesSummary.appendChild(h('div', { class: 'a-kpis' },
        h('div', { class: 'a-kpi' }, h('span', { class: 'a-kpi__l', text: 'Disponibles' }), h('span', { class: 'a-kpi__v', text: RDC.fmt.num(t.fresh) }), h('span', { class: 'a-kpi__s', text: 'prêts à être joués sur n’importe quel projet' })),
        h('div', { class: 'a-kpi' }, h('span', { class: 'a-kpi__l', text: 'Joués' }), h('span', { class: 'a-kpi__v', text: RDC.fmt.num(t.used) }), h('div', { class: 'a-row', style: { gap: '4px 12px' } }, per)),
        h('div', { class: 'a-kpi' }, h('span', { class: 'a-kpi__l', text: 'Émis au total' }), h('span', { class: 'a-kpi__v', text: RDC.fmt.num(t.total) }), h('span', { class: 'a-kpi__s', text: RDC.fmt.num(t.void) + ' désactivés' }))));
      self.paintBatches();
      self.loadCodeList(1);
    }, function (e) { self.fail(self.codesSummary, e); });
  };

  Admin.prototype.paintBatches = function () {
    var self = this;
    var s = this.codeData;
    RDC.clear(this.batchesCard);
    var body;
    if (!s.batches.length) body = emptyBox('Aucune série de tickets', 'Générez votre première série pour l’imprimer et la distribuer.', btn('Générer des tickets', 'plus', function () { self.generateModal(); }, 'btn--primary'));
    else {
      body = h('div', { class: 'a-table-wrap' }, h('table', { class: 'a-table' },
        h('thead', {}, h('tr', {}, ['Série', 'Créée le', 'Total', 'Disponibles', 'Joués', 'Désactivés', ''].map(function (x, i) { return h('th', { class: i > 1 && i < 6 ? 'num' : '', text: x }); }))),
        h('tbody', {}, s.batches.map(function (b) {
          var menu = h('div', { class: 'a-row', style: { justifyContent: 'flex-end', flexWrap: 'nowrap' } },
            linkBtn('Imprimer', 'print', RDC.url.print(b.id), 'btn--sm', !RDC.cfg.demo),
            iconBtn('download', 'Exporter la liste (CSV)', function () { RDC.download('adm.export.codes', { batch: b.id }); }),
            iconBtn('edit', 'Renommer la série', function () { self.renameBatch(b); }),
            b.fresh ? iconBtn('lock', 'Désactiver les tickets restants', function () { self.voidBatch(b); }) : null,
            !b.used ? iconBtn('trash', 'Supprimer la série', function () { self.deleteBatch(b); }, 'btn--danger-ghost') : null);
          return h('tr', {},
            h('td', {}, h('strong', { text: b.label })),
            h('td', { class: 'a-nowrap a-muted', text: RDC.fmt.date(b.created_at, false) }),
            h('td', { class: 'num', text: RDC.fmt.num(b.total) }),
            h('td', { class: 'num', text: RDC.fmt.num(b.fresh) }),
            h('td', { class: 'num', text: RDC.fmt.num(b.used) }),
            h('td', { class: 'num', text: RDC.fmt.num(b.void) }),
            h('td', {}, menu));
        }))));
    }
    this.batchesCard.appendChild(card('Séries de tickets', body, { desc: 'Chaque série regroupe des tickets générés ensemble, pour les imprimer ou les exporter vers un imprimeur.' }));
  };

  Admin.prototype.loadCodeList = function (page) {
    var self = this;
    this.codeFilter = this.codeFilter || { batch_id: '', status: '', project_id: '', q: '' };
    var f = this.codeFilter;
    RDC.clear(this.codesList);
    var batches = [['', 'Toutes les séries']].concat((this.codeData.batches || []).map(function (b) { return [b.id, b.label]; }));
    var fb = select(batches, f.batch_id, { 'aria-label': 'Série' });
    var fs = select([['', 'Tous les statuts'], ['new', 'Disponibles'], ['used', 'Joués'], ['void', 'Désactivés']], f.status, { 'aria-label': 'Statut' });
    var fp = select([['', 'Tous les projets']].concat(this.data.projects.map(function (p) { return [p.id, p.name]; })), f.project_id, { 'aria-label': 'Projet' });
    var fq = input(f.q, { placeholder: 'Début du code…', 'aria-label': 'Rechercher un code' });
    var apply = function () { f.batch_id = fb.value; f.status = fs.value; f.project_id = fp.value; f.q = fq.value; self.loadCodeList(1); };
    [fb, fs, fp].forEach(function (x) { x.addEventListener('change', apply); });
    fq.addEventListener('input', RDC.debounce(apply, 350));
    var tableBox = h('div', {}, h('div', { class: 'a-loading', html: '<span class="rdc-spinner"></span>' }));
    this.codesList.appendChild(card('Tous les tickets', h('div', {}, h('div', { class: 'a-filters' }, fb, fs, fp, fq), tableBox)));
    if (document.activeElement && document.activeElement.getAttribute('aria-label') === 'Rechercher un code') { /* rien */ }
    RDC.api('adm.codes.list', { batch_id: f.batch_id, status: f.status, project_id: f.project_id, q: f.q, page: page }).then(function (r) {
      RDC.clear(tableBox);
      if (!r.items.length) { tableBox.appendChild(emptyBox('Aucun ticket ne correspond', 'Modifiez les filtres ci-dessus.')); return; }
      tableBox.appendChild(h('div', { class: 'a-table-wrap' }, h('table', { class: 'a-table' },
        h('thead', {}, h('tr', {}, ['Code', 'Série', 'Statut', 'Projet', 'Résultat', 'Joué le'].map(function (x) { return h('th', { text: x }); }))),
        h('tbody', {}, r.items.map(function (it) {
          var st = CODE_STATUS[it.status] || [it.status, ''];
          return h('tr', {},
            h('td', {}, h('button', { type: 'button', class: 'btn btn--sm btn--ghost a-code', text: it.code, title: 'Voir le détail', onclick: function () { self.codeModal(it.code); } })),
            h('td', { class: 'a-muted', text: it.batch }),
            h('td', {}, badge(st[0], st[1])),
            h('td', { text: it.project || '—' }),
            h('td', {}, it.kind ? (it.kind === 'lose' ? h('span', { class: 'a-muted', text: 'Perdu' }) : h('span', { text: (it.kind === 'jackpot' ? '★ ' : '') + it.prize })) : '—'),
            h('td', { class: 'a-nowrap a-muted', text: it.used_at ? RDC.fmt.date(it.used_at) : '' }));
        })))));
      tableBox.appendChild(self.pager(r, function (pg) { self.loadCodeList(pg); }));
    }, function (e) { self.fail(tableBox, e); });
  };

  Admin.prototype.pager = function (r, go) {
    return h('div', { class: 'a-pager' },
      h('span', { text: RDC.fmt.num(r.total) + ' résultat' + (r.total > 1 ? 's' : '') + (r.pages > 1 ? ', page ' + r.page + ' sur ' + r.pages : '') }),
      r.pages > 1 ? h('div', { class: 'a-row' },
        btn('Précédente', 'back', function () { go(r.page - 1); }, 'btn--sm', { disabled: r.page <= 1 }),
        btn('Suivante', 'chevron', function () { go(r.page + 1); }, 'btn--sm', { disabled: r.page >= r.pages })) : null);
  };

  Admin.prototype.showCodeVerdict = function (box, r) {
    var self = this;
    RDC.clear(box);
    var v = describeCode(r);
    var res = r.result;
    var rows = [['Ticket', h('span', { class: 'a-code', text: r.code })], ['Série', r.batch || '—'], ['Émis le', RDC.fmt.date(r.created_at, false)]];
    if (res) {
      rows.push(['Projet', projDot(res.project ? (self.project(res.project.id) || res.project) : null)]);
      rows.push(['Joué le', RDC.fmt.date(res.played_at)]);
      rows.push(['Résultat', res.kind === 'lose' ? 'Perdu' : (res.kind === 'jackpot' ? 'Grand prix : ' : '') + res.prize.name + (res.prize.weight ? ' (' + res.prize.weight + ')' : '')]);
      if (res.customer && (res.customer.name || res.customer.phone)) rows.push(['Client', [res.customer.name, res.customer.phone, res.customer.note].filter(Boolean).join(' — ')]);
      if (res.status === 'delivered') rows.push(['Remis', RDC.fmt.date(res.delivered_at) + (res.delivered_by ? ' par ' + res.delivered_by : '')]);
    }
    var acts = h('div', { class: 'a-row' });
    if (r.status === 'new') acts.appendChild(btn('Désactiver ce ticket', 'lock', function (e) {
      var b = e.currentTarget;
      RDC.confirm({ title: 'Désactiver ce ticket ?', message: 'Il ne pourra plus être joué sur aucun projet. Vous pourrez le réactiver plus tard.', confirm: 'Désactiver', danger: true }).then(function (ok) {
        if (ok) RDC.busy(b, RDC.api('adm.codes.void', { code: r.code })).then(function (x) { self.showCodeVerdict(box, x); RDC.toast('Ticket désactivé.', 'success'); if (self.codeData) self.loadCodes(); }, function (ex) { RDC.toast(ex.message, 'error'); });
      });
    }, 'btn--sm btn--danger-ghost'));
    if (r.status === 'void') acts.appendChild(btn('Réactiver ce ticket', 'refresh', function (e) {
      RDC.busy(e.currentTarget, RDC.api('adm.codes.restore', { code: r.code })).then(function (x) { self.showCodeVerdict(box, x); RDC.toast('Ticket réactivé.', 'success'); if (self.codeData) self.loadCodes(); }, function (ex) { RDC.toast(ex.message, 'error'); });
    }, 'btn--sm'));
    if (res && res.kind !== 'lose' && res.status === 'pending') acts.appendChild(btn('Marquer le lot comme remis', 'check', function (e) {
      RDC.busy(e.currentTarget, RDC.api('adm.plays.status', { id: res.id, status: 'delivered' })).then(function () {
        return RDC.api('adm.codes.lookup', { code: r.code }).then(function (x) { self.showCodeVerdict(box, x); self.refreshPendingBadge(); RDC.toast('Remise enregistrée.', 'success'); });
      }, function (ex) { RDC.toast(ex.message, 'error'); });
    }, 'btn--sm'));
    box.appendChild(h('div', { class: 'a-verdict tone-' + v.tone },
      h('div', { class: 'a-verdict__head', html: RDC.icon(v.icon) + '<span>' + RDC.esc(v.title) + '</span>' }),
      h('div', { class: 'a-verdict__body' },
        h('dl', { class: 'a-dl' }, rows.map(function (x) { return [h('dt', { text: x[0] }), h('dd', {}, x[1])]; })),
        acts.childNodes.length ? acts : null)));
  };

  Admin.prototype.codeModal = function (code) {
    var self = this;
    var box = h('div', {}, h('div', { class: 'a-loading', html: '<span class="rdc-spinner"></span>' }));
    RDC.modal({ title: 'Ticket ' + code, content: box, width: '560px' });
    RDC.api('adm.codes.lookup', { code: code }).then(function (r) { self.showCodeVerdict(box, r); }, function (e) { self.fail(box, e); });
  };

  Admin.prototype.generateModal = function () {
    var self = this;
    var qty = input('100', { type: 'number', min: '1', max: '5000', inputmode: 'numeric' });
    var label = input('', { placeholder: 'Ex. Tickets de novembre', maxlength: '80' });
    var err = h('p', { class: 'a-err', role: 'alert' });
    var m = RDC.modal({
      title: 'Générer des tickets', width: '480px',
      content: h('div', { class: 'a-stack' },
        field('Nombre de tickets', qty, 'Entre 1 et 5 000 par série.'),
        field('Nom de la série (facultatif)', label, 'Pour vous y retrouver, par exemple le mois ou l’événement.'),
        h('div', { class: 'a-alert a-alert--info', html: RDC.icon('info') + '<span>Chaque ticket porte un code unique et imprévisible. Il est valable sur <strong>tous vos projets</strong>, mais une seule fois au total.</span>' }),
        err),
      actions: [
        { label: 'Annuler', class: 'btn btn--ghost' },
        { label: 'Générer', class: 'btn btn--primary', close: false, onClick: function (api, b) {
          var n = parseInt(qty.value, 10);
          if (!(n >= 1 && n <= 5000)) { err.textContent = 'Indiquez un nombre entre 1 et 5 000.'; qty.focus(); return; }
          RDC.busy(b, RDC.api('adm.codes.generate', { quantity: n, label: label.value })).then(function (r) {
            m.close();
            RDC.toast(RDC.fmt.plural(n, 'ticket généré', 'tickets générés') + '.', 'success');
            self.codeData = r;
            if (self.current === '/tickets') { self.loadCodes(); }
            self.afterGenerate(r.batch_id, n);
          }, function (e) { err.textContent = e.message; });
        } }
      ]
    });
  };

  Admin.prototype.afterGenerate = function (batchId, n) {
    RDC.modal({
      title: 'Série prête', width: '440px',
      content: h('p', { class: 'modal-text', text: RDC.fmt.plural(n, 'ticket est prêt', 'tickets sont prêts') + ' à être imprimés. Vous pouvez aussi exporter la liste pour un imprimeur.' }),
      actions: [
        { label: 'Exporter (CSV)', class: 'btn', onClick: function () { RDC.download('adm.export.codes', { batch: batchId }); } },
        { label: 'Imprimer les tickets', class: 'btn btn--primary', onClick: function () { if (RDC.cfg.demo) location.hash = RDC.url.print(batchId); else window.open(RDC.url.print(batchId), '_blank'); } }
      ]
    });
  };

  Admin.prototype.renameBatch = function (b) {
    var self = this;
    var lbl = input(b.label, { maxlength: '80' });
    RDC.modal({ title: 'Renommer la série', width: '440px', content: field('Nom de la série', lbl), actions: [
      { label: 'Annuler', class: 'btn btn--ghost' },
      { label: 'Enregistrer', class: 'btn btn--primary', close: false, onClick: function (api, bt) {
        RDC.busy(bt, RDC.api('adm.batch.rename', { id: b.id, label: lbl.value })).then(function (r) { api.close(); self.codeData = r; self.paintBatches(); }, function (e) { RDC.toast(e.message, 'error'); });
      } }] });
  };
  Admin.prototype.voidBatch = function (b) {
    var self = this;
    RDC.confirm({ title: 'Désactiver les tickets restants ?', message: 'Les ' + RDC.fmt.num(b.fresh) + ' tickets non joués de « ' + b.label + ' » ne pourront plus être joués (utile pour des tickets perdus ou d’essai). Les tickets déjà joués ne changent pas.', confirm: 'Désactiver', danger: true })
      .then(function (ok) { if (ok) RDC.api('adm.batch.void', { id: b.id }).then(function (r) { RDC.toast(RDC.fmt.plural(r.voided, 'ticket désactivé', 'tickets désactivés') + '.', 'success'); self.loadCodes(); }, function (e) { RDC.toast(e.message, 'error'); }); });
  };
  Admin.prototype.deleteBatch = function (b) {
    var self = this;
    RDC.confirm({ title: 'Supprimer cette série ?', message: 'Les ' + RDC.fmt.num(b.total) + ' tickets de « ' + b.label + ' » seront supprimés définitivement. Ne le faites que si ces tickets n’ont jamais été distribués.', confirm: 'Supprimer', danger: true })
      .then(function (ok) { if (ok) RDC.api('adm.batch.delete', { id: b.id }).then(function () { RDC.toast('Série supprimée.', 'success'); self.loadCodes(); }, function (e) { RDC.toast(e.message, 'error'); }); });
  };

  /* ════════════════ Gains & remises ════════════════ */
  Admin.prototype.pageGains = function (preset) {
    var self = this;
    this.gainFilter = this.gainFilter || { project_id: '', kind: '', status: '', period: '', q: '' };
    if (preset === 'a-remettre') this.gainFilter = { project_id: '', kind: '', status: 'pending', period: '', q: '' };
    var f = this.gainFilter;
    var exp = btn('Exporter (CSV)', 'download', function () { RDC.download('adm.export.plays', f); });
    this.main.appendChild(this.head('Gains & remises', 'Toutes les parties de tous les projets. Les lots gagnés passent de « À remettre » à « Remis » quand le livreur confirme la remise.', exp));
    var fp = select([['', 'Tous les projets']].concat(this.data.projects.map(function (p) { return [p.id, p.name]; })), f.project_id, { 'aria-label': 'Projet' });
    var fk = select([['', 'Tous les résultats'], ['win', 'Gagnés (lots + grand prix)'], ['jackpot', 'Grands prix'], ['lose', 'Perdus']], f.kind, { 'aria-label': 'Résultat' });
    var fs = select([['', 'Tous les statuts'], ['pending', 'À remettre'], ['delivered', 'Remis'], ['cancelled', 'Annulés']], f.status, { 'aria-label': 'Statut' });
    var fd = select([['', 'Toute la période'], ['today', 'Aujourd’hui'], ['7d', '7 derniers jours'], ['30d', '30 derniers jours']], f.period, { 'aria-label': 'Période' });
    var fq = input(f.q, { placeholder: 'Code, nom, téléphone, lot…', 'aria-label': 'Rechercher' });
    var box = h('div', {});
    var load = function (page) {
      f.project_id = fp.value; f.kind = fk.value; f.status = fs.value; f.period = fd.value; f.q = fq.value;
      RDC.clear(box);
      box.appendChild(h('div', { class: 'a-loading', html: '<span class="rdc-spinner"></span>' }));
      RDC.api('adm.plays.list', Object.assign({ page: page }, f)).then(function (r) { self.paintGains(box, r, load); }, function (e) { self.fail(box, e); });
    };
    [fp, fk, fs, fd].forEach(function (x) { x.addEventListener('change', function () { load(1); }); });
    fq.addEventListener('input', RDC.debounce(function () { load(1); }, 350));
    this.main.appendChild(card(null, h('div', {}, h('div', { class: 'a-filters' }, fp, fk, fs, fd, fq), box)));
    load(1);
  };

  Admin.prototype.paintGains = function (box, r, reload) {
    var self = this;
    RDC.clear(box);
    if (!r.items.length) { box.appendChild(emptyBox('Aucune partie ne correspond', 'Les parties s’affichent ici dès que vos clients jouent.')); return; }
    box.appendChild(h('div', { class: 'a-table-wrap' }, h('table', { class: 'a-table' },
      h('thead', {}, h('tr', {}, ['Date', 'Projet', 'Ticket', 'Résultat', 'Client', 'Statut', ''].map(function (x) { return h('th', { text: x }); }))),
      h('tbody', {}, r.items.map(function (it) {
        var st = STATUS[it.status] || ['—', ''];
        var proj = it.project ? (self.project(it.project.id) || it.project) : null;
        var res = it.kind === 'lose' ? h('span', { class: 'a-muted', text: 'Perdu' }) : h('div', { class: 'a-cell-prize' },
          it.prize.photo ? h('img', { class: 'a-thumb', src: RDC.asset(it.prize.photo), alt: '' }) : null,
          h('div', {}, it.kind === 'jackpot' ? badge('Grand prix', 'gold', 'crown') : null, h('div', { style: { fontWeight: '700' }, text: it.prize.name }), it.prize.weight ? h('div', { class: 'a-small a-muted', text: it.prize.weight }) : null));
        var cust = it.customer || {};
        var acts = h('div', { class: 'a-row', style: { flexWrap: 'nowrap', justifyContent: 'flex-end' } });
        if (it.kind !== 'lose') {
          if (it.status === 'pending') {
            acts.appendChild(btn('Remis', 'check', function (e) { self.setPlay(it, 'delivered', e.currentTarget, reload); }, 'btn--sm'));
            acts.appendChild(iconBtn('close', 'Annuler ce gain', function (e) {
              RDC.confirm({ title: 'Annuler ce gain ?', message: 'Le lot ne sera plus à remettre (par exemple en cas d’abus). Vous pourrez revenir en arrière.', confirm: 'Annuler le gain', danger: true, cancel: 'Garder' })
                .then(function (ok) { if (ok) self.setPlay(it, 'cancelled', null, reload); });
            }, 'btn--danger-ghost'));
          } else if (it.status === 'delivered' || it.status === 'cancelled') {
            acts.appendChild(iconBtn('refresh', 'Remettre « à remettre »', function (e) {
              var b = e.currentTarget;
              RDC.confirm({ title: 'Remettre ce lot « à remettre » ?', message: it.status === 'delivered'
                ? 'Ce lot a été noté remis' + (it.delivered_by ? ' par ' + it.delivered_by : '') + ' le ' + RDC.fmt.date(it.delivered_at) + '. Ne le faites que si la remise n’a pas vraiment eu lieu : le livreur pourra alors le remettre de nouveau.'
                : 'Le gain redeviendra à remettre.', confirm: 'Oui, remettre à remettre', danger: it.status === 'delivered', cancel: 'Annuler' })
                .then(function (ok) { if (ok) self.setPlay(it, 'pending', b, reload); });
            }));
          }
        }
        return h('tr', {},
          h('td', { class: 'a-nowrap', text: RDC.fmt.date(it.played_at) }),
          h('td', {}, projDot(proj)),
          h('td', {}, h('button', { type: 'button', class: 'btn btn--sm btn--ghost a-code', text: it.code, onclick: function () { self.codeModal(it.code); } })),
          h('td', {}, res),
          h('td', {}, cust.name || cust.phone ? h('div', {}, h('div', { style: { fontWeight: '700' }, text: cust.name || '—' }), cust.phone ? h('div', { class: 'a-small a-muted', text: cust.phone }) : null, cust.note ? h('div', { class: 'a-small a-muted', text: cust.note }) : null) : h('span', { class: 'a-muted', text: it.kind === 'lose' ? '' : 'Non renseigné' })),
          h('td', {}, it.kind === 'lose' ? '' : h('div', {}, badge(st[0], st[1], st[2]), it.status === 'delivered' ? h('div', { class: 'a-small a-muted', style: { marginTop: '4px' }, text: RDC.fmt.date(it.delivered_at) + (it.delivered_by ? ' par ' + it.delivered_by : '') }) : null)),
          h('td', {}, acts));
      })))));
    box.appendChild(this.pager(r, reload));
  };

  Admin.prototype.setPlay = function (it, status, b, reload) {
    var self = this;
    RDC.busy(b, RDC.api('adm.plays.status', { id: it.id, status: status })).then(function () {
      RDC.toast(status === 'delivered' ? 'Remise enregistrée.' : status === 'cancelled' ? 'Gain annulé.' : 'Le lot est de nouveau à remettre.', 'success');
      self.refreshPendingBadge();
      reload(1);
    }, function (e) { RDC.toast(e.message, 'error'); reload(1); });
  };

  /* ════════════════ Livreurs ════════════════ */
  Admin.prototype.pageLivreurs = function () {
    var self = this;
    this.main.appendChild(this.head('Livreurs', 'Un seul espace livreur pour tous les projets : il vérifie n’importe quel ticket et confirme la remise des lots.',
      btn('Ajouter un livreur', 'plus', function () { self.livreurModal(); }, 'btn--primary')));
    var box = this.loading();
    RDC.api('adm.livreurs.list').then(function (r) {
      box.remove();
      var url = RDC.cfg.demo ? location.href.split('#')[0] + '#/livreur' : r.url;
      var qr = '';
      try { qr = RDCQR.toSVG(url, { ecl: 'M', margin: 2 }); } catch (e) { qr = ''; }
      var copy = btn('Copier le lien', 'copy', function () { RDC.copy(url).then(function () { RDC.toast('Lien copié.', 'success'); }); }, 'btn--sm');
      self.main.appendChild(card('Accès à l’espace livreur', h('div', { class: 'a-qrbox' }, qr ? RDC.frag(qr) : null,
        h('div', { class: 'a-stack', style: { flex: '1', minWidth: '240px', gap: '10px' } },
          h('p', { text: 'Le livreur scanne ce QR code avec son téléphone (ou ouvre le lien), puis saisit son code personnel. Il reste connecté 90 jours et peut ajouter la page à son écran d’accueil comme une application.' }),
          h('div', { class: 'a-urlline' }, h('code', { text: url }), copy)))));
      var list;
      if (!r.livreurs.length) list = emptyBox('Aucun livreur', 'Ajoutez un livreur et donnez-lui son code personnel.', btn('Ajouter un livreur', 'plus', function () { self.livreurModal(); }, 'btn--primary'));
      else list = h('div', { class: 'a-table-wrap' }, h('table', { class: 'a-table' },
        h('thead', {}, h('tr', {}, ['Nom', 'Statut', 'Dernière activité', 'Lots remis', ''].map(function (x, i) { return h('th', { class: i === 3 ? 'num' : '', text: x }); }))),
        h('tbody', {}, r.livreurs.map(function (l) {
          return h('tr', {},
            h('td', {}, h('strong', { text: l.name })),
            h('td', {}, l.active ? badge('Actif', 'ok') : badge('Suspendu', 'err')),
            h('td', { class: 'a-muted', text: l.last_seen_at ? RDC.fmt.relative(l.last_seen_at) : 'Jamais connecté' }),
            h('td', { class: 'num', text: RDC.fmt.num(l.deliveries) }),
            h('td', {}, h('div', { class: 'a-row', style: { justifyContent: 'flex-end', flexWrap: 'nowrap' } },
              btn('Modifier', 'edit', function () { self.livreurModal(l); }, 'btn--sm'),
              iconBtn('trash', 'Supprimer', function () {
                RDC.confirm({ title: 'Supprimer ' + l.name + ' ?', message: 'Son code ne fonctionnera plus. L’historique de ses remises est conservé.', confirm: 'Supprimer', danger: true })
                  .then(function (ok) { if (ok) RDC.api('adm.livreurs.delete', { id: l.id }).then(function () { RDC.toast('Livreur supprimé.', 'success'); self.go('/livreurs'); }); });
              }, 'btn--danger-ghost'))));
        }))));
      self.main.appendChild(card('Vos livreurs', list));
    }, function (e) { self.fail(box, e); });
  };

  Admin.prototype.livreurModal = function (l) {
    var self = this;
    var name = input(l ? l.name : '', { maxlength: '60', autocomplete: 'off' });
    var pin = input('', { inputmode: 'numeric', maxlength: '8', autocomplete: 'off', placeholder: l ? 'Laisser vide pour ne pas changer' : '6 à 8 chiffres' });
    pin.addEventListener('input', function () { pin.value = pin.value.replace(/\D/g, '').slice(0, 8); });
    var gen = btn('Générer', 'refresh', function () { var s = ''; var a = new Uint32Array(6); (window.crypto || window.msCrypto).getRandomValues(a); for (var i = 0; i < 6; i++) s += String(a[i] % 10); pin.value = s; }, 'btn--sm');
    var active = !l || l.active;
    var err = h('p', { class: 'a-err', role: 'alert' });
    RDC.modal({
      title: l ? 'Modifier ' + l.name : 'Ajouter un livreur', width: '460px',
      content: h('div', { class: 'a-stack' },
        field('Nom', name),
        h('div', { class: 'a-field' }, h('label', { for: pin.id = nid('pin'), text: 'Code personnel' }), h('div', { class: 'a-row', style: { flexWrap: 'nowrap' } }, pin, gen),
          h('p', { class: 'a-hint', text: 'Le livreur saisit ce code pour se connecter. Notez-le avant d’enregistrer : il ne sera plus affiché ensuite.' })),
        switchEl('Accès actif', active, function (v) { active = v; }, 'Désactivez pour suspendre l’accès sans supprimer le livreur.'),
        err),
      actions: [
        { label: 'Annuler', class: 'btn btn--ghost' },
        { label: 'Enregistrer', class: 'btn btn--primary', close: false, onClick: function (api, b) {
          RDC.busy(b, RDC.api('adm.livreurs.save', { id: l ? l.id : 0, name: name.value, pin: pin.value, active: active })).then(function () {
            api.close();
            RDC.toast(l ? 'Livreur modifié.' : 'Livreur ajouté.' + (pin.value ? ' Son code : ' + pin.value : ''), 'success', 7000);
            self.go('/livreurs');
          }, function (e) { err.textContent = e.message; });
        } }
      ]
    });
  };

  /* ════════════════ Liste des projets ════════════════ */
  Admin.prototype.pageProjects = function () {
    var self = this;
    this.main.appendChild(this.head('Vos projets', 'Chaque projet a son propre site, son identité, ses produits et sa roue. Tous partagent la même réserve de tickets.',
      btn('Nouveau projet', 'plus', function () { self.newProject(); }, 'btn--primary')));
    var box = this.loading();
    RDC.api('adm.dashboard').then(function (d) {
      box.remove();
      var stats = {};
      d.projects.forEach(function (p) { stats[p.id] = p.stats; });
      var list = h('div', { class: 'a-projlist' });
      self.data.projects.forEach(function (p, i) {
        var st = stats[p.id] || { plays: 0, wins: 0, pending: 0, today: 0 };
        var logo = p.logo ? h('img', { class: 'a-projrow__logo', src: RDC.asset(p.logo), alt: '' }) : h('span', { class: 'a-projrow__logo' });
        logo.style.setProperty('--pc', p.c1); logo.style.setProperty('--pbg', p.bg1);
        list.appendChild(h('div', { class: 'a-projrow' },
          h('div', { class: 'a-move' }, iconBtn('up', 'Monter', function () { self.moveProject(i, -1); }), iconBtn('down', 'Descendre', function () { self.moveProject(i, 1); })),
          logo,
          h('div', { style: { minWidth: '0' } },
            h('div', { class: 'a-projrow__name' }, h('span', { text: p.name }), p.active ? badge('Ouvert', 'ok') : badge('Fermé', '')),
            h('div', { class: 'a-projrow__url', text: RDC.cfg.demo ? 'Démo : ' + RDC.url.project(p.slug) : p.url }),
            h('div', { class: 'a-projrow__stats' },
              h('span', {}, h('b', { text: RDC.fmt.num(st.plays) }), ' parties'), h('span', {}, h('b', { text: RDC.fmt.num(st.wins) }), ' gagnées'),
              h('span', {}, h('b', { text: RDC.fmt.num(st.pending) }), ' à remettre'))),
          h('div', { class: 'a-projrow__acts' },
            linkBtn('Personnaliser', 'palette', self.href('/projet/' + p.id), 'btn--sm btn--primary'),
            linkBtn('Voir le site', 'external', RDC.cfg.demo ? RDC.url.project(p.slug) : p.url, 'btn--sm', !RDC.cfg.demo))));
      });
      self.main.appendChild(list);
      self.main.appendChild(h('p', { class: 'a-hint', style: { marginTop: '14px' }, text: 'L’ordre ci-dessus est celui du portail (la page où le client choisit son jeu).' }));
    }, function (e) { self.fail(box, e); });
  };

  Admin.prototype.moveProject = function (i, dir) {
    var self = this;
    var ids = this.data.projects.map(function (p) { return p.id; });
    var j = i + dir;
    if (j < 0 || j >= ids.length) return;
    var t = ids[i]; ids[i] = ids[j]; ids[j] = t;
    RDC.api('adm.projects.reorder', { ids: ids }).then(function (r) { self.data.projects = r.projects; self.go('/projets'); });
  };

  Admin.prototype.newProject = function () {
    var self = this;
    var name = input('', { maxlength: '80', placeholder: 'Ex. Mon nouveau magasin' });
    var from = select([['0', 'Les produits et la roue d’exemple']].concat(this.data.projects.map(function (p) { return [p.id, 'Une copie de « ' + p.name + ' »']; })), this.data.projects[0] ? this.data.projects[0].id : '0');
    var err = h('p', { class: 'a-err', role: 'alert' });
    RDC.modal({ title: 'Nouveau projet', width: '480px', content: h('div', { class: 'a-stack' },
      field('Nom de l’activité', name), field('Partir de', from, 'La copie reprend l’apparence, les textes, les produits et la roue. Vous pourrez tout modifier.'), err),
    actions: [{ label: 'Annuler', class: 'btn btn--ghost' }, { label: 'Créer le projet', class: 'btn btn--primary', close: false, onClick: function (api, b) {
      RDC.busy(b, RDC.api('adm.project.create', { name: name.value, copy_from: parseInt(from.value, 10) || 0 })).then(function (r) {
        api.close();
        self.data.projects = r.projects;
        RDC.toast('Projet créé.', 'success');
        self.navigate('/projet/' + r.project.id + '/identite');
      }, function (e) { err.textContent = e.message; });
    } }] });
  };

  /* ════════════════ Un projet ════════════════ */
  var TABS = [['identite', 'Identité', 'image'], ['apparence', 'Apparence', 'palette'], ['produits', 'Produits & lots', 'box'], ['roue', 'Roue', 'wheel'], ['textes', 'Textes', 'text'], ['options', 'Options & contact', 'toggle'], ['reglages', 'Adresse & réglages', 'settings']];

  Admin.prototype.pageProject = function (id, tab) {
    var self = this;
    var box = this.loading();
    RDC.api('adm.project.get', { id: id }).then(function (r) {
      box.remove();
      self.proj = r;
      self.draft = clone(r.project);
      self.tab = TABS.some(function (t) { return t[0] === tab; }) ? tab : 'identite';
      self.paintProject();
    }, function (e) { self.fail(box, e); });
  };

  Admin.prototype.paintProject = function () {
    var self = this;
    var p = this.proj.project;
    RDC.clear(this.main);
    if (this.previewWheel) { this.previewWheel.destroy(); this.previewWheel = null; }
    var logo = p.logo ? h('img', { class: 'a-phead__logo', src: RDC.asset(p.logo), alt: '' }) : null;
    if (logo) { logo.style.setProperty('--pc', p.c1); logo.style.setProperty('--pbg', p.bg1); }
    var url = RDC.cfg.demo ? RDC.url.project(p.slug) : p.url;
    this.main.appendChild(h('div', { class: 'a-phead' }, logo,
      h('div', { class: 'a-phead__txt' }, h('h1', { text: p.name }),
        h('span', { class: 'a-phead__url' }, p.active ? badge('Ouvert', 'ok') : badge('Fermé', ''), h('a', { href: url, target: RDC.cfg.demo ? null : '_blank', rel: 'noopener', text: RDC.cfg.demo ? 'Ouvrir le site du projet' : url }))),
      linkBtn('Voir le site', 'external', url, '', !RDC.cfg.demo)));
    this.main.appendChild(h('nav', { class: 'a-tabs', 'aria-label': 'Sections du projet' }, TABS.map(function (t) {
      return h('a', { class: 'a-tab' + (t[0] === self.tab ? ' is-active' : ''), href: self.href('/projet/' + p.id + '/' + t[0]), html: RDC.icon(t[2]) + '<span>' + t[1] + '</span>', 'aria-current': t[0] === self.tab ? 'page' : null });
    })));
    this.tabBox = h('div', {});
    this.main.appendChild(this.tabBox);
    var fn = { identite: 'tabIdentity', apparence: 'tabLook', produits: 'tabProducts', roue: 'tabWheel', textes: 'tabTexts', options: 'tabOptions', reglages: 'tabSettings' }[this.tab];
    this[fn]();
  };

  /** Marque le brouillon du projet comme modifié (barre d'enregistrement). */
  Admin.prototype.touch = function () {
    var self = this;
    this.setDirty(true, function () { return self.saveProject(); }, function () { self.draft = clone(self.proj.project); self.setDirty(false); self.paintProject(); });
    if (this.onDraft) this.onDraft();
  };

  Admin.prototype.saveProject = function () {
    var self = this;
    var d = this.draft;
    return RDC.api('adm.project.save', { id: d.id, name: d.name, slug: d.slug, domain: d.domain, active: d.active, settings: d.settings }).then(function (r) {
      self.proj = r;
      self.draft = clone(r.project);
      self.setDirty(false);
      for (var i = 0; i < self.data.projects.length; i++) if (self.data.projects[i].id === r.project.id) {
        var s = r.project;
        self.data.projects[i] = { id: s.id, slug: s.slug, name: s.name, domain: s.domain, active: s.active, sort: s.sort, logo: s.logo, c1: s.c1, c2: s.c2, c3: s.c3, bg1: s.bg1, bg2: s.bg2, url: s.url };
      }
      self.paintNav();
      RDC.toast('Modifications enregistrées.', 'success');
      self.paintProject();
    }, function (e) {
      RDC.toast(e.message, 'error');
      throw e;
    });
  };

  /* ───── Identité ───── */
  Admin.prototype.tabIdentity = function () {
    var self = this, d = this.draft, s = d.settings;
    var name = input(d.name, { maxlength: '80' });
    name.addEventListener('input', function () { d.name = name.value; self.touch(); });
    var tag = input(s.brand.tagline, { maxlength: '120', placeholder: 'Ex. Votre épicerie fine, livrée chez vous' });
    tag.addEventListener('input', function () { s.brand.tagline = tag.value; self.touch(); });
    var pv = h('div', {});
    var paintPv = function () {
      RDC.clear(pv);
      var box = h('div', { class: 'a-preview' }, h('div', { class: 'a-preview__brand' }, s.brand.logo ? h('img', { src: RDC.asset(s.brand.logo), alt: '' }) : null,
        h('div', { style: { textAlign: 'left' } }, h('div', { class: 'a-preview__name', text: d.name || 'Nom de l’activité' }), s.brand.tagline ? h('div', { class: 'a-preview__sub', text: s.brand.tagline }) : null)));
      RDC.applyTheme(s.theme, box, self.data.defaults.fonts);
      pv.appendChild(box);
    };
    this.onDraft = paintPv;
    paintPv();
    this.tabBox.appendChild(h('div', { class: 'a-two' },
      card('Logo et nom', h('div', { class: 'a-stack' },
        h('div', { class: 'a-field' }, h('span', { class: 'a-label', text: 'Logo' }), imageEl({ value: s.brand.logo, kind: 'logo', dark: true, hint: 'PNG avec fond transparent conseillé. Il s’affiche en haut du site et sur les tickets.', onChange: function (v) { s.brand.logo = v; self.touch(); } })),
        field('Nom de l’activité', name, 'Affiché en lettres néon en haut de la page.'),
        field('Slogan (facultatif)', tag))),
      card('Aperçu', pv, { desc: 'Rendu en haut de la page de jeu.' })));
  };

  /* ───── Apparence ───── */
  Admin.prototype.tabLook = function () {
    var self = this, d = this.draft, t = d.settings.theme;
    var defs = this.data.defaults;
    var colorBoxes = {};
    var presets = h('div', { class: 'a-presets' });
    var paintPresets = function () {
      RDC.clear(presets);
      Object.keys(defs.presets).forEach(function (k) {
        var pr = defs.presets[k];
        var sw = h('span', { class: 'a-preset__sw', style: { background: 'radial-gradient(120% 120% at 50% 0%, ' + pr.bg2 + ', ' + pr.bg1 + ')' } },
          h('i', { style: { background: pr.c1, color: pr.c1 } }), h('i', { style: { background: pr.c2, color: pr.c2 } }), h('i', { style: { background: pr.c3, color: pr.c3 } }));
        presets.appendChild(h('button', { type: 'button', class: 'a-preset' + (t.preset === k ? ' is-on' : ''), 'aria-pressed': t.preset === k ? 'true' : 'false', onclick: function () {
          t.preset = k; ['c1', 'c2', 'c3', 'bg1', 'bg2', 'text'].forEach(function (c) { t[c] = pr[c]; if (colorBoxes[c]) colorBoxes[c].set(pr[c]); });
          paintPresets(); self.touch();
        } }, sw, h('span', { text: pr.label })));
      });
    };
    paintPresets();
    var colorField = function (key, label, hint) {
      var c = colorEl(t[key], function (v) { t[key] = v; t.preset = 'custom'; paintPresets(); self.touch(); });
      colorBoxes[key] = c;
      return h('div', { class: 'a-field' }, h('span', { class: 'a-label', text: label }), c, hint ? h('p', { class: 'a-hint', text: hint }) : null);
    };
    var bgMode = select([['gradient', 'Dégradé lumineux'], ['solid', 'Couleur unie'], ['image', 'Image de fond']], t.bg_mode);
    var imgBox = h('div', {});
    var overlay = input(String(t.bg_overlay), { type: 'range', min: '0', max: '90', step: '5', style: { padding: '0' } });
    var paintBg = function () {
      RDC.clear(imgBox);
      if (t.bg_mode !== 'image') return;
      imgBox.appendChild(h('div', { class: 'a-stack' },
        imageEl({ value: t.bg_image, kind: 'background', cover: true, hint: 'Grande image (paysage). Elle est assombrie pour garder le texte lisible.', onChange: function (v) { t.bg_image = v; self.touch(); } }),
        field('Assombrissement : ' + t.bg_overlay + NB + '%', overlay)));
    };
    bgMode.addEventListener('change', function () { t.bg_mode = bgMode.value; paintBg(); self.touch(); });
    overlay.addEventListener('input', function () { t.bg_overlay = parseInt(overlay.value, 10); var lb = overlay.parentNode && overlay.parentNode.querySelector('label'); if (lb) lb.textContent = 'Assombrissement : ' + t.bg_overlay + NB + '%'; self.touch(); });
    paintBg();
    var fontT = select(Object.keys(defs.fonts.title).map(function (f) { return [f, f]; }), t.font_title);
    var fontB = select(Object.keys(defs.fonts.body).map(function (f) { return [f, f]; }), t.font_body);
    var fontTpv = h('p', { class: 'a-fontpv', text: 'Tentez votre chance' });
    var fontBpv = h('p', { style: { marginTop: '4px' }, text: 'Scannez le QR code de votre ticket.' });
    var paintFonts = function () {
      RDC.loadFonts([defs.fonts.title[t.font_title].spec, defs.fonts.body[t.font_body].spec]);
      fontTpv.style.fontFamily = "'" + t.font_title + "', sans-serif"; fontTpv.style.fontWeight = String(defs.fonts.title[t.font_title].weight || 400);
      fontBpv.style.fontFamily = "'" + t.font_body + "', sans-serif";
    };
    fontT.addEventListener('change', function () { t.font_title = fontT.value; paintFonts(); self.touch(); });
    fontB.addEventListener('change', function () { t.font_body = fontB.value; paintFonts(); self.touch(); });
    paintFonts();

    var pv = h('div', {});
    var paintPv = function () {
      if (self.previewWheel) { self.previewWheel.destroy(); self.previewWheel = null; }
      RDC.clear(pv);
      var wheelBox = h('div', {});
      var box = h('div', { class: 'a-preview' + (t.bg_mode === 'image' && t.bg_image ? ' a-preview--img' : '') },
        t.bg_mode === 'image' && t.bg_image ? h('div', { class: 'a-preview__veil', style: { opacity: String(t.bg_overlay / 100) } }) : null,
        h('div', { class: 'a-preview__name', text: d.name }),
        h('div', { class: 'a-preview__title', text: d.settings.texts.title }),
        wheelBox,
        h('span', { class: 'a-preview__cta', html: RDC.icon('scan') + RDC.esc(d.settings.texts.scan_btn) }));
      if (t.bg_mode === 'image' && t.bg_image) box.style.backgroundImage = 'url("' + RDC.asset(t.bg_image) + '")';
      if (t.bg_mode === 'solid') box.style.background = t.bg1;
      RDC.applyTheme(t, box, defs.fonts);
      pv.appendChild(box);
      self.previewWheel = new RDC.Wheel(wheelBox, { segments: self.previewSegments(), theme: t, texts: d.settings.texts, noIdle: true });
    };
    this.onDraft = RDC.debounce(paintPv, 120);
    paintPv();

    this.tabBox.appendChild(h('div', { class: 'a-two' },
      h('div', { class: 'a-stack' },
        card('Ambiance', presets, { desc: 'Choisissez une ambiance électrique prête à l’emploi, puis ajustez les couleurs si besoin.' }),
        card('Couleurs', h('div', { class: 'a-grid a-grid--3' },
          colorField('c1', 'Couleur d’action', 'Bouton principal, pointeur, néon du nom.'),
          colorField('c2', 'Couleur de validation', 'Messages de réussite, cases de la roue.'),
          colorField('c3', 'Couleur des lots', 'Grand prix, ampoules, bons de gain.'),
          colorField('bg1', 'Fond (bords)'),
          colorField('bg2', 'Fond (halo central)'),
          colorField('text', 'Texte'))),
        card('Fond et effets', h('div', { class: 'a-stack' },
          field('Type de fond', bgMode), imgBox,
          switchEl('Rayons lumineux derrière la roue', t.rays, function (v) { t.rays = v; self.touch(); }),
          switchEl('Ciel étoilé', t.sparkles, function (v) { t.sparkles = v; self.touch(); }),
          switchEl('Ampoules animées autour de la roue', t.lights, function (v) { t.lights = v; self.touch(); }, 'Elles clignotent en chenillard, accélèrent pendant le lancer et s’affolent en cas de gain.'))),
        card('Polices', h('div', { class: 'a-grid a-grid--2' },
          h('div', { class: 'a-field' }, h('label', { for: fontT.id = nid('ft'), text: 'Titres et nom' }), fontT, fontTpv),
          h('div', { class: 'a-field' }, h('label', { for: fontB.id = nid('fb'), text: 'Textes' }), fontB, fontBpv)))),
      h('div', { class: 'a-wheel-preview' }, card('Aperçu', pv))));
  };

  /** Cases de la roue telles qu'affichées (pour les aperçus). */
  Admin.prototype.previewSegments = function (segs) {
    var prods = {};
    (this.proj.products || []).forEach(function (p) { prods[p.id] = p; });
    return (segs || this.proj.segments).map(function (sg, i) {
      var p = sg.product_id ? prods[sg.product_id] : null;
      return { id: sg.id || ('n' + i), kind: sg.kind, label: sg.label, sub: sg.sub, color: sg.color,
        product: sg.kind === 'lose' || !p ? null : { name: p.name, weight: p.weight, photo: p.photo },
        available: sg.kind === 'lose' || (p && p.active && (p.stock === null || p.stock > 0)) };
    }).filter(function (sg) { return sg.kind === 'lose' || sg.product; });
  };

  /* ───── Produits & lots ───── */
  Admin.prototype.tabProducts = function () {
    var self = this;
    var prods = this.proj.products;
    var used = {};
    this.proj.segments.forEach(function (s) { if (s.product_id) used[s.product_id] = (used[s.product_id] || 0) + 1; });
    var others = this.data.projects.filter(function (p) { return p.id !== self.proj.project.id; });
    var actions = h('div', { class: 'a-row' },
      others.length ? btn('Importer d’un autre projet', 'download', function () { self.importModal(others); }, 'btn--sm') : null,
      btn('Ajouter un produit', 'plus', function () { self.productModal(); }, 'btn--primary btn--sm'));
    var list;
    if (!prods.length) list = emptyBox('Aucun produit', 'Ajoutez les produits à gagner : nom, grammage et photo.', btn('Ajouter un produit', 'plus', function () { self.productModal(); }, 'btn--primary'));
    else list = h('div', { class: 'a-products' }, prods.map(function (p, i) {
      var stock = p.stock === null ? badge('Stock illimité', '') : p.stock > 0 ? badge('Stock : ' + p.stock, p.stock <= 3 ? 'warn' : 'info') : badge('Épuisé', 'err');
      return h('div', { class: 'a-prod' + (p.active ? '' : ' is-off') },
        h('div', { class: 'a-move' }, iconBtn('up', 'Monter', function () { self.moveProduct(i, -1); }), iconBtn('down', 'Descendre', function () { self.moveProduct(i, 1); })),
        p.photo ? h('img', { class: 'a-prod__img', src: RDC.asset(p.photo), alt: '' }) : h('span', { class: 'a-prod__img', style: { display: 'grid', placeItems: 'center' }, html: RDC.icon('image') }),
        h('div', { style: { minWidth: '0' } },
          h('div', { class: 'a-prod__name', text: p.name }),
          h('div', { class: 'a-prod__meta' }, p.weight ? h('span', { text: p.weight }) : null, p.value ? h('span', { text: p.value }) : null, stock,
            used[p.id] ? badge('Sur la roue', 'pri', 'wheel') : badge('Pas sur la roue', ''), p.active ? null : badge('Masqué', 'err'))),
        h('div', { class: 'a-prod__acts' },
          btn('Modifier', 'edit', function () { self.productModal(p); }, 'btn--sm'),
          iconBtn('trash', 'Supprimer', function () { self.deleteProduct(p, used[p.id]); }, 'btn--danger-ghost')));
    }));
    this.tabBox.appendChild(card('Produits & lots', list, { actions: actions, desc: 'Les lots que l’on peut gagner sur la roue. Le grand prix est un produit comme les autres : placez-le dans une case « Grand prix » dans l’onglet Roue.' }));
  };

  Admin.prototype.productModal = function (p) {
    var self = this;
    var pid = this.proj.project.id;
    var d = p ? clone(p) : { id: 0, name: '', weight: '', value: '', description: '', photo: '', stock: null, active: true };
    var name = input(d.name, { maxlength: '80', placeholder: 'Ex. Café arabica' });
    var weight = input(d.weight, { maxlength: '40', placeholder: 'Ex. 250 g' });
    var value = input(d.value, { maxlength: '40', placeholder: 'Ex. 120 DH' });
    var desc = textarea(d.description, { maxlength: '300', rows: '2', placeholder: 'Facultatif' });
    var stock = input(d.stock === null ? '' : String(d.stock), { type: 'number', min: '0', inputmode: 'numeric', placeholder: 'Illimité' });
    var err = h('p', { class: 'a-err', role: 'alert' });
    RDC.modal({
      title: p ? 'Modifier le produit' : 'Ajouter un produit', width: '560px',
      content: h('div', { class: 'a-stack' },
        h('div', { class: 'a-field' }, h('span', { class: 'a-label', text: 'Photo' }), imageEl({ value: d.photo, kind: 'product', cover: true, hint: 'Photo carrée de préférence : elle s’affiche dans un cercle sur la roue.', onChange: function (v) { d.photo = v; } })),
        field('Nom du produit', name),
        h('div', { class: 'a-grid a-grid--2' },
          field('Grammage', weight, 'Affiché sous le nom, sur la roue.'),
          field('Valeur ou prix (facultatif)', value, 'Visible seulement si l’option « Afficher la valeur des lots » est activée.')),
        field('Description (facultatif)', desc),
        field('Quantité disponible', stock, 'Laissez vide pour un stock illimité. À 0, la case ne peut plus être gagnée (la roue l’affiche « Épuisé »).'),
        switchEl('Produit actif', d.active, function (v) { d.active = v; }, 'Un produit masqué ne peut plus être gagné.'),
        err),
      actions: [
        { label: 'Annuler', class: 'btn btn--ghost' },
        { label: p ? 'Enregistrer' : 'Ajouter le produit', class: 'btn btn--primary', close: false, onClick: function (api, b) {
          d.name = name.value; d.weight = weight.value; d.value = value.value; d.description = desc.value;
          d.stock = stock.value === '' ? null : Math.max(0, parseInt(stock.value, 10) || 0);
          if (!d.name.trim()) { err.textContent = 'Le nom du produit est obligatoire.'; name.focus(); return; }
          RDC.busy(b, RDC.api('adm.product.save', { project_id: pid, product: d })).then(function (r) {
            api.close();
            self.proj.products = r.products; self.proj.segments = r.segments; self.draft.segments = r.segments;
            RDC.toast(p ? 'Produit enregistré.' : 'Produit ajouté. Placez-le sur la roue dans l’onglet Roue.', 'success');
            self.paintProject();
          }, function (e) { err.textContent = e.message; });
        } }
      ]
    });
  };

  Admin.prototype.deleteProduct = function (p, usedCount) {
    var self = this;
    RDC.confirm({ title: 'Supprimer « ' + p.name + ' » ?', message: usedCount ? 'Ce produit occupe ' + RDC.fmt.plural(usedCount, 'case', 'cases') + ' de la roue : ' + (usedCount > 1 ? 'elles seront retirées' : 'elle sera retirée') + '. Les gains passés restent enregistrés.' : 'Les gains passés restent enregistrés.', confirm: 'Supprimer', danger: true })
      .then(function (ok) {
        if (!ok) return;
        RDC.api('adm.product.delete', { project_id: self.proj.project.id, id: p.id }).then(function (r) {
          self.proj.products = r.products; self.proj.segments = r.segments;
          RDC.toast('Produit supprimé.', 'success');
          self.paintProject();
        }, function (e) { RDC.toast(e.message, 'error'); });
      });
  };

  Admin.prototype.moveProduct = function (i, dir) {
    var self = this;
    var ids = this.proj.products.map(function (p) { return p.id; });
    var j = i + dir;
    if (j < 0 || j >= ids.length) return;
    var t = ids[i]; ids[i] = ids[j]; ids[j] = t;
    RDC.api('adm.product.reorder', { project_id: this.proj.project.id, ids: ids }).then(function (r) { self.proj.products = r.products; self.paintProject(); });
  };

  Admin.prototype.importModal = function (others) {
    var self = this;
    var src = select(others.map(function (p) { return [p.id, p.name]; }), others[0].id);
    RDC.modal({ title: 'Importer les produits et la roue', width: '480px',
      content: h('div', { class: 'a-stack' }, field('Copier depuis', src),
        h('div', { class: 'a-alert a-alert--warn', html: RDC.icon('warning') + '<span>Les produits et la roue actuels de ce projet seront <strong>remplacés</strong>. L’historique des gains n’est pas touché.</span>' })),
      actions: [{ label: 'Annuler', class: 'btn btn--ghost' }, { label: 'Importer', class: 'btn btn--primary', close: false, onClick: function (api, b) {
        RDC.busy(b, RDC.api('adm.project.import', { id: self.proj.project.id, from_id: parseInt(src.value, 10) })).then(function (r) {
          api.close(); self.proj = r; self.draft = clone(r.project); RDC.toast('Produits et roue importés.', 'success'); self.paintProject();
        }, function (e) { RDC.toast(e.message, 'error'); });
      } }] });
  };

  /* ───── Roue ───── */
  Admin.prototype.tabWheel = function () {
    var self = this;
    var segs = clone(this.proj.segments);
    var prods = this.proj.products;
    var prodMap = {};
    prods.forEach(function (p) { prodMap[p.id] = p; });
    var t = this.draft.settings.theme;
    var texts = this.draft.settings.texts;
    var listBox = h('div', { class: 'a-segs' });
    var alerts = h('div', { class: 'a-alerts' });
    var probs = h('div', { class: 'a-probs' });
    var wheelBox = h('div', {});
    var stage = h('div', { class: 'a-wheel-stage' }, wheelBox);
    stage.style.setProperty('--pbg1', t.bg1); stage.style.setProperty('--pbg2', t.bg2);
    if (this.previewWheel) this.previewWheel.destroy();
    this.previewWheel = new RDC.Wheel(wheelBox, { segments: this.previewSegments(segs), theme: t, texts: texts, noIdle: true });
    var wheel = this.previewWheel;

    var dirty = function () {
      self.setDirty(true, save, function () { self.setDirty(false); self.paintProject(); });
      refresh();
    };
    var refreshWheel = RDC.debounce(function () { wheel.setSegments(self.previewSegments(segs)); }, 150);
    function autoColor(i) { var cols = RDC.Wheel.autoColors(segs.map(function (s) { return { kind: s.kind, color: s.color }; }), t); return cols[i]; }
    function defaultLabel(s) {
      var p = s.product_id ? prodMap[s.product_id] : null;
      if (s.kind === 'lose') return texts.lose_label || 'Perdu';
      if (s.kind === 'jackpot') return texts.jackpot_label || 'Grand prix';
      return p ? p.name : '';
    }
    function defaultSub(s) {
      var p = s.product_id ? prodMap[s.product_id] : null;
      if (s.kind === 'lose') return texts.lose_sub || '';
      if (s.kind === 'jackpot') return p ? p.name : '';
      return p ? p.weight : '';
    }
    function prodOptions() { return [['', '— Choisir le produit —']].concat(prods.map(function (p) { return [p.id, p.name + (p.weight ? ' (' + p.weight + ')' : '') + (!p.active ? ' — masqué' : p.stock === 0 ? ' — épuisé' : '')]; })); }

    function paintList() {
      RDC.clear(listBox);
      var total = segs.reduce(function (a, s) { return a + Math.max(0, +s.chance || 0); }, 0);
      segs.forEach(function (s, i) {
        var col = s.color || autoColor(i);
        var sw = h('span', { class: 'a-seg__sw', style: { background: col }, title: s.color ? 'Couleur personnalisée' : 'Couleur automatique' });
        var cp = h('input', { type: 'color', 'aria-label': 'Couleur de la case ' + (i + 1) });
        cp.value = col;
        cp.addEventListener('input', function () { s.color = cp.value.toUpperCase(); sw.style.background = s.color; refreshWheel(); dirty(); });
        sw.appendChild(cp);
        var kind = select([['product', 'Produit'], ['jackpot', 'Grand prix'], ['lose', 'Perdu']], s.kind, { class: 'a-select a-seg__kind', 'aria-label': 'Type de la case ' + (i + 1) });
        kind.addEventListener('change', function () { s.kind = kind.value; if (s.kind === 'lose') s.product_id = null; paintList(); refreshWheel(); dirty(); });
        var prod = select(prodOptions(), s.product_id || '', { 'aria-label': 'Produit de la case ' + (i + 1) });
        prod.hidden = s.kind === 'lose';
        prod.addEventListener('change', function () { s.product_id = prod.value ? parseInt(prod.value, 10) : null; paintList(); refreshWheel(); dirty(); });
        var loseNote = s.kind === 'lose' ? h('span', { class: 'a-small a-muted', text: 'Aucun lot : « ' + (texts.lose_text || 'Vous avez perdu') + ' »' }) : null;
        var chance = input(String(s.chance), { type: 'number', min: '0', max: '100000', inputmode: 'numeric', 'aria-label': 'Chances de la case ' + (i + 1) });
        var pctEl = h('span', { class: 'a-seg__pct', text: total ? pct(Math.max(0, +s.chance || 0) / total * 100) : '0' + NB + '%' });
        chance.addEventListener('input', function () { s.chance = Math.max(0, parseInt(chance.value, 10) || 0); updatePct(); dirty(); });
        var label = input(s.label, { maxlength: '40', placeholder: defaultLabel(s), 'aria-label': 'Texte sur la roue, case ' + (i + 1) });
        label.addEventListener('input', function () { s.label = label.value; refreshWheel(); dirty(); });
        var sub = input(s.sub, { maxlength: '40', placeholder: defaultSub(s) || '2e ligne (facultatif)', 'aria-label': 'Deuxième ligne, case ' + (i + 1) });
        sub.addEventListener('input', function () { s.sub = sub.value; refreshWheel(); dirty(); });
        var p = s.product_id ? prodMap[s.product_id] : null;
        var problem = s.kind !== 'lose' && (!p || !p.active || p.stock === 0);
        listBox.appendChild(h('div', { class: 'a-seg' + (s.kind !== 'lose' && !s.product_id ? ' is-error' : '') },
          h('span', { class: 'a-seg__n', text: String(i + 1) }),
          sw,
          kind,
          h('div', { class: 'a-seg__prod' }, s.kind === 'lose' ? loseNote : prod),
          h('div', { class: 'a-seg__chance' }, chance, pctEl),
          h('div', { class: 'a-row a-seg__acts', style: { flexWrap: 'nowrap', gap: '4px' } },
            iconBtn('up', 'Monter', function () { if (i > 0) { var x = segs[i - 1]; segs[i - 1] = s; segs[i] = x; paintList(); refreshWheel(); dirty(); } }),
            iconBtn('down', 'Descendre', function () { if (i < segs.length - 1) { var x = segs[i + 1]; segs[i + 1] = s; segs[i] = x; paintList(); refreshWheel(); dirty(); } }),
            s.color ? iconBtn('palette', 'Revenir à la couleur automatique', function () { s.color = ''; paintList(); refreshWheel(); dirty(); }) : null,
            iconBtn('trash', 'Supprimer la case', function () { segs.splice(i, 1); paintList(); refreshWheel(); dirty(); }, 'btn--danger-ghost')),
          h('div', { class: 'a-seg__more' }, label, sub),
          problem && p ? h('div', { class: 'a-seg__more' }, h('span', { class: 'a-small', style: { color: 'var(--a-warn)', fontWeight: '700' }, text: p.stock === 0 ? 'Produit épuisé : cette case ne peut plus être gagnée.' : 'Produit masqué : cette case ne peut plus être gagnée.' })) : null));
        function updatePct() {
          var tot = segs.reduce(function (a, x) { return a + Math.max(0, +x.chance || 0); }, 0);
          RDC.$$('.a-seg__pct', listBox).forEach(function (el, k) { el.textContent = tot ? pct(Math.max(0, +segs[k].chance || 0) / tot * 100) : '0' + NB + '%'; });
          refresh();
        }
      });
      refresh();
    }

    function refresh() {
      RDC.clear(alerts); RDC.clear(probs);
      var total = 0, by = { product: 0, jackpot: 0, lose: 0 };
      segs.forEach(function (s) { var c = Math.max(0, +s.chance || 0); total += c; by[s.kind] += c; });
      var warn = function (cls, icon, msg) { alerts.appendChild(h('div', { class: 'a-alert a-alert--' + cls, html: RDC.icon(icon) + '<span>' + msg + '</span>' })); };
      if (segs.length < 2) warn('err', 'warning', 'La roue doit compter au moins 2 cases.');
      if (!total) warn('err', 'warning', 'Toutes les chances sont à 0 : personne ne pourrait jouer. Donnez des chances aux cases.');
      if (!segs.some(function (s) { return s.kind === 'lose'; })) warn('warn', 'warning', 'Aucune case « Perdu » : chaque ticket fera gagner un lot.');
      if (!segs.some(function (s) { return s.kind === 'jackpot'; })) warn('info', 'info', 'Aucune case « Grand prix » sur la roue.');
      if (segs.some(function (s) { return s.kind !== 'lose' && !s.product_id; })) warn('err', 'warning', 'Certaines cases n’ont pas de produit : choisissez-en un.');
      if (segs.length > 12) warn('info', 'info', 'Au-delà de 12 cases, les textes deviennent petits sur téléphone.');
      if (total) {
        [['product', 'Gagner un lot', t.c2], ['jackpot', 'Gagner le grand prix', t.c3], ['lose', 'Perdre', '#8E87A8']].forEach(function (k) {
          var v = by[k[0]] / total * 100;
          probs.appendChild(h('div', { class: 'a-prob' }, h('span', { text: k[1] }), h('strong', { text: pct(v) }),
            h('div', { class: 'a-prob__bar' }, h('i', { style: { width: v + '%', background: k[2] } }))));
        });
      }
    }

    function save() {
      var bad = segs.findIndex ? segs.findIndex(function (s) { return s.kind !== 'lose' && !s.product_id; }) : -1;
      if (bad >= 0) { RDC.toast('Case ' + (bad + 1) + ' : choisissez le produit à gagner.', 'error'); return Promise.reject(new Error('')); }
      return RDC.api('adm.wheel.save', { project_id: self.proj.project.id, segments: segs }).then(function (r) {
        self.proj.segments = r.segments;
        self.setDirty(false);
        RDC.toast('Roue enregistrée. Elle est déjà à jour sur le site.', 'success');
        self.paintProject();
      }, function (e) { RDC.toast(e.message, 'error'); throw e; });
    }

    var add = function (kind) {
      var firstProd = prods.filter(function (p) { return p.active; })[0];
      segs.push({ id: 0, kind: kind, product_id: kind === 'lose' ? null : (firstProd ? firstProd.id : null), label: '', sub: '', color: '', chance: kind === 'jackpot' ? 2 : 10 });
      paintList(); refreshWheel(); dirty();
    };
    paintList();
    this.tabBox.appendChild(h('div', { class: 'a-wheel-layout' },
      h('div', { class: 'a-stack' },
        card('Cases de la roue', h('div', { class: 'a-stack' }, listBox,
          h('div', { class: 'a-row' }, btn('Case produit', 'plus', function () { add('product'); }, 'btn--sm'), btn('Case « Perdu »', 'plus', function () { add('lose'); }, 'btn--sm'), btn('Case grand prix', 'plus', function () { add('jackpot'); }, 'btn--sm'))),
          { desc: 'Les « chances » sont relatives : une case à 20 sort deux fois plus souvent qu’une case à 10. Le tirage est fait par le serveur, jamais par le téléphone du client.' })),
      h('div', { class: 'a-wheel-preview' }, card('Aperçu et probabilités', h('div', {}, stage, probs, h('div', { style: { marginTop: '14px' } }, alerts))))));
  };

  /* ───── Textes ───── */
  Admin.prototype.tabTexts = function () {
    var self = this, x = this.draft.settings.texts;
    var t = function (key, label, hint, multi, max) {
      var el = multi ? textarea(x[key], { rows: multi === true ? '3' : String(multi), maxlength: String(max || 400) }) : input(x[key], { maxlength: String(max || 200) });
      el.addEventListener('input', function () { x[key] = el.value; self.touch(); });
      return field(label, el, hint);
    };
    var steps = h('div', { class: 'a-grid a-grid--3' }, [0, 1, 2].map(function (i) {
      var st = x.steps[i] || { t: '', d: '' };
      x.steps[i] = st;
      var a = input(st.t, { maxlength: '40' }), b = textarea(st.d, { rows: '3', maxlength: '200' });
      a.addEventListener('input', function () { st.t = a.value; self.touch(); });
      b.addEventListener('input', function () { st.d = b.value; self.touch(); });
      return h('div', { class: 'a-stack', style: { gap: '8px' } }, field('Étape ' + (i + 1), a), field('Explication', b));
    }));
    this.tabBox.appendChild(h('div', { class: 'a-stack' },
      card('Page d’accueil', h('div', { class: 'a-grid a-grid--2' },
        t('title', 'Grand titre'), t('subtitle', 'Sous-titre', null, true),
        t('scan_btn', 'Bouton « scanner »'), t('manual_btn', 'Lien « saisir le code »'),
        t('spin_btn', 'Bouton « lancer la roue »'), t('locked_hint', 'Message avant le scan'),
        t('ready_hint', 'Message quand le ticket est validé', '{code} est remplacé par le code du ticket.'), t('prizes_title', 'Titre de la liste des lots'))),
      card('Comment jouer', steps, { desc: 'Les trois étapes affichées sous la liste des lots.' }),
      card('Roue', h('div', { class: 'a-grid a-grid--2' },
        t('jackpot_label', 'Texte de la case grand prix', 'Modifiable aussi case par case dans l’onglet Roue.'),
        t('lose_label', 'Texte de la case perdante'), t('lose_sub', 'Deuxième ligne de la case perdante'), t('sold_out', 'Mention « épuisé »'))),
      card('Résultats', h('div', { class: 'a-grid a-grid--2' },
        t('win_title', 'Titre en cas de gain'), t('win_text', 'Phrase en cas de gain'),
        t('jackpot_title', 'Titre du grand prix'), t('jackpot_text', 'Phrase du grand prix'),
        t('lose_title', 'Titre en cas de perte'), t('lose_text', 'Phrase en cas de perte'))),
      card('Bon de gain et coordonnées', h('div', { class: 'a-grid a-grid--2' },
        t('voucher_hint', 'Consigne sur le bon de gain', null, true), t('claim_title', 'Titre du formulaire de coordonnées'),
        t('claim_privacy', 'Mention sous le formulaire', null, true), t('claim_thanks', 'Message après envoi', null, true))),
      card('Règlement et pied de page', h('div', { class: 'a-stack' },
        t('rules', 'Règlement du jeu', 'Affiché dans une fenêtre depuis le bas de la page. Un retour à la ligne = un paragraphe.', 8, 6000),
        t('footer', 'Texte du pied de page (facultatif)', null, 2, 400)))));
  };

  /* ───── Options & contact ───── */
  Admin.prototype.tabOptions = function () {
    var self = this, o = this.draft.settings.options, c = this.draft.settings.contact;
    var sw = function (key, label, small) { return switchEl(label, o[key], function (v) { o[key] = v; self.touch(); }, small); };
    var ci = function (key, label, ph, hint) {
      var el = input(c[key], { placeholder: ph, maxlength: '200' });
      el.addEventListener('input', function () { c[key] = el.value; self.touch(); });
      return field(label, el, hint);
    };
    this.tabBox.appendChild(h('div', { class: 'a-two' },
      h('div', { class: 'a-stack' },
        card('Après un gain', h('div', { class: 'a-stack' },
          sw('ask_details', 'Demander les coordonnées du gagnant', 'Le gagnant indique son nom et son téléphone : ils apparaissent dans l’espace livreur.'),
          sw('require_phone', 'Téléphone obligatoire'),
          sw('ask_address', 'Proposer un champ « adresse ou précisions »'))),
        card('Affichage', h('div', { class: 'a-stack' },
          sw('show_prizes', 'Afficher la liste des lots en jeu'),
          sw('show_values', 'Afficher la valeur des lots', 'Utilise le champ « valeur ou prix » des produits.'),
          sw('show_steps', 'Afficher « Comment jouer »'),
          sw('sound', 'Effets sonores', 'Cliquetis de la roue et jingles. Le client peut toujours couper le son.'),
          sw('confetti', 'Confettis en cas de gain')))),
      card('Contact', h('div', { class: 'a-stack' },
        ci('phone', 'Téléphone', 'Ex. 06 12 34 56 78'),
        ci('whatsapp', 'WhatsApp', 'Numéro au format international, ex. +212 6 12 34 56 78'),
        ci('instagram', 'Instagram', '@moncompte ou lien complet'),
        ci('facebook', 'Facebook', 'Nom de la page ou lien complet'),
        ci('website', 'Site web', 'Ex. www.monsite.com')), { desc: 'Affichés en bas de la page de jeu. Laissez vide ce que vous n’utilisez pas.' })));
  };

  /* ───── Adresse & réglages ───── */
  Admin.prototype.tabSettings = function () {
    var self = this, d = this.draft;
    var slug = input(d.slug, { maxlength: '60' });
    slug.addEventListener('input', function () { d.slug = slug.value.toLowerCase().replace(/[^a-z0-9\-]/g, '-'); self.touch(); });
    var domain = input(d.domain, { maxlength: '190', placeholder: 'Ex. jeu.monmagasin.com' });
    domain.addEventListener('input', function () { d.domain = domain.value.trim(); self.touch(); });
    var base = RDC.cfg.publicBase || '';
    var others = this.data.projects.filter(function (p) { return p.id !== d.id; });
    this.tabBox.appendChild(h('div', { class: 'a-two' },
      h('div', { class: 'a-stack' },
        card('Adresse du projet', h('div', { class: 'a-stack' },
          field('Adresse courte', slug, 'Utilisée dans le lien du projet : ' + base + '?p=' + d.slug),
          field('Nom de domaine dédié (facultatif)', domain, 'Si vous faites pointer un domaine vers ce même site, il ouvrira directement ce projet. Les 4 projets restent reliés à la même base de tickets.'))),
        card('Ouverture du jeu', switchEl('Jeu ouvert au public', d.active, function (v) { d.active = v; self.touch(); }, 'Fermé, la page affiche « Ce jeu est fermé » et aucun ticket ne peut y être joué. Les tickets restent valables sur les autres projets.'))),
      h('div', { class: 'a-stack' },
        card('Dupliquer', h('div', { class: 'a-stack' }, h('p', { class: 'a-hint', text: 'Crée un nouveau projet avec la même apparence, les mêmes textes, produits et roue.' }),
          btn('Dupliquer ce projet', 'copy', function () {
            RDC.api('adm.project.create', { name: d.name + ' (copie)', copy_from: d.id }).then(function (r) { self.data.projects = r.projects; RDC.toast('Projet dupliqué.', 'success'); self.navigate('/projet/' + r.project.id + '/identite'); }, function (e) { RDC.toast(e.message, 'error'); });
          }))),
        card('Supprimer', h('div', { class: 'a-stack' },
          h('p', { class: 'a-hint', text: this.proj.stats.plays ? 'Ce projet a déjà ' + RDC.fmt.plural(this.proj.stats.plays, 'partie', 'parties') + ' : fermez-le plutôt que de le supprimer, pour garder l’historique.' : 'Le projet, ses produits et sa roue seront supprimés. Les tickets ne sont pas touchés.' }),
          btn('Supprimer ce projet', 'trash', function () {
            RDC.confirm({ title: 'Supprimer « ' + d.name + ' » ?', message: 'Cette action est définitive.', confirm: 'Supprimer', danger: true }).then(function (ok) {
              if (ok) RDC.api('adm.project.delete', { id: d.id }).then(function (r) { self.data.projects = r.projects; self.setDirty(false); RDC.toast('Projet supprimé.', 'success'); self.navigate('/projets'); }, function (e) { RDC.toast(e.message, 'error'); });
            });
          }, 'btn--danger-ghost', { disabled: !!this.proj.stats.plays || !others.length }))))));
  };

  /* ════════════════ Paramètres ════════════════ */
  Admin.prototype.pageSettings = function () {
    var self = this;
    var s = clone(this.data.settings);
    var mark = function () { self.setDirty(true, save, function () { self.setDirty(false); self.go('/parametres'); }); };
    function save() {
      return RDC.api('adm.settings.save', { settings: s }).then(function (r) {
        self.data.settings = r.settings; self.data.public_base = r.public_base; RDC.cfg.publicBase = r.public_base;
        self.setDirty(false); RDC.toast('Paramètres enregistrés.', 'success'); self.go('/parametres');
      }, function (e) { RDC.toast(e.message, 'error'); throw e; });
    }
    var bind = function (obj, key, el) { el.addEventListener('input', function () { obj[key] = el.value; mark(); }); el.addEventListener('change', function () { obj[key] = el.value; mark(); }); return el; };
    this.main.appendChild(this.head('Paramètres', 'Réglages communs à tous les projets.'));
    var projOpts = this.data.projects.map(function (p) { return [p.slug, 'Le projet « ' + p.name + ' »']; });
    var baseIn = bind(s, 'base_url', input(s.base_url, { placeholder: this.data.detected_base }));
    var home = bind(s, 'home', select([['portal', 'Le portail (le client choisit son jeu)']].concat(projOpts), s.home));
    var tz = bind(s, 'timezone', select(this.data.timezones.map(function (z) { return [z, z.replace(/_/g, ' ')]; }), s.timezone));
    var tk = s.ticket;
    var linkSel = bind(tk, 'link', select([['portal', 'Le portail (valable pour tous les projets)']].concat(this.data.projects.map(function (p) { return [p.slug, 'Directement le projet « ' + p.name + ' »']; })), tk.link));
    this.main.appendChild(h('div', { class: 'a-two' },
      h('div', { class: 'a-stack' },
        card('Adresse utilisée dans les QR codes', h('div', { class: 'a-stack' },
          field('Adresse du site', baseIn, 'Laissez vide pour utiliser l’adresse actuelle : ' + this.data.detected_base),
          h('div', { class: 'a-alert a-alert--warn', html: RDC.icon('warning') + '<span>Les tickets déjà imprimés gardent l’adresse qu’ils contiennent. Choisissez-la avant d’imprimer, idéalement en <strong>https</strong>.</span>' }))),
        card('Page d’accueil et portail', h('div', { class: 'a-stack' },
          field('À l’ouverture de l’adresse principale, afficher', home, 'Un nom de domaine dédié à un projet ouvre toujours ce projet.'),
          field('Titre du portail', bind(s.portal, 'title', input(s.portal.title, { maxlength: '80' }))),
          field('Texte du portail', bind(s.portal, 'text', textarea(s.portal.text, { rows: '2', maxlength: '300' }))),
          h('div', { class: 'a-field' }, h('span', { class: 'a-label', text: 'Logo du portail (facultatif)' }), imageEl({ value: s.portal.logo, kind: 'portal', dark: true, onChange: function (v) { s.portal.logo = v; mark(); } })),
          h('p', { class: 'a-hint', text: 'Une fois entré dans un jeu, le client ne revient plus au portail : le jeu n’y renvoie jamais, le bouton Retour le fait sortir du site et un ticket déjà joué rouvre directement son jeu.' }))),
        card('Tickets imprimés', h('div', { class: 'a-stack' },
          field('Le QR code ouvre', linkSel, 'Le portail convient quand les mêmes tickets servent aux 4 projets. Le ticket reste utilisable sur tous les projets dans les deux cas.'),
          h('div', { class: 'a-grid a-grid--2' },
            field('Titre du ticket', bind(tk, 'title', input(tk.title, { maxlength: '60' }))),
            field('Phrase d’accroche', bind(tk, 'subtitle', input(tk.subtitle, { maxlength: '120' })))),
          field('Mention en bas du ticket', bind(tk, 'footer', input(tk.footer, { maxlength: '120' }))),
          h('div', { class: 'a-grid a-grid--2' },
            field('Style', bind(tk, 'style', select([['neon', 'Néon (fond sombre)'], ['light', 'Clair (économise l’encre)']], tk.style))),
            field('Tickets par page A4', bind(tk, 'layout', select([['8', '8 grands tickets'], ['10', '10 (format carte de visite)'], ['12', '12 moyens'], ['24', '24 petits (étiquettes)']], tk.layout)))))),
        card('Fuseau horaire', field('Heure utilisée pour les statistiques et les exports', tz))),
      h('div', { class: 'a-stack' },
        this.passwordCard(),
        this.diagCard(),
        card('Sauvegarde', h('div', { class: 'a-stack' },
          h('p', { class: 'a-hint', text: 'Téléchargez régulièrement une copie de la base (tickets, parties, réglages). En cas de problème, elle permet de tout restaurer.' }),
          btn('Télécharger une sauvegarde', 'download', function () { RDC.download('adm.backup', {}); }))),
        card('À propos', h('dl', { class: 'a-dl' }, h('dt', { text: 'Version' }), h('dd', { text: this.data.version }), h('dt', { text: 'Base de données' }), h('dd', { text: this.data.driver === 'mysql' ? 'MySQL' : 'SQLite (fichier)' }), h('dt', { text: 'Envoi d’images' }), h('dd', { text: 'jusqu’à ' + this.data.upload_max }))))));
  };

  Admin.prototype.passwordCard = function () {
    var self = this;
    if (RDC.cfg.demo) return card('Accès administrateur', h('p', { class: 'a-hint', text: 'Dans la démo, l’administration est ouverte sans identifiants. Sur votre site, vous vous connectez avec votre numéro de téléphone et votre mot de passe, et vous les changez ici quand vous voulez.' }));
    var phone = input(this.data.admin_phone || '', { type: 'tel', inputmode: 'tel', autocomplete: 'username', placeholder: '+212 6 12 34 56 78', maxlength: '24' });
    var cur = input('', { type: 'password', autocomplete: 'current-password' });
    var nw = input('', { type: 'password', autocomplete: 'new-password' });
    var nw2 = input('', { type: 'password', autocomplete: 'new-password' });
    var err = h('p', { class: 'a-err', role: 'alert' });
    var go = h('button', { type: 'submit', class: 'btn', text: 'Enregistrer' });
    var f = h('form', { class: 'a-stack', novalidate: true },
      field('Numéro de téléphone (identifiant)', phone, 'Avec l’indicatif du pays. À la connexion, le numéro peut aussi s’écrire avec le 0 de votre pays.'),
      field('Nouveau mot de passe', nw, 'Laissez vide pour garder le mot de passe actuel. 8\u00a0caractères minimum.'),
      field('Confirmez le nouveau mot de passe', nw2),
      field('Mot de passe actuel', cur, 'Demandé pour toute modification.'),
      err, h('div', {}, go));
    f.addEventListener('submit', function (e) {
      e.preventDefault(); err.textContent = '';
      if (nw.value !== nw2.value) { err.textContent = 'Les deux nouveaux mots de passe ne sont pas identiques.'; return; }
      if (!cur.value) { err.textContent = 'Indiquez votre mot de passe actuel.'; return; }
      RDC.busy(go, RDC.api('adm.password', { phone: phone.value, current: cur.value, new: nw.value })).then(function (r) {
        cur.value = nw.value = nw2.value = '';
        self.data.admin_phone = r.phone; phone.value = r.phone;
        if (r.phone) self.phoneLogin = true;
        var pwd = r.changed.indexOf('password') >= 0, ph = r.changed.indexOf('phone') >= 0;
        if (pwd) self.data.default_password = false;
        RDC.toast(pwd && ph ? 'Numéro et mot de passe modifiés. Les autres appareils sont déconnectés.' : pwd ? 'Mot de passe modifié. Les autres appareils sont déconnectés.' : 'Numéro de téléphone modifié.', 'success', 5000);
      }, function (ex) { err.textContent = ex.message; });
    });
    return card('Accès administrateur', f, { desc: 'Votre identifiant de connexion et votre mot de passe. Vous pouvez les changer à tout moment.' });
  };

  Admin.prototype.diagCard = function () {
    var box = h('div', { class: 'a-stack' });
    var run = btn('Lancer le diagnostic', 'shield', function () {
      RDC.busy(run, RDC.api('adm.diagnostic')).then(function (r) {
        RDC.clear(box);
        var list = h('div', {});
        r.checks.forEach(function (c) { list.appendChild(h('div', { class: 'a-check ' + (c.ok ? 'is-ok' : 'is-ko') }, RDC.iconEl(c.ok ? 'check' : 'warning'), h('div', {}, h('strong', { text: c.label }), h('div', { class: 'a-check__d', text: c.detail })))); });
        box.appendChild(list);
        if (!RDC.cfg.demo && r.protected && r.protected.length) {
          var row = h('div', { class: 'a-check' }, h('span', { class: 'rdc-spinner', style: { width: '20px', height: '20px' } }), h('div', {}, h('strong', { text: 'Fichiers internes protégés' }), h('div', { class: 'a-check__d', text: 'Vérification depuis votre navigateur…' })));
          list.appendChild(row);
          Promise.all(r.protected.map(function (p) { return fetch(RDC.cfg.base + p, { cache: 'no-store', credentials: 'omit' }).then(function (x) { return x.status; }, function () { return 0; }); })).then(function (codes) {
            var open = codes.some(function (c) { return c === 200; });
            RDC.clear(row);
            row.className = 'a-check ' + (open ? 'is-ko' : 'is-ok');
            row.appendChild(RDC.iconEl(open ? 'warning' : 'check'));
            row.appendChild(h('div', {}, h('strong', { text: 'Fichiers internes protégés' }), h('div', { class: 'a-check__d', text: open ? 'Attention : la base de données est téléchargeable depuis Internet. Ajoutez les règles de protection (voir le guide, section « Serveur Nginx ») ou placez le dossier data/ hors du site.' : 'La base de données et les fichiers internes ne sont pas accessibles depuis Internet.' })));
          });
        }
      }, function (e) { RDC.toast(e.message, 'error'); });
    });
    return card('Diagnostic', h('div', { class: 'a-stack' }, h('p', { class: 'a-hint', text: 'Vérifie votre hébergement, dont un test réel d’utilisation unique d’un ticket sur la base de données.' }), h('div', {}, run), box));
  };

  /* ════════════════ Aide ════════════════ */
  Admin.prototype.pageHelp = function () {
    var self = this;
    var sec = function (title, nodes) { return card(null, h('div', { class: 'a-help' }, h('h2', { text: title }), nodes)); };
    var ol = function (items) { return h('ol', {}, items.map(function (x) { return h('li', { html: x }); })); };
    this.main.appendChild(this.head('Aide & mode d’emploi', 'L’essentiel pour lancer et gérer vos jeux.'));
    this.main.appendChild(h('div', { class: 'a-stack' },
      sec('Le principe', h('p', { html: 'Vos <strong>' + this.data.projects.length + ' projets</strong> fonctionnent sur la même installation et la même base de données. Chaque ticket existe en un seul exemplaire dans cette base : quand un client le joue sur un projet, il est marqué « joué » en une seule opération, et les autres projets le refusent immédiatement. Il n’y a rien à synchroniser, donc aucun délai ni risque de double utilisation.' })),
      sec('Lancer une campagne', ol([
        'Dans <a href="' + this.href('/parametres') + '">Paramètres</a>, vérifiez l’adresse utilisée dans les QR codes (en https).',
        'Personnalisez chaque projet : logo, nom, couleurs, produits (nom, grammage, photo) et cases de la roue.',
        'Dans <a href="' + this.href('/tickets') + '">Tickets & QR codes</a>, désactivez la série « Codes d’essai » puis générez votre série.',
        'Imprimez les tickets (ou exportez la liste pour un imprimeur) et distribuez-les avec vos commandes.'
      ])),
      sec('Côté client', ol([
        'Le client scanne le QR code de son ticket avec l’appareil photo de son téléphone : la page du jeu s’ouvre avec son ticket déjà reconnu (ou le portail s’il doit choisir son projet).',
        'Il lance la roue. Le résultat est tiré par le serveur, selon les chances que vous avez fixées et le stock disponible.',
        'S’il gagne, il obtient un bon de gain (avec QR code) et peut laisser ses coordonnées.'
      ])),
      sec('Côté livreur', ol([
        'Créez un livreur dans <a href="' + this.href('/livreurs') + '">Livreurs</a> et donnez-lui son code.',
        'Il ouvre l’espace livreur sur son téléphone : un seul outil pour les tickets de tous les projets.',
        'Il scanne le ticket ou le bon du client : l’écran indique en grand « Lot à remettre », « Déjà remis », « Perdant » ou « Code inconnu ».',
        'Après la remise, il confirme : le lot ne pourra plus jamais être remis une deuxième fois.'
      ])),
      sec('Bonnes pratiques', h('ul', {}, [
        'Activez le certificat <strong>https</strong> de votre hébergement : il protège les échanges et permet de scanner avec la caméra depuis le site.',
        'Utilisez les stocks pour plafonner les gros lots (par exemple 1 grand prix par mois).',
        'Téléchargez une sauvegarde chaque semaine depuis Paramètres.',
        'Lancez le diagnostic après l’installation et après tout changement d’hébergement.'
      ].map(function (x) { return h('li', { html: x }); })))));
  };

  RDC.apps.Admin = {
    mount: function (root, boot) {
      var a = new Admin(root, boot);
      return { app: a, destroy: function () {
        window.removeEventListener('hashchange', a.onHash);
        window.removeEventListener('beforeunload', a.onUnload);
        if (a.savebar) a.savebar.remove();
        if (a.previewWheel) a.previewWheel.destroy();
        RDC.onAuthLost = null;
        RDC.closeAllModals();
      } };
    }
  };
})();
