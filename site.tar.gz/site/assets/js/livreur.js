/*!
 * Roue de la Chance — espace livreur.
 * Un seul écran pour vérifier n'importe quel ticket, quel que soit le projet, et confirmer la remise des lots.
 */
(function () {
  'use strict';
  var RDC = window.RDC;
  var h = RDC.h;
  var NB = ' ';

  function Livreur(root, boot) {
    this.root = root;
    this.boot = boot;
    this.me = null;
    this.projects = [];
    this.tab = 'check';
    this.filter = 0;
    this.recent = [];
    this.pendingCount = 0;
    var self = this;
    RDC.onAuthLost = function () { self.showLogin(); };
    RDC.api('liv.me').then(function (r) { if (r.livreur) self.signedIn(r); else self.showLogin(); }, function () { self.showLogin(); });
  }

  /* ───── Connexion par code ───── */
  Livreur.prototype.showLogin = function () {
    var self = this;
    this.me = null;
    RDC.clear(this.root);
    var pin = '';
    var dots = h('div', { class: 'l-pin', 'aria-hidden': 'true' });
    var err = h('p', { class: 'l-pinerr', role: 'alert' });
    var live = h('p', { class: 'sr-only', 'aria-live': 'polite' });
    var okBtn = h('button', { type: 'button', class: 'l-key l-key--ok', text: 'Entrer' });
    function paint() {
      RDC.clear(dots);
      var n = Math.max(6, pin.length);
      for (var i = 0; i < n; i++) dots.appendChild(h('i', { class: i < pin.length ? 'is-on' : '' }));
      live.textContent = pin.length + ' chiffre' + (pin.length > 1 ? 's' : '') + ' saisi' + (pin.length > 1 ? 's' : '');
    }
    function press(k) {
      err.textContent = ''; dots.classList.remove('is-error');
      if (k === 'del') pin = pin.slice(0, -1);
      else if (pin.length < 8) pin += k;
      paint();
    }
    function submit() {
      if (pin.length < 6) { err.textContent = 'Le code compte au moins 6 chiffres.'; return; }
      RDC.sfx.unlock();
      RDC.busy(okBtn, RDC.api('liv.login', { pin: pin })).then(function (r) {
        RDC.sfx.beep();
        self.signedIn(r);
      }, function (e) {
        pin = ''; paint();
        dots.classList.add('is-error');
        err.textContent = e.message;
        RDC.sfx.error();
        if (navigator.vibrate) try { navigator.vibrate([80, 60, 80]); } catch (x) { /* rien */ }
      });
    }
    var pad = h('div', { class: 'l-pad' });
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'del', '0'].forEach(function (k) {
      pad.appendChild(h('button', { type: 'button', class: 'l-key', 'aria-label': k === 'del' ? 'Effacer' : k, html: k === 'del' ? RDC.icon('back') : k, onclick: function () { press(k); } }));
    });
    okBtn.addEventListener('click', submit);
    pad.appendChild(okBtn);
    this.keyHandler && document.removeEventListener('keydown', this.keyHandler);
    this.keyHandler = function (e) {
      if (self.me) return;
      if (/^\d$/.test(e.key)) press(e.key);
      else if (e.key === 'Backspace') press('del');
      else if (e.key === 'Enter') submit();
    };
    document.addEventListener('keydown', this.keyHandler);
    paint();
    this.root.appendChild(h('div', { class: 'l-root' }, h('main', { class: 'l-login' }, h('div', { class: 'l-login__box' },
      h('h1', { class: 'l-login__t', text: 'Espace livreur' }),
      h('p', { class: 'l-login__s', text: 'Saisissez votre code personnel pour vérifier les tickets et remettre les lots.' }),
      dots, live, err, pad))));
  };

  Livreur.prototype.signedIn = function (r) {
    this.me = r.livreur;
    this.projects = r.projects || [];
    this.pendingCount = r.pending || 0;
    if (this.keyHandler) { document.removeEventListener('keydown', this.keyHandler); this.keyHandler = null; }
    this.render();
    this.refreshCount();
  };

  Livreur.prototype.project = function (id) {
    for (var i = 0; i < this.projects.length; i++) if (this.projects[i].id === id) return this.projects[i];
    return null;
  };

  /* ───── Écran principal ───── */
  Livreur.prototype.render = function () {
    var self = this;
    RDC.clear(this.root);
    this.tabCheck = h('button', { type: 'button', class: 'l-tab', role: 'tab', html: RDC.icon('scan') + '<span>Vérifier</span>', onclick: function () { self.go('check'); } });
    this.countEl = h('span', { class: 'l-count' });
    this.tabPending = h('button', { type: 'button', class: 'l-tab', role: 'tab', onclick: function () { self.go('pending'); } }, h('span', { text: 'À remettre' }), this.countEl);
    this.main = h('main', { class: 'l-main' });
    this.root.appendChild(h('div', { class: 'l-root' },
      h('header', { class: 'l-top' },
        h('div', { class: 'l-brand' }, h('p', { class: 'l-brand__t', text: 'Espace livreur' }), h('p', { class: 'l-brand__who', text: this.me.name + (this.me.admin ? ' (accès administrateur)' : '') })),
        h('button', { type: 'button', class: 'l-iconbtn', 'aria-label': 'Se déconnecter', title: 'Se déconnecter', html: RDC.icon('logout'), onclick: function () { self.logout(); } })),
      h('div', { class: 'l-tabs', role: 'tablist' }, this.tabCheck, this.tabPending),
      this.main));
    this.paintCount();
    this.go(this.tab);
  };

  Livreur.prototype.paintCount = function () {
    if (!this.countEl) return;
    this.countEl.textContent = String(this.pendingCount);
    this.countEl.classList.toggle('is-zero', !this.pendingCount);
  };

  Livreur.prototype.refreshCount = function () {
    var self = this;
    RDC.api('liv.pending', {}).then(function (r) { self.pendingCount = r.items.length; self.paintCount(); }, function () {});
  };

  Livreur.prototype.go = function (tab) {
    this.tab = tab;
    this.tabCheck.setAttribute('aria-selected', tab === 'check' ? 'true' : 'false');
    this.tabPending.setAttribute('aria-selected', tab === 'pending' ? 'true' : 'false');
    RDC.clear(this.main);
    if (tab === 'check') this.renderCheck(); else this.renderPending();
  };

  Livreur.prototype.logout = function () {
    var self = this;
    RDC.confirm({ title: 'Se déconnecter ?', message: 'Vous devrez saisir à nouveau votre code pour revenir.', confirm: 'Se déconnecter', confirmClass: 'l-btn l-btn--go', cancelClass: 'l-btn' })
      .then(function (ok) { if (ok) RDC.api('liv.logout').then(function () { self.showLogin(); }, function () { self.showLogin(); }); });
  };

  /* ───── Vérifier un ticket ───── */
  Livreur.prototype.renderCheck = function () {
    var self = this;
    var input = h('input', { class: 'l-input', type: 'text', inputmode: 'text', autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false', maxlength: '11', placeholder: 'XXXXX-XXXXX', 'aria-label': 'Code du ticket' });
    input.addEventListener('input', function () { input.value = RDC.code.typing(input.value); });
    var go = h('button', { type: 'submit', class: 'l-btn l-btn--go', text: 'Vérifier' });
    var form = h('form', { class: 'l-manual', novalidate: true }, input, go);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      RDC.sfx.unlock();
      var c = RDC.code.normalize(input.value);
      if (!c) { self.showVerdict({ tone: 'red', icon: 'warning', title: 'Code mal saisi', sub: 'Vérifiez les 10 caractères (sans O, I, L, 0 ni 1).' }); RDC.sfx.error(); return; }
      RDC.busy(go, self.lookup(c)).then(function () { input.value = ''; });
    });
    this.verdictBox = h('div', { 'aria-live': 'polite' });
    this.recentBox = h('div', {});
    this.main.appendChild(h('button', { type: 'button', class: 'l-scan', html: RDC.icon('scan') + '<span>Scanner un ticket</span>', onclick: function () { self.scan(); } }));
    this.main.appendChild(form);
    this.main.appendChild(h('p', { class: 'l-help', text: 'Valable pour les tickets de tous les projets.' }));
    this.main.appendChild(this.verdictBox);
    this.main.appendChild(this.recentBox);
    if (this.last) this.showLookup(this.last);
    this.paintRecent();
  };

  Livreur.prototype.scan = function () {
    var self = this;
    RDC.sfx.unlock();
    RDC.Scanner.open({
      title: 'Vérifier un ticket',
      hint: 'Visez le QR code du ticket ou du bon de gain du client.',
      accent: '#18E7FF',
      onResult: function (text) {
        var c = RDC.code.normalize(text);
        if (!c) return 'Ce QR code n’est pas un ticket du jeu.';
        RDC.sfx.beep();
        self.lookup(c);
        return true;
      },
      onManual: function () { var i = RDC.$('.l-input', self.main); if (i) i.focus(); }
    });
  };

  Livreur.prototype.lookup = function (code) {
    var self = this;
    if (this.tab !== 'check') this.go('check');
    return RDC.api('liv.lookup', { code: code }).then(function (r) {
      self.last = r;
      self.showLookup(r, true);
      self.remember(r);
    }, function (e) {
      self.last = null;
      if (e.code === 'invalid') self.showVerdict({ tone: 'red', icon: 'close', title: 'Code inconnu', sub: 'Ce ticket n’a pas été émis par votre système. Ne remettez aucun lot.' }, true);
      else if (e.code === 'format') self.showVerdict({ tone: 'red', icon: 'warning', title: 'Code illisible', sub: e.message }, true);
      else RDC.toast(e.message, 'error');
      RDC.sfx.error();
    });
  };

  /** Traduit la réponse du serveur en verdict clair pour le livreur. */
  Livreur.prototype.describe = function (r) {
    var res = r.result;
    if (r.status === 'void') return { tone: 'red', icon: 'close', title: 'Ticket désactivé', sub: 'Désactivé par l’administrateur : aucun lot à remettre.' };
    if (r.status === 'new') return { tone: 'blue', icon: 'ticket', title: 'Pas encore joué', sub: 'Ticket valide. Le client doit d’abord jouer pour savoir s’il a gagné.' };
    if (!res) return { tone: 'gray', icon: 'info', title: 'Ticket utilisé', sub: 'Aucune partie associée.' };
    if (res.kind === 'lose') return { tone: 'gray', icon: 'sad', title: 'Ticket perdant', sub: 'Aucun lot à remettre.' };
    if (res.status === 'pending') return { tone: 'green', icon: 'gift', title: res.kind === 'jackpot' ? 'Grand prix à remettre' : 'Lot à remettre', sub: 'Remettez ce lot puis confirmez la remise.' };
    if (res.status === 'delivered') return { tone: 'amber', icon: 'warning', title: 'Déjà remis', sub: 'Remis le ' + RDC.fmt.date(res.delivered_at) + (res.delivered_by ? ' par ' + res.delivered_by : '') + '. Ne le remettez pas une seconde fois.' };
    if (res.status === 'cancelled') return { tone: 'red', icon: 'close', title: 'Gain annulé', sub: 'Annulé par l’administrateur : aucun lot à remettre.' };
    return { tone: 'gray', icon: 'info', title: 'Statut inconnu', sub: '' };
  };

  Livreur.prototype.showLookup = function (r, fresh) {
    var self = this;
    var v = this.describe(r);
    var res = r.result;
    var body = [];
    if (res && res.prize) {
      body.push(h('div', { class: 'l-prize' },
        res.prize.photo ? h('img', { src: RDC.asset(res.prize.photo), alt: '' }) : null,
        h('div', {}, h('p', { class: 'l-prize__name', text: res.prize.name }), res.prize.weight ? h('p', { class: 'l-prize__meta', text: res.prize.weight }) : null)));
    }
    var rows = [['Ticket', h('span', { class: 'l-code', text: r.code })]];
    if (res && res.project) rows.push(['Jeu', this.projChip(res.project)]);
    if (res) rows.push(['Joué', RDC.fmt.date(res.played_at)]);
    if (res && res.customer && (res.customer.name || res.customer.phone)) {
      rows.push(['Client', res.customer.name || '—']);
      if (res.customer.phone) rows.push(['Téléphone', h('a', { href: 'tel:' + res.customer.phone.replace(/[^\d+]/g, ''), text: res.customer.phone })]);
      if (res.customer.note) rows.push(['Adresse', res.customer.note]);
    } else if (res && res.kind !== 'lose' && res.status === 'pending') {
      rows.push(['Client', h('span', { style: { color: 'var(--l-muted)', fontWeight: '600' }, text: 'Coordonnées non renseignées' })]);
    }
    if (r.batch) rows.push(['Série', r.batch]);
    body.push(h('dl', { class: 'l-rows' }, rows.map(function (x) { return h('div', { class: 'l-row' }, h('dt', { text: x[0] }), h('dd', {}, x[1])); })));
    if (res && res.status === 'pending' && res.kind !== 'lose') {
      body.push(h('button', { type: 'button', class: 'l-btn l-btn--ok l-btn--block', style: { minHeight: '62px', fontSize: '18px' }, html: RDC.icon('check') + '<span>Confirmer la remise du lot</span>', onclick: function (e) { self.deliver(r, e.currentTarget); } }));
    }
    this.showVerdict(v, fresh, body);
  };

  Livreur.prototype.showVerdict = function (v, fresh, body) {
    if (!this.verdictBox) return;
    RDC.clear(this.verdictBox);
    var card = h('section', { class: 'l-verdict tone-' + v.tone },
      h('div', { class: 'l-verdict__head', html: RDC.icon(v.icon) }, h('div', {}, h('p', { class: 'l-verdict__title', text: v.title }), v.sub ? h('p', { class: 'l-verdict__sub', text: v.sub }) : null)),
      body && body.length ? h('div', { class: 'l-verdict__body' }, body) : null);
    this.verdictBox.appendChild(card);
    if (fresh) {
      if (v.tone === 'green') RDC.sfx.unlockWheel();
      else if (v.tone === 'red' || v.tone === 'amber') RDC.sfx.error();
      if (navigator.vibrate) try { navigator.vibrate(v.tone === 'green' ? 80 : [120, 80, 120]); } catch (e) { /* rien */ }
      if (card.scrollIntoView) card.scrollIntoView({ behavior: RDC.reducedMotion() ? 'auto' : 'smooth', block: 'nearest' });
    }
  };

  Livreur.prototype.projChip = function (p) {
    var chip = h('span', { class: 'l-proj' }, p.logo ? h('img', { src: RDC.asset(p.logo), alt: '' }) : h('i', {}), h('span', { text: p.name }));
    chip.style.setProperty('--pc', p.c1 || '#fff');
    return chip;
  };

  Livreur.prototype.deliver = function (r, btn) {
    var self = this;
    var res = r.result;
    RDC.confirm({
      title: 'Confirmer la remise ?',
      message: (res.prize ? res.prize.name + (res.prize.weight ? ' (' + res.prize.weight + ')' : '') : 'Lot') + ' remis au client' + (res.customer && res.customer.name ? ' ' + res.customer.name : '') + '. Cette action est définitive pour vous.',
      confirm: 'Oui, lot remis', confirmClass: 'l-btn l-btn--ok', cancelClass: 'l-btn'
    }).then(function (ok) {
      if (!ok) return;
      RDC.busy(btn, RDC.api('liv.deliver', { code: r.code })).then(function (x) {
        r.result = x.result;
        self.last = r;
        self.showLookup(r);
        self.remember(r);
        RDC.toast('Remise enregistrée.', 'success');
        RDC.sfx.win();
        self.refreshCount();
      }, function (e) {
        if (e.data && e.data.result) { r.result = e.data.result; self.showLookup(r, true); }
        RDC.toast(e.message, 'error');
      });
    });
  };

  Livreur.prototype.remember = function (r) {
    var v = this.describe(r);
    this.recent = [{ r: r, v: v, at: new Date().toISOString() }].concat(this.recent.filter(function (x) { return x.r.code !== r.code; })).slice(0, 6);
    this.paintRecent();
  };

  Livreur.prototype.paintRecent = function () {
    var self = this;
    if (!this.recentBox) return;
    RDC.clear(this.recentBox);
    if (this.recent.length < 2) return;
    this.recentBox.appendChild(h('p', { class: 'l-h2', text: 'Dernières vérifications' }));
    this.recentBox.appendChild(h('div', { class: 'l-recent' }, this.recent.slice(1).map(function (x) {
      var b = h('button', { type: 'button', onclick: function () { self.lookup(x.r.code.replace('-', '')); } },
        h('i', { class: 'l-dot tone-' + x.v.tone }),
        h('span', { class: 'l-recent__t', text: x.r.code + NB + '· ' + x.v.title }),
        h('span', { class: 'l-recent__d', text: RDC.fmt.relative(x.at) }));
      return b;
    })));
  };

  /* ───── Lots à remettre (tous projets) ───── */
  Livreur.prototype.renderPending = function () {
    var self = this;
    var chips = h('div', { class: 'l-chips', role: 'group', 'aria-label': 'Filtrer par projet' });
    var list = h('div', { class: 'l-list', 'aria-live': 'polite' }, h('p', { class: 'l-help', text: 'Chargement…' }));
    var all = [{ id: 0, name: 'Tous les projets' }].concat(this.projects);
    all.forEach(function (p) {
      var c = h('button', { type: 'button', class: 'l-chip', 'aria-pressed': self.filter === p.id ? 'true' : 'false', onclick: function () { self.filter = p.id; self.go('pending'); } },
        p.id ? h('i', {}) : null, h('span', { text: p.name }));
      if (p.c1) c.style.setProperty('--pc', p.c1);
      chips.appendChild(c);
    });
    this.main.appendChild(chips);
    this.main.appendChild(list);
    RDC.api('liv.pending', { project_id: this.filter }).then(function (r) {
      RDC.clear(list);
      if (!self.filter) { self.pendingCount = r.items.length; self.paintCount(); }
      if (!r.items.length) {
        list.appendChild(h('div', { class: 'l-empty', html: RDC.icon('check') + '<strong>Rien à remettre</strong>Tous les lots gagnés ont été remis.' }));
        return;
      }
      r.items.forEach(function (it) { list.appendChild(self.pendingItem(it)); });
    }, function (e) { RDC.clear(list); list.appendChild(h('p', { class: 'l-help', text: e.message })); });
  };

  Livreur.prototype.pendingItem = function (it) {
    var self = this;
    var pz = it.prize || {};
    var cust = it.customer || {};
    var call = cust.phone ? h('a', { class: 'l-call', href: 'tel:' + cust.phone.replace(/[^\d+]/g, ''), html: RDC.icon('phone') + '<span>' + RDC.esc(cust.phone) + '</span>' }) : null;
    var deliverBtn = h('button', { type: 'button', class: 'l-btn l-btn--ok', html: RDC.icon('check') + '<span>Remis</span>' });
    var card = h('article', { class: 'l-item' },
      h('div', { class: 'l-item__top' },
        pz.photo ? h('img', { src: RDC.asset(pz.photo), alt: '' }) : null,
        h('div', { style: { minWidth: '0' } },
          h('p', { class: 'l-item__name' }, it.kind === 'jackpot' ? h('span', { class: 'l-jack', text: 'Grand prix' }) : null, h('span', { text: pz.name }), pz.weight ? h('span', { class: 'l-item__w', text: ' ' + pz.weight }) : null),
          h('div', { class: 'l-item__meta' }, it.project ? this.projChip(it.project) : null, h('span', { text: RDC.fmt.relative(it.played_at) }), h('span', { class: 'l-code', style: { fontSize: '15px' }, text: it.code })))),
      (cust.name || cust.note) ? h('p', { class: 'l-item__who' }, cust.name ? h('strong', { text: cust.name }) : null, cust.note ? h('span', { text: cust.note }) : null)
        : h('p', { class: 'l-item__who', style: { color: 'var(--l-muted)' }, text: 'Le client n’a pas encore laissé ses coordonnées.' }),
      h('div', { class: 'l-item__acts' }, call, deliverBtn));
    deliverBtn.addEventListener('click', function () {
      RDC.confirm({ title: 'Confirmer la remise ?', message: pz.name + (cust.name ? ' remis à ' + cust.name : ' remis au client') + '.', confirm: 'Oui, lot remis', confirmClass: 'l-btn l-btn--ok', cancelClass: 'l-btn' })
        .then(function (ok) {
          if (!ok) return;
          RDC.busy(deliverBtn, RDC.api('liv.deliver', { code: it.code })).then(function () {
            card.remove();
            self.pendingCount = Math.max(0, self.pendingCount - 1);
            self.paintCount();
            RDC.toast('Remise enregistrée.', 'success');
            RDC.sfx.win();
            if (!RDC.$('.l-item', self.main)) self.go('pending');
          }, function (e) { RDC.toast(e.message, 'error'); self.go('pending'); });
        });
    });
    return card;
  };

  RDC.apps.Livreur = {
    mount: function (root, boot) {
      var l = new Livreur(root, boot);
      return { app: l, destroy: function () { if (l.keyHandler) document.removeEventListener('keydown', l.keyHandler); RDC.onAuthLost = null; RDC.closeAllModals(); } };
    }
  };
})();
