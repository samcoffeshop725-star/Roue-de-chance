/*!
 * Roue de la Chance — scanner de QR code par la caméra.
 * Utilise le détecteur natif du navigateur s'il existe, sinon la bibliothèque jsQR
 * (chargée depuis assets/vendor/jsQR.js si vous l'y déposez, sinon depuis jsDelivr).
 */
(function () {
  'use strict';
  var RDC = window.RDC;
  var h = RDC.h;
  var JSQR_URLS = function () { return [RDC.cfg.base + 'assets/vendor/jsQR.js', 'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js']; };

  function getDecoder() {
    if ('BarcodeDetector' in window) {
      return Promise.resolve(window.BarcodeDetector.getSupportedFormats ? window.BarcodeDetector.getSupportedFormats() : ['qr_code'])
        .then(function (formats) {
          if (formats.indexOf('qr_code') >= 0) {
            var det = new window.BarcodeDetector({ formats: ['qr_code'] });
            return function (video) {
              return det.detect(video).then(function (codes) { return codes && codes[0] ? codes[0].rawValue : null; });
            };
          }
          return jsqrDecoder();
        }, jsqrDecoder);
    }
    return jsqrDecoder();
  }

  function jsqrDecoder() {
    var load = window.jsQR ? Promise.resolve() : RDC.loadScript(JSQR_URLS());
    return load.then(function () {
      if (!window.jsQR) throw new Error('jsqr');
      var canvas = document.createElement('canvas');
      var ctx = canvas.getContext('2d', { willReadFrequently: true });
      var flip = false;
      return function (video) {
        var vw = video.videoWidth, vh = video.videoHeight;
        if (!vw || !vh) return Promise.resolve(null);
        var scale = Math.min(1, 720 / Math.max(vw, vh));
        var w = Math.round(vw * scale), hh = Math.round(vh * scale);
        if (canvas.width !== w) canvas.width = w;
        if (canvas.height !== hh) canvas.height = hh;
        ctx.drawImage(video, 0, 0, w, hh);
        var img = ctx.getImageData(0, 0, w, hh);
        flip = !flip;
        var r = window.jsQR(img.data, w, hh, { inversionAttempts: flip ? 'dontInvert' : 'onlyInvert' });
        return Promise.resolve(r ? r.data : null);
      };
    });
  }

  /**
   * Ouvre le scanner plein écran.
   * opts: { title, hint, accent, onResult(text) -> Promise|boolean (true = fermer), onManual(), onClose() }
   */
  function open(opts) {
    opts = opts || {};
    var stream = null, raf = null, stopped = false, busy = false, torchOn = false, track = null;
    var video = h('video', { playsinline: true, muted: true, autoplay: true });
    video.muted = true;
    var msg = h('div', { class: 'rdc-scan__msg', hidden: true });
    var frame = h('div', { class: 'rdc-scan__frame' }, h('div', { class: 'rdc-scan__laser' }));
    var torchBtn = h('button', { type: 'button', class: 'rdc-scan__btn', hidden: true, 'aria-label': 'Lampe', html: RDC.icon('flash') });
    var closeBtn = h('button', { type: 'button', class: 'rdc-scan__btn', 'aria-label': 'Fermer le scanner', html: RDC.icon('close') });
    var manualBtn = h('button', { type: 'button', class: 'rdc-scan__btn', html: RDC.icon('keyboard') + '<span>' + RDC.esc(opts.manualLabel || 'Saisir le code') + '</span>' });
    var view = h('div', { class: 'rdc-scan__view' }, video, frame, msg);
    var root = h('div', { class: 'rdc-scan', role: 'dialog', 'aria-modal': 'true', 'aria-label': opts.title || 'Scanner un QR code' },
      h('div', { class: 'rdc-scan__top' }, closeBtn, h('div', { class: 'rdc-scan__title', text: opts.title || 'Scanner le QR code' }), torchBtn),
      view,
      h('div', { class: 'rdc-scan__bottom' }, h('p', { class: 'rdc-scan__hint', text: opts.hint || 'Placez le QR code dans le cadre.' }), opts.onManual ? manualBtn : null)
    );
    if (opts.accent) root.style.setProperty('--scan-accent', opts.accent);
    document.body.appendChild(root);
    document.documentElement.classList.add('rdc-noscroll');

    function show(text) { msg.hidden = !text; msg.textContent = text || ''; }
    function stop() {
      stopped = true;
      cancelAnimationFrame(raf);
      if (stream) stream.getTracks().forEach(function (t) { t.stop(); });
      stream = null;
    }
    function close(silent) {
      stop();
      document.removeEventListener('keydown', onKey);
      root.remove();
      document.documentElement.classList.remove('rdc-noscroll');
      if (!silent && opts.onClose) opts.onClose();
    }
    function onKey(e) { if (e.key === 'Escape') close(); }
    document.addEventListener('keydown', onKey);
    closeBtn.addEventListener('click', function () { close(); });
    manualBtn.addEventListener('click', function () { close(true); opts.onManual(); });
    torchBtn.addEventListener('click', function () {
      if (!track) return;
      torchOn = !torchOn;
      track.applyConstraints({ advanced: [{ torch: torchOn }] }).then(function () { torchBtn.classList.toggle('is-on', torchOn); }, function () { torchOn = false; });
    });

    var secure = window.isSecureContext || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !secure) {
      frame.hidden = true;
      show(!secure ? 'La caméra n’est accessible que sur une connexion sécurisée (https). Saisissez le code à la place.' : 'Votre navigateur ne permet pas d’utiliser la caméra ici. Saisissez le code à la place.');
      return { close: close };
    }

    show('Ouverture de la caméra…');
    Promise.all([
      navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false }),
      getDecoder().catch(function () { return null; })
    ]).then(function (res) {
      if (stopped) { res[0].getTracks().forEach(function (t) { t.stop(); }); return; }
      stream = res[0];
      var decode = res[1];
      video.srcObject = stream;
      track = stream.getVideoTracks()[0];
      try {
        var caps = track.getCapabilities ? track.getCapabilities() : {};
        if (caps && caps.torch) torchBtn.hidden = false;
      } catch (e) { /* pas de lampe */ }
      return video.play().catch(function () {}).then(function () {
        if (!decode) { show('Lecture automatique indisponible sur cet appareil. Utilisez l’appareil photo du téléphone ou saisissez le code.'); return; }
        show('');
        var last = 0;
        (function loop(now) {
          if (stopped) return;
          raf = requestAnimationFrame(loop);
          if (busy || now - last < 140 || video.readyState < 2) return;
          last = now;
          busy = true;
          decode(video).then(function (text) {
            if (!text || stopped) { busy = false; return; }
            root.classList.add('is-found');
            if (navigator.vibrate) try { navigator.vibrate(60); } catch (e) { /* rien */ }
            return Promise.resolve(opts.onResult ? opts.onResult(text) : true).then(function (done) {
              if (done === true) { close(true); return; }
              root.classList.remove('is-found');
              if (typeof done === 'string') show(done);
              setTimeout(function () { busy = false; }, 1200);
            });
          }).catch(function () { busy = false; });
        })(0);
      });
    }).catch(function (err) {
      frame.hidden = true;
      var name = err && err.name;
      if (name === 'NotAllowedError' || name === 'SecurityError') show('Accès à la caméra refusé. Autorisez la caméra pour ce site dans les réglages du navigateur, ou saisissez le code.');
      else if (name === 'NotFoundError' || name === 'OverconstrainedError') show('Aucune caméra disponible sur cet appareil. Saisissez le code à la place.');
      else if (name === 'NotReadableError') show('La caméra est utilisée par une autre application. Fermez-la puis réessayez.');
      else show('Impossible d’ouvrir la caméra. Saisissez le code à la place.');
    });

    return { close: close, show: show };
  }

  RDC.Scanner = { open: open };
})();
