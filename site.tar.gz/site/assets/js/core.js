/*!
 * Roue de la Chance — noyau commun (outils DOM, API, codes, couleurs, fenêtres, messages).
 */
(function () {
  'use strict';
  var RDC = window.RDC = window.RDC || {};

  /* ───────────── DOM ───────────── */
  /** Typographie française : espace insécable avant « : ; ! ? » et après « (textes affichés uniquement). */
  function typo(s) {
    s = String(s);
    return s.indexOf(' ') < 0 ? s : s.replace(/ +([:;!?»])/g, '\u00a0$1').replace(/« +/g, '«\u00a0');
  }
  RDC.typo = typo;
  var RAW = { textarea: 1, pre: 1, code: 1, input: 1, script: 1, style: 1 };

  function h(tag, attrs) {
    var el = document.createElement(tag);
    if (attrs) {
      for (var k in attrs) {
        if (!Object.prototype.hasOwnProperty.call(attrs, k)) continue;
        var v = attrs[k];
        if (v === null || v === undefined || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'text') el.textContent = RAW[tag] ? v : typo(v);
        else if (k === 'html') el.innerHTML = v;
        else if (k === 'style' && typeof v === 'object') { for (var s in v) { if (s.indexOf('--') === 0) el.style.setProperty(s, v[s]); else el.style[s] = v[s]; } }
        else if (k === 'dataset') { for (var d in v) el.dataset[d] = v[d]; }
        else if (k.indexOf('on') === 0 && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (v === true) el.setAttribute(k, '');
        else el.setAttribute(k, v);
      }
    }
    for (var i = 2; i < arguments.length; i++) append(el, arguments[i]);
    return el;
  }
  function append(el, c) {
    if (c === null || c === undefined || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { append(el, x); }); return; }
    el.appendChild(c instanceof Node ? c : document.createTextNode(RAW[el.localName] ? String(c) : typo(c)));
  }
  RDC.h = h;
  RDC.$ = function (sel, root) { return (root || document).querySelector(sel); };
  RDC.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  RDC.clear = function (el) { while (el && el.firstChild) el.removeChild(el.firstChild); return el; };
  RDC.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  };
  RDC.frag = function (html) { var t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstChild; };

  /* ───────────── Icônes (SVG en ligne) ───────────── */
  var I = {
    scan: '<path d="M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2"/><rect x="7.5" y="7.5" width="3.5" height="3.5" rx=".6"/><rect x="13" y="7.5" width="3.5" height="3.5" rx=".6"/><rect x="7.5" y="13" width="3.5" height="3.5" rx=".6"/><path d="M13 13h1.5v1.5M16.5 16.5V15M13 16.5h1.5"/>',
    keyboard: '<rect x="2.5" y="6" width="19" height="12" rx="2.5"/><path d="M6.5 10h.01M10 10h.01M13.5 10h.01M17 10h.01M7.5 14h9"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M4.5 12.5l4.5 4.5L19.5 7"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
    gift: '<rect x="3.5" y="8.5" width="17" height="4" rx="1"/><path d="M5 12.5v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7M12 8.5v12M12 8.5c-1.5-4-6-4.5-6-2s4 2 6 2zM12 8.5c1.5-4 6-4.5 6-2s-4 2-6 2z"/>',
    crown: '<path d="M3.5 8l4.5 4 4-7 4 7 4.5-4-2 11h-13z"/><path d="M6 19h12"/>',
    star: '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
    soundOn: '<path d="M4 9.5v5h3.5L12 19V5L7.5 9.5z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
    soundOff: '<path d="M4 9.5v5h3.5L12 19V5L7.5 9.5z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
    phone: '<path d="M6.6 3.5h2.6l1.5 4-2 1.3a11 11 0 0 0 6.5 6.5l1.3-2 4 1.5v2.6a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 4.6 5.7a2 2 0 0 1 2-2.2z"/>',
    whatsapp: '<path d="M4.5 19.5l1.2-3.6A8 8 0 1 1 8.4 18.6z"/><path d="M9 8.6c.3-.6.9-.7 1.2-.2l.7 1.4c.1.3 0 .6-.2.8l-.5.5c.4 1 1.3 1.9 2.3 2.4l.5-.5c.2-.2.5-.3.8-.2l1.4.7c.5.3.4.9-.2 1.2-.7.4-1.6.6-2.6.1A8 8 0 0 1 9 11.2c-.4-1-.4-1.9 0-2.6z"/>',
    instagram: '<rect x="4" y="4" width="16" height="16" rx="4.5"/><circle cx="12" cy="12" r="3.6"/><path d="M16.8 7.2h.01"/>',
    facebook: '<path d="M14 21v-7.5h2.6l.4-3H14V8.6c0-.9.3-1.5 1.6-1.5H17V4.4a20 20 0 0 0-2.3-.1C12.4 4.3 11 5.7 11 8.2v2.3H8.5v3H11V21"/>',
    globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.4 2.5 3.5 5.3 3.5 8.5s-1.1 6-3.5 8.5c-2.4-2.5-3.5-5.3-3.5-8.5S9.6 6 12 3.5z"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    trash: '<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 12.5a1.5 1.5 0 0 0 1.5 1.4h6a1.5 1.5 0 0 0 1.5-1.4l1-12.5M10 11v6M14 11v6"/>',
    edit: '<path d="M14.5 5.5l4 4L8 20H4v-4z"/><path d="M12.5 7.5l4 4"/>',
    upload: '<path d="M12 15.5V4M7.5 8.5L12 4l4.5 4.5M4.5 15v3.5a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V15"/>',
    image: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="M20.5 16l-5-5-8.5 8.5"/>',
    print: '<path d="M7 9V3.5h10V9M7 17.5H5a1.5 1.5 0 0 1-1.5-1.5v-5.5A1.5 1.5 0 0 1 5 9h14a1.5 1.5 0 0 1 1.5 1.5V16a1.5 1.5 0 0 1-1.5 1.5h-2"/><rect x="7" y="14" width="10" height="6.5" rx="1"/>',
    download: '<path d="M12 4v11.5M7.5 11L12 15.5 16.5 11M4.5 15.5v3a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-3"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
    user: '<circle cx="12" cy="8.5" r="4"/><path d="M4.5 20.5c1-3.8 4-5.5 7.5-5.5s6.5 1.7 7.5 5.5"/>',
    truck: '<path d="M2.5 6.5h11v10h-11zM13.5 10h4l3 3.5v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>',
    logout: '<path d="M14.5 4.5h3a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2h-3M10 16.5L5.5 12 10 7.5M5.5 12h10"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 0 0-2.1-1.2L14.2 3h-4.4l-.4 2.6a7 7 0 0 0-2.1 1.2L5 5.9 3 9.3l2 1.5a7 7 0 0 0 0 2.4l-2 1.5 2 3.4 2.3-.9c.6.5 1.3.9 2.1 1.2l.4 2.6h4.4l.4-2.6c.8-.3 1.5-.7 2.1-1.2l2.3.9 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z"/>',
    grid: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5"/>',
    wheel: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="2"/><path d="M12 3.5V10M12 14v6.5M3.5 12H10M14 12h6.5M6 6l4.6 4.6M13.4 13.4L18 18M18 6l-4.6 4.6M10.6 13.4L6 18"/>',
    ticket: '<path d="M3.5 7.5a1.5 1.5 0 0 1 1.5-1.5h14a1.5 1.5 0 0 1 1.5 1.5v2.2a2.3 2.3 0 0 0 0 4.6v2.2a1.5 1.5 0 0 1-1.5 1.5H5a1.5 1.5 0 0 1-1.5-1.5v-2.2a2.3 2.3 0 0 0 0-4.6z"/><path d="M14.5 6v2M14.5 11v2M14.5 16v2"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    copy: '<rect x="8.5" y="8.5" width="11" height="11" rx="2"/><path d="M15.5 8.5V6a1.5 1.5 0 0 0-1.5-1.5H6A1.5 1.5 0 0 0 4.5 6v8A1.5 1.5 0 0 0 6 15.5h2.5"/>',
    refresh: '<path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3M19.5 4.5v4h-4"/>',
    flash: '<path d="M13.5 3L5.5 13.5h6L10.5 21l8-10.5h-6z"/>',
    info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.8h.01"/>',
    warning: '<path d="M12 4l9 15.5H3z"/><path d="M12 10v4.5M12 17.2h.01"/>',
    up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
    down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
    chevron: '<path d="M9 5.5l6.5 6.5L9 18.5"/>',
    chevronDown: '<path d="M5.5 9l6.5 6.5L18.5 9"/>',
    back: '<path d="M15 5.5L8.5 12 15 18.5"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    external: '<path d="M13.5 4.5h6v6M19.5 4.5L11 13M17 13.5v5a1.5 1.5 0 0 1-1.5 1.5h-10A1.5 1.5 0 0 1 4 18.5v-10A1.5 1.5 0 0 1 5.5 7h5"/>',
    sad: '<circle cx="12" cy="12" r="8.5"/><path d="M8.5 16.5c2-2 5-2 7 0M9 9.5h.01M15 9.5h.01"/>',
    palette: '<path d="M12 3.5a8.5 8.5 0 0 0 0 17c1.2 0 1.8-.8 1.8-1.7 0-1.2-1-1.6-1-2.6 0-1 .8-1.7 1.8-1.7h2.2a3.7 3.7 0 0 0 3.7-3.7c0-4.3-3.8-7.3-8.5-7.3z"/><circle cx="7.8" cy="11" r="1"/><circle cx="10.5" cy="7.5" r="1"/><circle cx="15" cy="7.8" r="1"/>',
    text: '<path d="M5 6.5V5h14v1.5M12 5v14M9 19h6"/>',
    toggle: '<rect x="2.5" y="7" width="19" height="10" rx="5"/><circle cx="16.5" cy="12" r="3"/>',
    dashboard: '<path d="M4 13.5a8 8 0 1 1 16 0"/><path d="M12 13.5l4-4.5"/><path d="M4 18.5h16"/>',
    box: '<path d="M3.5 7.5L12 3.5l8.5 4v9L12 20.5l-8.5-4z"/><path d="M3.5 7.5L12 11.5l8.5-4M12 11.5v9"/>',
    drag: '<path d="M9 6h.01M15 6h.01M9 12h.01M15 12h.01M9 18h.01M15 18h.01"/>',
    camera: '<path d="M4.5 8h3l1.5-2.5h6L16.5 8h3a1 1 0 0 1 1 1v9.5a1 1 0 0 1-1 1h-15a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>',
    calendar: '<rect x="4" y="5.5" width="16" height="14.5" rx="2"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>',
    filter: '<path d="M4 6h16M7 12h10M10 18h4"/>',
    shield: '<path d="M12 3.5l7.5 3v5.5c0 4.5-3.2 7.6-7.5 9-4.3-1.4-7.5-4.5-7.5-9V6.5z"/><path d="M8.8 12.2l2.3 2.3 4.3-4.6"/>'
  };
  RDC.icon = function (name, cls) {
    var p = I[name] || I.info;
    return '<svg class="ico' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
  };
  RDC.iconEl = function (name, cls) { return RDC.frag(RDC.icon(name, cls)); };

  /* ───────────── Configuration & adresses ───────────── */
  RDC.cfg = { base: '/', api: '/api/', demo: false };

  RDC.asset = function (p) {
    if (!p) return '';
    if (/^(https?:|data:|blob:|\/)/i.test(p)) return p;
    return RDC.cfg.base + p;
  };

  RDC.url = {
    project: function (slug, code) {
      if (RDC.cfg.demo) return '#/p/' + encodeURIComponent(slug) + (code ? '/' + encodeURIComponent(code) : '');
      return RDC.cfg.base + '?p=' + encodeURIComponent(slug) + (code ? '&c=' + encodeURIComponent(code) : '');
    },
    portal: function (code) {
      if (RDC.cfg.demo) return '#/portail' + (code ? '/' + encodeURIComponent(code) : '');
      return RDC.cfg.base + (code ? '?c=' + encodeURIComponent(code) : '');
    },
    admin: function () { return RDC.cfg.demo ? '#/admin' : RDC.cfg.base + 'admin/'; },
    livreur: function () { return RDC.cfg.demo ? '#/livreur' : RDC.cfg.base + 'livreur/'; },
    print: function (batch) { return RDC.cfg.demo ? '#/tickets/' + batch : RDC.cfg.base + 'admin/print.php?batch=' + batch; },
    download: function (action, params) {
      var q = '';
      for (var k in (params || {})) if (params[k] !== '' && params[k] != null) q += '&' + k + '=' + encodeURIComponent(params[k]);
      return RDC.cfg.api + '?a=' + action + q;
    },
    /** Lien encodé dans un QR code de ticket. link = 'portal' ou le slug d'un projet. */
    ticket: function (code, base, link, projects) {
      var c = String(code).replace(/[^A-Z0-9]/gi, '').toUpperCase();
      base = base || RDC.cfg.publicBase || (location.origin + RDC.cfg.base);
      if (!/\/$/.test(base)) base += '/';
      if (link && link !== 'portal') {
        var p = (projects || []).filter(function (x) { return x.slug === link; })[0];
        if (p && p.domain) return 'https://' + p.domain + '/?c=' + c;
        return base + '?p=' + encodeURIComponent(link) + '&c=' + c;
      }
      return base + '?c=' + c;
    }
  };

  /* ───────────── Appels au serveur ───────────── */
  function ApiError(message, code, data) {
    this.name = 'ApiError'; this.message = message; this.code = code || 'error'; this.data = data || {};
  }
  ApiError.prototype = Object.create(Error.prototype);
  RDC.ApiError = ApiError;

  RDC.transport = function (action, data) {
    return fetch(RDC.cfg.api + '?a=' + encodeURIComponent(action), {
      method: 'POST', credentials: 'same-origin', cache: 'no-store',
      headers: { 'Content-Type': 'application/json', 'X-RDC': '1' },
      body: JSON.stringify(data || {})
    }).then(function (r) {
      return r.text().then(function (t) {
        var j = null;
        try { j = JSON.parse(t); } catch (e) { /* réponse non JSON */ }
        if (!j) throw new ApiError(r.status >= 500 ? 'Le serveur ne répond pas correctement. Réessayez dans un instant.' : 'Réponse inattendue du serveur (' + r.status + ').', 'server');
        return j;
      });
    }, function () {
      throw new ApiError('Connexion impossible. Vérifiez votre accès à Internet puis réessayez.', 'network');
    });
  };

  RDC.api = function (action, data) {
    return Promise.resolve(RDC.transport(action, data)).then(function (j) {
      if (!j.ok) {
        if (j.error === 'auth' && typeof RDC.onAuthLost === 'function') RDC.onAuthLost(j);
        throw new ApiError(j.message || 'Une erreur est survenue.', j.error, j);
      }
      return j;
    });
  };

  RDC.uploadTransport = function (file, kind) {
    var fd = new FormData();
    fd.append('file', file);
    fd.append('kind', kind || 'product');
    return fetch(RDC.cfg.api + '?a=adm.upload', { method: 'POST', credentials: 'same-origin', headers: { 'X-RDC': '1' }, body: fd })
      .then(function (r) { return r.json().catch(function () { throw new ApiError('Envoi impossible : le fichier est peut-être trop lourd pour votre hébergement.', 'upload'); }); },
        function () { throw new ApiError('Connexion impossible pendant l’envoi.', 'network'); });
  };
  /** Réduit dans le navigateur les grosses photos (souvent 4 à 8 Mo sur téléphone) avant l'envoi. */
  RDC.shrinkImage = function (file, kind) {
    var limit = 1.5 * 1024 * 1024;
    if (!file || file.size <= limit || !/^image\/(jpeg|png|webp)$/.test(file.type) || !window.HTMLCanvasElement) return Promise.resolve(file);
    var max = kind === 'background' ? 2400 : kind === 'logo' || kind === 'portal' ? 900 : 1200;
    return new Promise(function (resolve) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        var r = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
        var cv = document.createElement('canvas');
        cv.width = Math.max(1, Math.round(img.naturalWidth * r));
        cv.height = Math.max(1, Math.round(img.naturalHeight * r));
        cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
        URL.revokeObjectURL(url);
        var png = file.type === 'image/png' && (kind === 'logo' || kind === 'portal');
        cv.toBlob(function (blob) {
          if (!blob || blob.size >= file.size) { resolve(file); return; }
          var name = (file.name || 'image').replace(/\.[a-z0-9]+$/i, '') + (png ? '.png' : '.jpg');
          try { resolve(new File([blob], name, { type: blob.type })); } catch (e) { blob.name = name; resolve(blob); }
        }, png ? 'image/png' : 'image/jpeg', 0.86);
      };
      img.onerror = function () { URL.revokeObjectURL(url); resolve(file); };
      img.src = url;
    });
  };
  RDC.upload = function (file, kind) {
    return RDC.shrinkImage(file, kind).then(function (f) { return RDC.uploadTransport(f, kind); }).then(function (j) {
      if (!j.ok) throw new ApiError(j.message || 'Envoi impossible.', j.error, j);
      return j;
    });
  };

  /** Téléchargement d'un export (CSV, sauvegarde) via le cookie de session. */
  RDC.download = function (action, params) {
    var a = document.createElement('a');
    a.href = RDC.url.download(action, params);
    a.download = '';
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  RDC.loadScript = function (urls) {
    urls = [].concat(urls);
    return new Promise(function (resolve, reject) {
      (function next(i) {
        if (i >= urls.length) { reject(new Error('script')); return; }
        var s = document.createElement('script');
        s.src = urls[i]; s.async = true;
        s.onload = function () { resolve(urls[i]); };
        s.onerror = function () { s.remove(); next(i + 1); };
        document.head.appendChild(s);
      })(0);
    });
  };

  /* ───────────── Codes des tickets ───────────── */
  var ALPHA = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  RDC.code = {
    alphabet: ALPHA,
    checksum: function (body) {
      var sum = 0;
      for (var i = 0; i < body.length; i++) sum += (i + 1) * ALPHA.indexOf(body.charAt(i));
      return ALPHA.charAt(sum % 31);
    },
    extract: function (raw) {
      raw = String(raw || '').trim();
      if (/^[a-z][a-z0-9+.\-]*:\/\//i.test(raw) || raw.indexOf('?') >= 0 || raw.indexOf('/') >= 0) {
        var m = raw.match(/[?&#](?:c|code)=([A-Za-z0-9\-]+)/);
        if (m) return m[1];
        var m2 = raw.match(/([A-Za-z0-9]{5}-?[A-Za-z0-9]{5})\/?$/);
        if (m2) return m2[1];
      }
      return raw;
    },
    /** Renvoie le code sur 10 caractères, ou null si invalide (format ou clé de contrôle). */
    normalize: function (raw) {
      var s = RDC.code.extract(raw).toUpperCase().replace(/[^A-Z0-9]/g, '');
      if (s.length !== 10) return null;
      for (var i = 0; i < 10; i++) if (ALPHA.indexOf(s.charAt(i)) < 0) return null;
      if (RDC.code.checksum(s.slice(0, 9)) !== s.charAt(9)) return null;
      return s;
    },
    format: function (c) {
      var s = String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
      return s.length > 5 ? s.slice(0, 5) + '-' + s.slice(5, 10) : s;
    },
    /** Mise en forme pendant la saisie : majuscules, caractères autorisés, tiret automatique. */
    typing: function (v) {
      var s = String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10);
      return s.length > 5 ? s.slice(0, 5) + '-' + s.slice(5) : s;
    }
  };

  /* ───────────── Couleurs ───────────── */
  function hexToRgb(hex) {
    var m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '').trim());
    if (!m) return [0, 0, 0];
    var n = parseInt(m[1], 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function rgbToHex(r) {
    return '#' + r.map(function (v) { v = Math.max(0, Math.min(255, Math.round(v))); return (v < 16 ? '0' : '') + v.toString(16); }).join('').toUpperCase();
  }
  RDC.color = {
    rgb: hexToRgb,
    hex: rgbToHex,
    mix: function (a, b, t) { var x = hexToRgb(a), y = hexToRgb(b); return rgbToHex([0, 1, 2].map(function (i) { return x[i] + (y[i] - x[i]) * t; })); },
    shade: function (c, amt) { return amt < 0 ? RDC.color.mix(c, '#000000', -amt) : RDC.color.mix(c, '#FFFFFF', amt); },
    alpha: function (c, a) { var x = hexToRgb(c); return 'rgba(' + x[0] + ',' + x[1] + ',' + x[2] + ',' + a + ')'; },
    luminance: function (c) {
      var x = hexToRgb(c).map(function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
      return 0.2126 * x[0] + 0.7152 * x[1] + 0.0722 * x[2];
    },
    ink: function (c, dark, light) { return RDC.color.luminance(c) > 0.36 ? (dark || '#14062E') : (light || '#FFFFFF'); }
  };

  /** Applique les couleurs et polices d'un thème sous forme de variables CSS. */
  RDC.applyTheme = function (t, target, fonts) {
    var el = target || document.documentElement;
    var C = RDC.color;
    var set = function (k, v) { el.style.setProperty(k, v); };
    set('--c1', t.c1); set('--c2', t.c2); set('--c3', t.c3);
    set('--bg1', t.bg1); set('--bg2', t.bg2); set('--ink', t.text || '#FFFFFF');
    set('--c1-ink', C.ink(t.c1)); set('--c2-ink', C.ink(t.c2)); set('--c3-ink', C.ink(t.c3));
    set('--c1-a', C.alpha(t.c1, 0.45)); set('--c2-a', C.alpha(t.c2, 0.45)); set('--c3-a', C.alpha(t.c3, 0.5));
    set('--panel', C.alpha(C.mix(t.bg1, t.bg2, 0.5), 0.72));
    set('--panel-solid', C.mix(t.bg1, t.bg2, 0.55));
    set('--line', C.alpha(t.text || '#FFFFFF', 0.14));
    var f = fonts || (RDC.boot && RDC.boot.fonts);
    if (t.font_title) {
      var w = f && f.title && f.title[t.font_title] ? f.title[t.font_title].weight : 400;
      set('--font-title', "'" + t.font_title + "', 'Bungee', Impact, sans-serif");
      set('--title-weight', String(w || 400));
    }
    if (t.font_body) set('--font-body', "'" + t.font_body + "', 'Barlow', system-ui, sans-serif");
    if (f) RDC.loadFonts([f.title && f.title[t.font_title] && f.title[t.font_title].spec, f.body && f.body[t.font_body] && f.body[t.font_body].spec, f.wheel]);
  };

  var loadedFonts = {};
  RDC.loadFonts = function (specs) {
    var list = (specs || []).filter(function (s) { return s && !loadedFonts[s]; });
    if (!list.length) return;
    list.forEach(function (s) { loadedFonts[s] = true; });
    var l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = 'https://fonts.googleapis.com/css2?family=' + list.join('&family=') + '&display=swap';
    document.head.appendChild(l);
  };

  /* ───────────── Dates & nombres ───────────── */
  RDC.fmt = {
    date: function (iso, withTime) {
      if (!iso) return '';
      var d = new Date(iso);
      if (isNaN(d)) return '';
      var p2 = function (n) { return (n < 10 ? '0' : '') + n; };
      var out = p2(d.getDate()) + '/' + p2(d.getMonth() + 1) + '/' + d.getFullYear();
      if (withTime !== false) out += ' à ' + p2(d.getHours()) + ':' + p2(d.getMinutes());
      return out;
    },
    short: function (iso) {
      var d = new Date(iso);
      if (isNaN(d)) return '';
      return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) + ' à ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    },
    day: function (iso) {
      var d = new Date(iso);
      return isNaN(d) ? '' : d.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });
    },
    relative: function (iso) {
      if (!iso) return '';
      var s = (Date.now() - new Date(iso).getTime()) / 1000;
      if (s < 45) return 'à l’instant';
      if (s < 3600) return 'il y a ' + Math.round(s / 60) + ' min';
      if (s < 86400) return 'il y a ' + Math.round(s / 3600) + ' h';
      if (s < 86400 * 7) { var j = Math.round(s / 86400); return 'il y a ' + j + ' jour' + (j > 1 ? 's' : ''); }
      return RDC.fmt.date(iso, false);
    },
    num: function (n) { return Number(n || 0).toLocaleString('fr-FR'); },
    pct: function (n) { return (Math.round(n * 10) / 10).toLocaleString('fr-FR') + ' %'; },
    plural: function (n, one, many) { return RDC.fmt.num(n) + ' ' + (Math.abs(n) > 1 ? many : one); }
  };

  /* ───────────── Stockage local (facultatif) ───────────── */
  RDC.store = {
    get: function (k, def) { try { var v = localStorage.getItem('rdc.' + k); return v === null ? def : JSON.parse(v); } catch (e) { return def; } },
    set: function (k, v) { try { localStorage.setItem('rdc.' + k, JSON.stringify(v)); } catch (e) { /* stockage indisponible */ } }
  };

  RDC.reducedMotion = function () {
    return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  };

  /* ───────────── Messages éphémères ───────────── */
  var toastBox = null;
  RDC.toast = function (msg, type, ms) {
    if (!toastBox || !document.body.contains(toastBox)) {
      toastBox = h('div', { class: 'rdc-toasts', role: 'status', 'aria-live': 'polite' });
      document.body.appendChild(toastBox);
    }
    var t = h('div', { class: 'rdc-toast' + (type ? ' is-' + type : '') }, h('span', { html: RDC.icon(type === 'error' ? 'warning' : type === 'success' ? 'check' : 'info') }), h('span', { text: msg }));
    toastBox.appendChild(t);
    setTimeout(function () { t.classList.add('is-leaving'); setTimeout(function () { t.remove(); }, 220); }, ms || (type === 'error' ? 5200 : 3200));
  };

  /* ───────────── Fenêtres ───────────── */
  var openModals = [];
  RDC.modal = function (o) {
    o = o || {};
    var lastFocus = document.activeElement;
    var titleId = 'm' + Math.random().toString(36).slice(2, 8);
    var panel = h('div', { class: 'rdc-modal__panel' + (o.className ? ' ' + o.className : ''), role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': o.title ? titleId : null, 'aria-label': o.title ? null : (o.label || 'Fenêtre') });
    var wrap = h('div', { class: 'rdc-modal' + (o.wrapClass ? ' ' + o.wrapClass : '') }, panel);
    if (o.width) wrap.style.setProperty('--modal-width', o.width);
    var api = { el: wrap, panel: panel, close: close };
    if (o.title || o.dismissible !== false) {
      var head = h('div', { class: 'rdc-modal__head' });
      head.appendChild(h('h2', { class: 'rdc-modal__title', id: titleId, text: o.title || '' }));
      if (o.dismissible !== false) head.appendChild(h('button', { type: 'button', class: 'rdc-modal__close', 'aria-label': 'Fermer', html: RDC.icon('close'), onclick: function () { close(); } }));
      panel.appendChild(head);
    }
    var body = h('div', { class: 'rdc-modal__body' });
    if (o.content) append(body, typeof o.content === 'function' ? o.content(api) : o.content);
    panel.appendChild(body);
    api.body = body;
    if (o.actions && o.actions.length) {
      var acts = h('div', { class: 'rdc-modal__actions' });
      o.actions.forEach(function (a) {
        var b = h('button', { type: 'button', class: a.class || 'btn', text: a.label, onclick: function () { if (a.onClick) { var r = a.onClick(api, b); if (r === false) return; } if (a.close !== false) close(a.value); } });
        acts.appendChild(b);
      });
      panel.appendChild(acts);
    }
    function onKey(e) {
      if (openModals[openModals.length - 1] !== api) return;
      if (e.key === 'Escape' && o.dismissible !== false) { e.preventDefault(); close(); }
      if (e.key === 'Tab') {
        var f = RDC.$$('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])', panel).filter(function (x) { return !x.disabled && x.offsetParent !== null; });
        if (!f.length) return;
        if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
        else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
      }
    }
    var closed = false;
    function close(value) {
      if (closed) return;
      closed = true;
      document.removeEventListener('keydown', onKey);
      openModals = openModals.filter(function (m) { return m !== api; });
      wrap.classList.remove('is-open');
      setTimeout(function () { wrap.remove(); if (!openModals.length) document.documentElement.classList.remove('rdc-noscroll'); }, 190);
      if (lastFocus && lastFocus.focus) try { lastFocus.focus({ preventScroll: true }); } catch (e) { /* élément disparu */ }
      if (o.onClose) o.onClose(value);
    }
    if (o.dismissible !== false) wrap.addEventListener('mousedown', function (e) { if (e.target === wrap) close(); });
    document.addEventListener('keydown', onKey);
    (o.root || document.body).appendChild(wrap);
    openModals.push(api);
    document.documentElement.classList.add('rdc-noscroll');
    requestAnimationFrame(function () {
      wrap.classList.add('is-open');
      var first = RDC.$(o.focus || '[autofocus], input, select, textarea', panel) || RDC.$('.rdc-modal__actions button:last-child', panel) || RDC.$('button', panel);
      if (first) try { first.focus({ preventScroll: true }); } catch (e) { /* rien */ }
    });
    return api;
  };
  RDC.closeAllModals = function () { openModals.slice().forEach(function (m) { m.close(); }); };

  RDC.confirm = function (o) {
    return new Promise(function (resolve) {
      var done = false;
      RDC.modal({
        title: o.title, width: '420px', className: o.className,
        content: o.message ? h('p', { class: 'modal-text', text: o.message }) : null,
        actions: [
          { label: o.cancel || 'Annuler', class: o.cancelClass || 'btn btn--ghost', onClick: function () { done = true; resolve(false); } },
          { label: o.confirm || 'Confirmer', class: o.confirmClass || ('btn ' + (o.danger ? 'btn--danger' : 'btn--primary')), onClick: function () { done = true; resolve(true); } }
        ],
        onClose: function () { if (!done) resolve(false); }
      });
    });
  };

  /** Met un bouton en attente pendant une promesse. */
  RDC.busy = function (btn, promise) {
    if (btn) { btn.classList.add('is-busy'); btn.disabled = true; }
    var end = function () { if (btn) { btn.classList.remove('is-busy'); btn.disabled = false; } };
    return Promise.resolve(promise).then(function (v) { end(); return v; }, function (e) { end(); throw e; });
  };

  RDC.debounce = function (fn, ms) {
    var t;
    return function () { var a = arguments, self = this; clearTimeout(t); t = setTimeout(function () { fn.apply(self, a); }, ms); };
  };

  RDC.copy = function (text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
    return new Promise(function (resolve, reject) {
      var ta = h('textarea', { style: { position: 'fixed', opacity: '0' } });
      ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); resolve(); } catch (e) { reject(e); }
      ta.remove();
    });
  };

  /* ───────────── Démarrage ───────────── */
  RDC.apps = RDC.apps || {};
  RDC.start = function (boot, root) {
    RDC.boot = boot || {};
    if (boot.base) RDC.cfg.base = boot.base;
    if (boot.api) RDC.cfg.api = boot.api;
    if (boot.qr_base) RDC.cfg.publicBase = boot.qr_base;
    var map = { game: 'Game', portal: 'Portal', closed: 'Portal', admin: 'Admin', livreur: 'Livreur', print: 'Print' };
    var app = RDC.apps[map[boot.mode]];
    if (!app) return null;
    return app.mount(root || document.getElementById('app'), boot);
  };
})();
