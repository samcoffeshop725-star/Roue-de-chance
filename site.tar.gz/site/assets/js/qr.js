/*!
 * Roue de la Chance — générateur de QR codes (autonome, sans dépendance).
 * Implémente la norme ISO/IEC 18004 (mode octet, versions 1 à 40, niveaux L/M/Q/H).
 */
(function (root) {
  'use strict';

  var ECC_PER_BLOCK = [
    [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
    [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30]
  ];
  var NUM_BLOCKS = [
    [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
    [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
    [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
    [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81]
  ];
  // Ordre interne des niveaux : L=0, M=1, Q=2, H=3 ; bits de format correspondants.
  var ECL_INDEX = { L: 0, M: 1, Q: 2, H: 3 };
  var ECL_FORMAT_BITS = [1, 0, 3, 2];

  function getBit(x, i) { return ((x >>> i) & 1) !== 0; }

  function rawDataModules(ver) {
    var result = (16 * ver + 128) * ver + 64;
    if (ver >= 2) {
      var numAlign = Math.floor(ver / 7) + 2;
      result -= (25 * numAlign - 10) * numAlign - 55;
      if (ver >= 7) result -= 36;
    }
    return result;
  }

  function dataCodewords(ver, ecl) {
    return Math.floor(rawDataModules(ver) / 8) - ECC_PER_BLOCK[ecl][ver] * NUM_BLOCKS[ecl][ver];
  }

  // Arithmétique dans GF(2^8) modulo x^8 + x^4 + x^3 + x^2 + 1 (0x11D)
  function gfMul(x, y) {
    var z = 0;
    for (var i = 7; i >= 0; i--) {
      z = (z << 1) ^ ((z >>> 7) * 0x11D);
      z ^= ((y >>> i) & 1) * x;
    }
    return z & 0xFF;
  }

  function rsDivisor(degree) {
    var result = [];
    for (var i = 0; i < degree - 1; i++) result.push(0);
    result.push(1);
    var root = 1;
    for (var k = 0; k < degree; k++) {
      for (var j = 0; j < result.length; j++) {
        result[j] = gfMul(result[j], root);
        if (j + 1 < result.length) result[j] ^= result[j + 1];
      }
      root = gfMul(root, 0x02);
    }
    return result;
  }

  function rsRemainder(data, divisor) {
    var result = divisor.map(function () { return 0; });
    for (var i = 0; i < data.length; i++) {
      var factor = data[i] ^ result.shift();
      result.push(0);
      for (var j = 0; j < divisor.length; j++) result[j] ^= gfMul(divisor[j], factor);
    }
    return result;
  }

  function utf8Bytes(str) {
    if (typeof TextEncoder !== 'undefined') return Array.prototype.slice.call(new TextEncoder().encode(str));
    var out = [], s = unescape(encodeURIComponent(str));
    for (var i = 0; i < s.length; i++) out.push(s.charCodeAt(i));
    return out;
  }

  function alignmentPositions(ver, size) {
    if (ver === 1) return [];
    var numAlign = Math.floor(ver / 7) + 2;
    var step = Math.floor((ver * 8 + numAlign * 3 + 5) / (numAlign * 4 - 4)) * 2;
    var result = [6];
    for (var pos = size - 7; result.length < numAlign; pos -= step) result.splice(1, 0, pos);
    return result;
  }

  /**
   * Encode un texte en matrice QR.
   * @param {string} text
   * @param {object} [opts] { ecl: 'L'|'M'|'Q'|'H', minVersion, maxVersion, mask (-1 = auto), boostEcl }
   * @returns {{size:number, version:number, ecl:string, mask:number, modules:boolean[][]}}
   */
  function encode(text, opts) {
    opts = opts || {};
    var ecl = ECL_INDEX[(opts.ecl || 'M').toUpperCase()];
    if (ecl === undefined) ecl = 1;
    var minVer = opts.minVersion || 1, maxVer = opts.maxVersion || 40;
    var bytes = utf8Bytes(String(text));

    var ver, usedBits;
    for (ver = minVer; ; ver++) {
      var ccBits = ver < 10 ? 8 : 16;
      usedBits = 4 + ccBits + bytes.length * 8;
      if (bytes.length < (1 << ccBits) && usedBits <= dataCodewords(ver, ecl) * 8) break;
      if (ver >= maxVer) throw new Error('Texte trop long pour un QR code');
    }
    if (opts.boostEcl !== false) {
      for (var e = 3; e > ecl; e--) {
        if (usedBits <= dataCodewords(ver, e) * 8) { ecl = e; break; }
      }
    }

    // Flux de bits
    var bb = [];
    function append(val, len) { for (var i = len - 1; i >= 0; i--) bb.push((val >>> i) & 1); }
    append(0x4, 4);
    append(bytes.length, ver < 10 ? 8 : 16);
    bytes.forEach(function (b) { append(b, 8); });
    var capacityBits = dataCodewords(ver, ecl) * 8;
    append(0, Math.min(4, capacityBits - bb.length));
    append(0, (8 - bb.length % 8) % 8);
    for (var pad = 0xEC; bb.length < capacityBits; pad ^= 0xEC ^ 0x11) append(pad, 8);

    var data = [];
    for (var i = 0; i < bb.length; i += 8) {
      var byte = 0;
      for (var k = 0; k < 8; k++) byte = (byte << 1) | bb[i + k];
      data.push(byte);
    }

    // Blocs + correction d'erreurs + entrelacement
    var numBlocks = NUM_BLOCKS[ecl][ver], blockEccLen = ECC_PER_BLOCK[ecl][ver];
    var rawCodewords = Math.floor(rawDataModules(ver) / 8);
    var numShortBlocks = numBlocks - rawCodewords % numBlocks;
    var shortBlockLen = Math.floor(rawCodewords / numBlocks);
    var blocks = [], divisor = rsDivisor(blockEccLen);
    for (var b = 0, off = 0; b < numBlocks; b++) {
      var len = shortBlockLen - blockEccLen + (b < numShortBlocks ? 0 : 1);
      var dat = data.slice(off, off + len);
      off += len;
      var ecc = rsRemainder(dat, divisor);
      if (b < numShortBlocks) dat.push(0);
      blocks.push(dat.concat(ecc));
    }
    var allCodewords = [];
    for (var c = 0; c < blocks[0].length; c++) {
      for (var bi = 0; bi < blocks.length; bi++) {
        if (c !== shortBlockLen - blockEccLen || bi >= numShortBlocks) allCodewords.push(blocks[bi][c]);
      }
    }

    // Matrice
    var size = ver * 4 + 17;
    var modules = [], isFunc = [];
    for (var y = 0; y < size; y++) {
      modules.push(new Array(size).fill(false));
      isFunc.push(new Array(size).fill(false));
    }
    function setFn(x, y, dark) { modules[y][x] = dark; isFunc[y][x] = true; }

    for (var t = 0; t < size; t++) { setFn(6, t, t % 2 === 0); setFn(t, 6, t % 2 === 0); }
    function finder(cx, cy) {
      for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) {
        var dist = Math.max(Math.abs(dx), Math.abs(dy)), xx = cx + dx, yy = cy + dy;
        if (xx >= 0 && xx < size && yy >= 0 && yy < size) setFn(xx, yy, dist !== 2 && dist !== 4);
      }
    }
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    var ap = alignmentPositions(ver, size), na = ap.length;
    for (var ai = 0; ai < na; ai++) for (var aj = 0; aj < na; aj++) {
      if ((ai === 0 && aj === 0) || (ai === 0 && aj === na - 1) || (ai === na - 1 && aj === 0)) continue;
      for (var dy2 = -2; dy2 <= 2; dy2++) for (var dx2 = -2; dx2 <= 2; dx2++) {
        setFn(ap[ai] + dx2, ap[aj] + dy2, Math.max(Math.abs(dx2), Math.abs(dy2)) !== 1);
      }
    }
    function drawFormat(mask) {
      var d = ECL_FORMAT_BITS[ecl] << 3 | mask, rem = d;
      for (var q = 0; q < 10; q++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
      var bits = (d << 10 | rem) ^ 0x5412;
      for (var i = 0; i <= 5; i++) setFn(8, i, getBit(bits, i));
      setFn(8, 7, getBit(bits, 6));
      setFn(8, 8, getBit(bits, 7));
      setFn(7, 8, getBit(bits, 8));
      for (var j = 9; j < 15; j++) setFn(14 - j, 8, getBit(bits, j));
      for (var m = 0; m < 8; m++) setFn(size - 1 - m, 8, getBit(bits, m));
      for (var n = 8; n < 15; n++) setFn(8, size - 15 + n, getBit(bits, n));
      setFn(8, size - 8, true);
    }
    drawFormat(0);
    if (ver >= 7) {
      var rem2 = ver;
      for (var q2 = 0; q2 < 12; q2++) rem2 = (rem2 << 1) ^ ((rem2 >>> 11) * 0x1F25);
      var vbits = ver << 12 | rem2;
      for (var vi = 0; vi < 18; vi++) {
        var col = getBit(vbits, vi), a = size - 11 + vi % 3, bb2 = Math.floor(vi / 3);
        setFn(a, bb2, col); setFn(bb2, a, col);
      }
    }

    // Placement en zigzag
    var bitIdx = 0, totalBits = allCodewords.length * 8;
    for (var right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (var vert = 0; vert < size; vert++) {
        for (var jj = 0; jj < 2; jj++) {
          var x = right - jj;
          var upward = ((right + 1) & 2) === 0;
          var yy = upward ? size - 1 - vert : vert;
          if (!isFunc[yy][x] && bitIdx < totalBits) {
            modules[yy][x] = getBit(allCodewords[bitIdx >>> 3], 7 - (bitIdx & 7));
            bitIdx++;
          }
        }
      }
    }

    function applyMask(mask) {
      for (var y = 0; y < size; y++) for (var x = 0; x < size; x++) {
        if (isFunc[y][x]) continue;
        var inv;
        switch (mask) {
          case 0: inv = (x + y) % 2 === 0; break;
          case 1: inv = y % 2 === 0; break;
          case 2: inv = x % 3 === 0; break;
          case 3: inv = (x + y) % 3 === 0; break;
          case 4: inv = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; break;
          case 5: inv = x * y % 2 + x * y % 3 === 0; break;
          case 6: inv = (x * y % 2 + x * y % 3) % 2 === 0; break;
          default: inv = ((x + y) % 2 + x * y % 3) % 2 === 0; break;
        }
        if (inv) modules[y][x] = !modules[y][x];
      }
    }

    function penalty() {
      var score = 0, x, y, run, dark = 0;
      for (y = 0; y < size; y++) {
        run = 1;
        for (x = 1; x < size; x++) {
          if (modules[y][x] === modules[y][x - 1]) { run++; if (run === 5) score += 3; else if (run > 5) score++; }
          else run = 1;
        }
      }
      for (x = 0; x < size; x++) {
        run = 1;
        for (y = 1; y < size; y++) {
          if (modules[y][x] === modules[y - 1][x]) { run++; if (run === 5) score += 3; else if (run > 5) score++; }
          else run = 1;
        }
      }
      for (y = 0; y < size - 1; y++) for (x = 0; x < size - 1; x++) {
        var c = modules[y][x];
        if (c === modules[y][x + 1] && c === modules[y + 1][x] && c === modules[y + 1][x + 1]) score += 3;
      }
      var p1 = [true, false, true, true, true, false, true, false, false, false, false];
      var p2 = [false, false, false, false, true, false, true, true, true, false, true];
      function matchAt(getter) {
        var m1 = true, m2 = true;
        for (var k = 0; k < 11; k++) {
          var v = getter(k);
          if (v !== p1[k]) m1 = false;
          if (v !== p2[k]) m2 = false;
          if (!m1 && !m2) return false;
        }
        return true;
      }
      for (y = 0; y < size; y++) for (x = 0; x <= size - 11; x++) {
        if (matchAt(function (k) { return modules[y][x + k]; })) score += 40;
      }
      for (x = 0; x < size; x++) for (y = 0; y <= size - 11; y++) {
        if (matchAt(function (k) { return modules[y + k][x]; })) score += 40;
      }
      for (y = 0; y < size; y++) for (x = 0; x < size; x++) if (modules[y][x]) dark++;
      var total = size * size;
      var kk = Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1;
      score += Math.max(0, kk) * 10;
      return score;
    }

    var mask = (typeof opts.mask === 'number' && opts.mask >= 0) ? opts.mask : -1;
    if (mask === -1) {
      var best = Infinity;
      for (var mi = 0; mi < 8; mi++) {
        applyMask(mi); drawFormat(mi);
        var pen = penalty();
        if (pen < best) { best = pen; mask = mi; }
        applyMask(mi);
      }
    }
    applyMask(mask);
    drawFormat(mask);

    return { size: size, version: ver, ecl: 'LMQH'.charAt(ecl), mask: mask, modules: modules };
  }

  /**
   * Chemin SVG (un seul <path>) pour une matrice, avec marge en modules.
   */
  function toPath(qr, margin) {
    margin = margin == null ? 4 : margin;
    var d = [];
    for (var y = 0; y < qr.size; y++) {
      var x = 0;
      while (x < qr.size) {
        if (qr.modules[y][x]) {
          var start = x;
          while (x < qr.size && qr.modules[y][x]) x++;
          d.push('M' + (start + margin) + ' ' + (y + margin) + 'h' + (x - start) + 'v1h-' + (x - start) + 'z');
        } else x++;
      }
    }
    return d.join('');
  }

  /**
   * Code SVG complet.
   * @param {string} text
   * @param {object} [opts] { ecl, margin, dark, light, title }
   */
  function toSVG(text, opts) {
    opts = opts || {};
    var qr = encode(text, { ecl: opts.ecl || 'M' });
    var margin = opts.margin == null ? 4 : opts.margin;
    var dim = qr.size + margin * 2;
    var dark = opts.dark || '#000', light = opts.light === undefined ? '#fff' : opts.light;
    var bg = light ? '<rect width="' + dim + '" height="' + dim + '" fill="' + light + '"/>' : '';
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + dim + ' ' + dim + '" shape-rendering="crispEdges"' +
      (opts.className ? ' class="' + opts.className + '"' : '') + ' role="img" aria-label="' + (opts.title || 'QR code') + '">' +
      bg + '<path fill="' + dark + '" d="' + toPath(qr, margin) + '"/></svg>';
  }

  var api = { encode: encode, toPath: toPath, toSVG: toSVG };
  root.RDCQR = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
