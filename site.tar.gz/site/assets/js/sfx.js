/*!
 * Roue de la Chance — effets sonores synthétisés (aucun fichier audio à charger).
 */
(function () {
  'use strict';
  var RDC = window.RDC;
  var ctx = null, master = null;
  var enabled = RDC.store.get('sound', true) !== false;

  var gestured = false;
  ['pointerdown', 'keydown', 'touchstart'].forEach(function (ev) {
    document.addEventListener(ev, function () { gestured = true; }, { capture: true, passive: true });
  });
  function ensure() {
    if (!gestured) return null;
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      try { ctx = new AC(); } catch (e) { return null; }
      master = ctx.createGain();
      master.gain.value = 0.55;
      master.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function tone(freq, at, dur, opts) {
    opts = opts || {};
    var c = ensure();
    if (!c || !enabled) return;
    var t0 = c.currentTime + (at || 0);
    var osc = c.createOscillator();
    var g = c.createGain();
    osc.type = opts.type || 'triangle';
    osc.frequency.setValueAtTime(freq, t0);
    if (opts.to) osc.frequency.exponentialRampToValueAtTime(opts.to, t0 + dur);
    var vol = opts.vol == null ? 0.3 : opts.vol;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + Math.min(0.012, dur / 4));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    var node = g;
    if (opts.lowpass) {
      var f = c.createBiquadFilter();
      f.type = 'lowpass'; f.frequency.value = opts.lowpass;
      g.connect(f); node = f;
    }
    osc.connect(g);
    node.connect(master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  var lastTick = 0;
  RDC.sfx = {
    unlock: ensure,
    isEnabled: function () { return enabled; },
    setEnabled: function (v) { enabled = !!v; RDC.store.set('sound', enabled); if (enabled) ensure(); },
    tick: function () {
      var now = performance.now();
      if (now - lastTick < 28) return;
      lastTick = now;
      tone(2100, 0, 0.035, { type: 'square', vol: 0.08, to: 1300, lowpass: 3800 });
    },
    beep: function () { tone(1320, 0, 0.09, { type: 'sine', vol: 0.25 }); tone(1760, 0.09, 0.12, { type: 'sine', vol: 0.22 }); },
    unlockWheel: function () { [523, 659, 784].forEach(function (f, i) { tone(f, i * 0.07, 0.16, { vol: 0.22 }); }); },
    win: function () {
      [523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) { tone(f, i * 0.11, 0.26, { vol: 0.28 }); });
      tone(1318.5, 0.46, 0.5, { vol: 0.22 });
      [2093, 2637, 3136].forEach(function (f, i) { tone(f, 0.55 + i * 0.06, 0.18, { type: 'sine', vol: 0.06 }); });
    },
    jackpot: function () {
      var seq = [392, 523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5, 1318.5];
      seq.forEach(function (f, i) { tone(f, i * 0.12, 0.24, { type: 'square', vol: 0.12, lowpass: 3000 }); tone(f / 2, i * 0.12, 0.24, { vol: 0.12 }); });
      tone(1046.5, 1.0, 0.9, { vol: 0.2 }); tone(1318.5, 1.0, 0.9, { vol: 0.16 }); tone(1568, 1.0, 0.9, { vol: 0.14 });
      for (var i = 0; i < 10; i++) tone(2000 + Math.random() * 2400, 1.05 + i * 0.07, 0.12, { type: 'sine', vol: 0.05 });
    },
    lose: function () {
      tone(392, 0, 0.32, { type: 'sawtooth', vol: 0.14, to: 370, lowpass: 1400 });
      tone(370, 0.34, 0.32, { type: 'sawtooth', vol: 0.14, to: 349, lowpass: 1300 });
      tone(349, 0.68, 0.7, { type: 'sawtooth', vol: 0.14, to: 262, lowpass: 1100 });
    },
    error: function () { tone(220, 0, 0.18, { type: 'square', vol: 0.12, lowpass: 900 }); tone(196, 0.2, 0.25, { type: 'square', vol: 0.12, lowpass: 900 }); }
  };
})();
